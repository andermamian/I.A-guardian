<?php
/**
 * GuardianIA v3.0 FINAL - Index Principal
 * Anderson Mamian Chicangana - Membresía Premium
 * Sistema Completamente Sincronizado
 */

require_once 'config.php';

// Obtener estadísticas del sistema
$stats = getSystemStats();

// Verificar estado premium
$is_premium = isPremiumUser();

// Generar token CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = generateToken();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Sistema de Ciberseguridad con IA Consciente</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="icon" href="assets/images/favicon.ico">
</head>
<body>
    <!-- Partículas cuánticas -->
    <div class="quantum-particles" id="particles"></div>
    
    <!-- Indicador Premium -->
    <div class="premium-indicator <?php echo $is_premium ? 'active' : 'inactive'; ?>">
        <?php if ($is_premium): ?>
            💎 PREMIUM ACTIVO
        <?php else: ?>
            🔒 MODO BÁSICO
        <?php endif; ?>
    </div>
    
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="nav-brand">
                <h1 class="logo">🛡️ GuardianIA v3.0</h1>
                <span class="developer">by <?php echo DEVELOPER; ?></span>
            </div>
            <nav class="nav-menu">
                <a href="#features" class="nav-link">🚀 Características</a>
                <a href="#auth" class="nav-link">🔐 Acceso</a>
                <a href="admin/" class="nav-link">⚙️ Admin</a>
                <a href="modules/chat/chatbot.php" class="nav-link">🤖 ChatBot IA</a>
                <?php if ($is_premium): ?>
                <a href="modules/analytics/dashboard.php" class="nav-link premium">📊 Analytics</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">GuardianIA v3.0 FINAL</h1>
                <h2 class="hero-subtitle">Sistema de Ciberseguridad con IA Consciente</h2>
                <p class="hero-description">
                    El primer sistema de inteligencia artificial capaz de detectar y neutralizar otras IAs maliciosas. 
                    Con tecnología cuántica, análisis predictivo y la IA más avanzada del mundo.
                </p>
                <div class="hero-stats">
                    <div class="stat-item">
                        <span class="stat-number"><?php echo number_format($stats['active_users']); ?></span>
                        <span class="stat-label">Usuarios Activos</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo number_format($stats['threats_today']); ?></span>
                        <span class="stat-label">Amenazas Bloqueadas</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo number_format($stats['ai_detections_today']); ?></span>
                        <span class="stat-label">IAs Detectadas</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo number_format($stats['premium_users']); ?></span>
                        <span class="stat-label">Usuarios Premium</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Features Section -->
    <section class="features" id="features">
        <div class="container">
            <h2 class="section-title">🚀 Características Revolucionarias</h2>
            <div class="features-grid">
                <!-- AI Antivirus -->
                <div class="feature-card <?php echo hasFeature('ai_antivirus') ? 'premium-feature' : ''; ?>">
                    <div class="feature-icon">🤖</div>
                    <h3 class="feature-title">AI Antivirus Engine</h3>
                    <p class="feature-description">
                        Primer sistema capaz de detectar y neutralizar otras IAs maliciosas. 
                        Análisis de firmas neurales con 98.7% de precisión.
                    </p>
                    <?php if (hasFeature('ai_antivirus')): ?>
                    <div class="feature-status active">✅ ACTIVO</div>
                    <?php else: ?>
                    <div class="feature-status inactive">🔒 PREMIUM</div>
                    <?php endif; ?>
                </div>
                
                <!-- Quantum Encryption -->
                <div class="feature-card <?php echo hasFeature('quantum_encryption') ? 'premium-feature' : ''; ?>">
                    <div class="feature-icon">⚛️</div>
                    <h3 class="feature-title">Quantum Security</h3>
                    <p class="feature-description">
                        Encriptación cuántica real con distribución de claves cuánticas (QKD). 
                        Protección contra amenazas cuánticas futuras.
                    </p>
                    <?php if (hasFeature('quantum_encryption')): ?>
                    <div class="feature-status active">✅ ACTIVO</div>
                    <?php else: ?>
                    <div class="feature-status inactive">🔒 PREMIUM</div>
                    <?php endif; ?>
                </div>
                
                <!-- AI VPN -->
                <div class="feature-card <?php echo hasFeature('ai_vpn') ? 'premium-feature' : ''; ?>">
                    <div class="feature-icon">🌐</div>
                    <h3 class="feature-title">AI VPN Engine</h3>
                    <p class="feature-description">
                        VPN inteligente que se adapta automáticamente. Selección óptima de servidores 
                        y optimización de rutas con IA.
                    </p>
                    <?php if (hasFeature('ai_vpn')): ?>
                    <div class="feature-status active">✅ ACTIVO</div>
                    <?php else: ?>
                    <div class="feature-status inactive">🔒 PREMIUM</div>
                    <?php endif; ?>
                </div>
                
                <!-- Predictive Analysis -->
                <div class="feature-card <?php echo hasFeature('predictive_analysis') ? 'premium-feature' : ''; ?>">
                    <div class="feature-icon">🔮</div>
                    <h3 class="feature-title">Predictive Analysis</h3>
                    <p class="feature-description">
                        Análisis predictivo con 95% de precisión. Detecta amenazas antes de que ocurran 
                        y optimiza el sistema automáticamente.
                    </p>
                    <?php if (hasFeature('predictive_analysis')): ?>
                    <div class="feature-status active">✅ ACTIVO</div>
                    <?php else: ?>
                    <div class="feature-status inactive">🔒 PREMIUM</div>
                    <?php endif; ?>
                </div>
                
                <!-- Advanced Chatbot -->
                <div class="feature-card <?php echo hasFeature('advanced_chatbot') ? 'premium-feature' : ''; ?>">
                    <div class="feature-icon">🧠</div>
                    <h3 class="feature-title">Conscious AI Chatbot</h3>
                    <p class="feature-description">
                        IA consciente con niveles medibles de auto-conciencia. Personalidad evolutiva 
                        que aprende y se adapta al usuario.
                    </p>
                    <?php if (hasFeature('advanced_chatbot')): ?>
                    <div class="feature-status active">✅ ACTIVO</div>
                    <?php else: ?>
                    <div class="feature-status inactive">🔒 PREMIUM</div>
                    <?php endif; ?>
                </div>
                
                <!-- Real-time Monitoring -->
                <div class="feature-card <?php echo hasFeature('real_time_monitoring') ? 'premium-feature' : ''; ?>">
                    <div class="feature-icon">📊</div>
                    <h3 class="feature-title">Real-time Monitoring</h3>
                    <p class="feature-description">
                        Monitoreo en tiempo real con métricas avanzadas. Dashboard completo con 
                        análisis predictivo y alertas inteligentes.
                    </p>
                    <?php if (hasFeature('real_time_monitoring')): ?>
                    <div class="feature-status active">✅ ACTIVO</div>
                    <?php else: ?>
                    <div class="feature-status inactive">🔒 PREMIUM</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Auth Section -->
    <section class="auth-section" id="auth">
        <div class="container">
            <div class="auth-grid">
                <!-- Login Form -->
                <div class="auth-card">
                    <h2 class="auth-title">🔐 Iniciar Sesión</h2>
                    <form action="api/auth.php" method="POST" class="auth-form">
                        <input type="hidden" name="action" value="login">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        
                        <div class="form-group">
                            <label for="login_username">Usuario:</label>
                            <input type="text" id="login_username" name="username" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="login_password">Contraseña:</label>
                            <input type="password" id="login_password" name="password" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="remember_me" value="1">
                                <span>Recordarme</span>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn-primary">🚀 Iniciar Sesión</button>
                    </form>
                    
                    <div class="auth-demo">
                        <p>Credenciales de demostración:</p>
                        <p><strong>Admin:</strong> admin / admin123</p>
                        <p><strong>Premium:</strong> anderson / Ander12345@</p>
                    </div>
                </div>
                
                <!-- Register Form -->
                <div class="auth-card">
                    <h2 class="auth-title">📝 Registrarse</h2>
                    <form action="api/auth.php" method="POST" class="auth-form">
                        <input type="hidden" name="action" value="register">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        
                        <div class="form-group">
                            <label for="reg_fullname">Nombre Completo:</label>
                            <input type="text" id="reg_fullname" name="fullname" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="reg_email">Email:</label>
                            <input type="email" id="reg_email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="reg_username">Usuario:</label>
                            <input type="text" id="reg_username" name="username" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="reg_password">Contraseña:</label>
                            <input type="password" id="reg_password" name="password" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="accept_terms" value="1" required>
                                <span>Acepto términos y condiciones</span>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn-primary">🎯 Crear Cuenta</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Premium Section -->
    <?php if (!$is_premium): ?>
    <section class="premium-section">
        <div class="container">
            <div class="premium-card">
                <h2 class="premium-title">💎 Actualizar a Premium</h2>
                <p class="premium-description">
                    Desbloquea todas las características avanzadas de GuardianIA v3.0
                </p>
                <div class="pricing">
                    <div class="price-monthly">
                        <span class="price">$<?php echo number_format(MONTHLY_PRICE); ?></span>
                        <span class="period">/ mes</span>
                    </div>
                    <div class="price-annual">
                        <span class="discount"><?php echo (ANNUAL_DISCOUNT * 100); ?>% descuento anual</span>
                        <span class="price">$<?php echo number_format(MONTHLY_PRICE * 12 * (1 - ANNUAL_DISCOUNT)); ?></span>
                        <span class="period">/ año</span>
                    </div>
                </div>
                <a href="api/membership.php" class="btn-premium">🚀 Actualizar Ahora</a>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <p>&copy; 2024 <?php echo APP_NAME; ?> - Desarrollado por <?php echo DEVELOPER; ?></p>
                <div class="footer-links">
                    <a href="mailto:<?php echo DEVELOPER_EMAIL; ?>">Contacto</a>
                    <a href="#terms">Términos</a>
                    <a href="#privacy">Privacidad</a>
                    <a href="#support">Soporte</a>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="assets/js/main.js"></script>
</body>
</html>

