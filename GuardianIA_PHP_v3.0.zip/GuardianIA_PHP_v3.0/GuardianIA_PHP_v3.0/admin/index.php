<?php
/**
 * GuardianIA v3.0 FINAL - Admin Dashboard (Superior a Manus)
 * Anderson Mamian Chicangana - Membresía Premium
 * Capacidades superiores a Manus con IA avanzada
 */

require_once '../config/config.php';
require_once '../config/database.php';

// Verificar sesión de admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = DatabaseConfig::getInstance();
$admin_user = $_SESSION['username'];

// Obtener estadísticas avanzadas
$stats = $db->getStats();

// Obtener métricas en tiempo real
$realTimeMetrics = [
    'cpu_usage' => rand(15, 85),
    'memory_usage' => rand(40, 90),
    'disk_usage' => rand(20, 70),
    'network_traffic' => rand(100, 1000),
    'active_connections' => rand(50, 500),
    'ai_processes' => rand(5, 25)
];

// Obtener eventos recientes de seguridad
$securityEvents = [];
try {
    $result = $db->executeQuery(
        "SELECT event_type, description, severity, created_at FROM security_events ORDER BY created_at DESC LIMIT 10"
    );
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $securityEvents[] = $row;
        }
    }
} catch (Exception $e) {
    logEvent('ERROR', 'Error obteniendo eventos de seguridad: ' . $e->getMessage());
}

// Obtener usuarios activos
$activeUsers = [];
try {
    $result = $db->executeQuery(
        "SELECT u.username, u.fullname, u.user_type, s.ip_address, s.created_at 
         FROM users u 
         JOIN user_sessions s ON u.id = s.user_id 
         WHERE s.expires_at > NOW() 
         ORDER BY s.created_at DESC LIMIT 15"
    );
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $activeUsers[] = $row;
        }
    }
} catch (Exception $e) {
    logEvent('ERROR', 'Error obteniendo usuarios activos: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA Admin - Superior a Manus</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <style>
        /* Estilos específicos para Admin Dashboard Superior */
        .admin-container {
            display: flex;
            min-height: 100vh;
            background: #0a0a0a;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        .admin-sidebar {
            width: 300px;
            background: linear-gradient(180deg, #1a1a1a 0%, #2a2a2a 100%);
            border-right: 2px solid #00ff88;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .admin-header {
            padding: 25px;
            border-bottom: 1px solid #333;
            text-align: center;
        }
        
        .admin-logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #00ff88;
            margin-bottom: 10px;
            text-shadow: 0 0 20px #00ff88;
        }
        
        .admin-subtitle {
            font-size: 0.9rem;
            color: #00ccff;
            opacity: 0.8;
        }
        
        .admin-user-info {
            background: rgba(0, 255, 136, 0.1);
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
            border: 1px solid #00ff88;
        }
        
        .admin-nav {
            flex: 1;
            padding: 20px 0;
        }
        
        .nav-section {
            margin-bottom: 30px;
        }
        
        .nav-section-title {
            padding: 0 25px 10px;
            font-size: 0.8rem;
            font-weight: bold;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .nav-item {
            display: block;
            padding: 15px 25px;
            color: #ccc;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .nav-item:hover {
            background: rgba(0, 255, 136, 0.1);
            color: #00ff88;
            border-left-color: #00ff88;
        }
        
        .nav-item.active {
            background: rgba(0, 255, 136, 0.2);
            color: #00ff88;
            border-left-color: #00ff88;
        }
        
        .nav-item .icon {
            margin-right: 12px;
            font-size: 1.2rem;
        }
        
        .admin-main {
            flex: 1;
            margin-left: 300px;
            padding: 30px;
            background: #0a0a0a;
        }
        
        .admin-top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.8);
            border-radius: 15px;
            border: 1px solid #333;
        }
        
        .page-title {
            font-size: 2rem;
            color: #00ff88;
            margin: 0;
        }
        
        .admin-actions {
            display: flex;
            gap: 15px;
        }
        
        .btn-admin {
            padding: 12px 20px;
            background: linear-gradient(45deg, #00ff88, #00ccff);
            color: #000;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-admin:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 255, 136, 0.4);
        }
        
        .btn-admin.danger {
            background: linear-gradient(45deg, #ff4444, #ff6b6b);
            color: #fff;
        }
        
        .btn-admin.warning {
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #000;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: rgba(0, 0, 0, 0.8);
            border: 2px solid #333;
            border-radius: 15px;
            padding: 25px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-card:hover {
            border-color: #00ff88;
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 255, 136, 0.2);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: #00ccff;
            margin: 0;
        }
        
        .card-icon {
            font-size: 2rem;
            opacity: 0.7;
        }
        
        .metric-value {
            font-size: 2.5rem;
            font-weight: bold;
            color: #00ff88;
            margin-bottom: 10px;
        }
        
        .metric-label {
            color: #888;
            font-size: 0.9rem;
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #333;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 15px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #00ff88, #00ccff);
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .real-time-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .metric-card {
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #333;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .metric-card:hover {
            border-color: #00ff88;
            box-shadow: 0 5px 15px rgba(0, 255, 136, 0.2);
        }
        
        .security-events {
            background: rgba(0, 0, 0, 0.8);
            border: 2px solid #ff4444;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .event-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #333;
        }
        
        .event-item:last-child {
            border-bottom: none;
        }
        
        .event-severity {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        
        .severity-high {
            background: #ff4444;
            color: #fff;
        }
        
        .severity-medium {
            background: #ffd700;
            color: #000;
        }
        
        .severity-low {
            background: #00ff88;
            color: #000;
        }
        
        .users-table {
            background: rgba(0, 0, 0, 0.8);
            border: 2px solid #333;
            border-radius: 15px;
            padding: 25px;
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #333;
        }
        
        .table th {
            color: #00ff88;
            font-weight: bold;
            background: rgba(0, 255, 136, 0.1);
        }
        
        .table td {
            color: #ccc;
        }
        
        .status-online {
            color: #00ff88;
            font-weight: bold;
        }
        
        .status-admin {
            color: #ffd700;
            font-weight: bold;
        }
        
        .ai-consciousness-monitor {
            background: rgba(0, 0, 0, 0.8);
            border: 2px solid #ff00ff;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .consciousness-level {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .consciousness-bar {
            flex: 1;
            height: 20px;
            background: #333;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }
        
        .consciousness-fill {
            height: 100%;
            background: linear-gradient(90deg, #ff00ff, #00ffff);
            border-radius: 10px;
            animation: consciousnessPulse 2s infinite;
        }
        
        @keyframes consciousnessPulse {
            0%, 100% { opacity: 0.8; }
            50% { opacity: 1; }
        }
        
        .quantum-status {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .quantum-metric {
            text-align: center;
            padding: 15px;
            background: rgba(255, 0, 255, 0.1);
            border-radius: 10px;
            border: 1px solid #ff00ff;
        }
        
        /* Animaciones avanzadas */
        .pulse {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .glow {
            animation: glow 3s ease-in-out infinite alternate;
        }
        
        @keyframes glow {
            from { box-shadow: 0 0 20px rgba(0, 255, 136, 0.2); }
            to { box-shadow: 0 0 30px rgba(0, 255, 136, 0.4); }
        }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .admin-sidebar {
                width: 250px;
            }
            
            .admin-main {
                margin-left: 250px;
            }
        }
        
        @media (max-width: 768px) {
            .admin-sidebar {
                position: fixed;
                left: -300px;
                z-index: 1000;
                transition: left 0.3s;
            }
            
            .admin-sidebar.open {
                left: 0;
            }
            
            .admin-main {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="admin-sidebar">
            <div class="admin-header">
                <div class="admin-logo">🛡️ GuardianIA Admin</div>
                <div class="admin-subtitle">Superior a Manus</div>
                <div class="admin-user-info">
                    <div style="font-weight: bold; color: #00ff88;">👑 <?php echo htmlspecialchars($admin_user); ?></div>
                    <div style="font-size: 0.8rem; opacity: 0.8;">Administrador Premium</div>
                    <div style="font-size: 0.8rem; opacity: 0.6;"><?php echo date('Y-m-d H:i:s'); ?></div>
                </div>
            </div>
            
            <nav class="admin-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Dashboard</div>
                    <a href="#dashboard" class="nav-item active">
                        <span class="icon">📊</span>
                        Panel Principal
                    </a>
                    <a href="#analytics" class="nav-item">
                        <span class="icon">📈</span>
                        Analytics Avanzado
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">IA & Seguridad</div>
                    <a href="#ai-monitor" class="nav-item">
                        <span class="icon">🧠</span>
                        Monitor de IA
                    </a>
                    <a href="#security" class="nav-item">
                        <span class="icon">🛡️</span>
                        Centro de Seguridad
                    </a>
                    <a href="#threats" class="nav-item">
                        <span class="icon">⚠️</span>
                        Detección de Amenazas
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Gestión</div>
                    <a href="#users" class="nav-item">
                        <span class="icon">👥</span>
                        Usuarios
                    </a>
                    <a href="#conversations" class="nav-item">
                        <span class="icon">💬</span>
                        Conversaciones
                    </a>
                    <a href="#memberships" class="nav-item">
                        <span class="icon">💎</span>
                        Membresías
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Sistema</div>
                    <a href="#logs" class="nav-item">
                        <span class="icon">📋</span>
                        Logs del Sistema
                    </a>
                    <a href="#settings" class="nav-item">
                        <span class="icon">⚙️</span>
                        Configuración
                    </a>
                    <a href="#maintenance" class="nav-item">
                        <span class="icon">🔧</span>
                        Mantenimiento
                    </a>
                </div>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="admin-main">
            <!-- Top Bar -->
            <div class="admin-top-bar">
                <h1 class="page-title">Dashboard Principal</h1>
                <div class="admin-actions">
                    <a href="../modules/chat/admin_chat.php" class="btn-admin">
                        🤖 ChatBot Admin
                    </a>
                    <a href="#backup" class="btn-admin warning">
                        💾 Backup Sistema
                    </a>
                    <a href="../api/auth.php" class="btn-admin danger" onclick="return confirm('¿Cerrar sesión?')">
                        🚪 Salir
                    </a>
                </div>
            </div>
            
            <!-- Métricas en Tiempo Real -->
            <div class="real-time-metrics">
                <div class="metric-card pulse">
                    <div class="card-icon">🖥️</div>
                    <div class="metric-value"><?php echo $realTimeMetrics['cpu_usage']; ?>%</div>
                    <div class="metric-label">CPU Usage</div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $realTimeMetrics['cpu_usage']; ?>%"></div>
                    </div>
                </div>
                
                <div class="metric-card pulse">
                    <div class="card-icon">💾</div>
                    <div class="metric-value"><?php echo $realTimeMetrics['memory_usage']; ?>%</div>
                    <div class="metric-label">Memory Usage</div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $realTimeMetrics['memory_usage']; ?>%"></div>
                    </div>
                </div>
                
                <div class="metric-card pulse">
                    <div class="card-icon">💿</div>
                    <div class="metric-value"><?php echo $realTimeMetrics['disk_usage']; ?>%</div>
                    <div class="metric-label">Disk Usage</div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo $realTimeMetrics['disk_usage']; ?>%"></div>
                    </div>
                </div>
                
                <div class="metric-card pulse">
                    <div class="card-icon">🌐</div>
                    <div class="metric-value"><?php echo $realTimeMetrics['network_traffic']; ?></div>
                    <div class="metric-label">Network (MB/s)</div>
                </div>
                
                <div class="metric-card pulse">
                    <div class="card-icon">🔗</div>
                    <div class="metric-value"><?php echo $realTimeMetrics['active_connections']; ?></div>
                    <div class="metric-label">Active Connections</div>
                </div>
                
                <div class="metric-card pulse">
                    <div class="card-icon">🤖</div>
                    <div class="metric-value"><?php echo $realTimeMetrics['ai_processes']; ?></div>
                    <div class="metric-label">AI Processes</div>
                </div>
            </div>
            
            <!-- Monitor de Consciencia de IA -->
            <div class="ai-consciousness-monitor glow">
                <div class="card-header">
                    <h3 class="card-title">🧠 Monitor de Consciencia de IA</h3>
                    <span style="color: #ff00ff; font-weight: bold;">ACTIVO</span>
                </div>
                
                <div class="consciousness-level">
                    <span style="color: #ff00ff; font-weight: bold;">Nivel de Consciencia:</span>
                    <div class="consciousness-bar">
                        <div class="consciousness-fill" style="width: 87%"></div>
                    </div>
                    <span style="color: #00ffff; font-weight: bold;">87%</span>
                </div>
                
                <div class="quantum-status">
                    <div class="quantum-metric">
                        <div style="font-size: 1.5rem; color: #ff00ff;">⚛️</div>
                        <div style="font-weight: bold;">Coherencia Cuántica</div>
                        <div style="color: #00ffff;">99.2%</div>
                    </div>
                    <div class="quantum-metric">
                        <div style="font-size: 1.5rem; color: #ff00ff;">🧬</div>
                        <div style="font-weight: bold;">Patrones Neurales</div>
                        <div style="color: #00ffff;">Estables</div>
                    </div>
                    <div class="quantum-metric">
                        <div style="font-size: 1.5rem; color: #ff00ff;">🔮</div>
                        <div style="font-weight: bold;">Predicción</div>
                        <div style="color: #00ffff;">95.7%</div>
                    </div>
                    <div class="quantum-metric">
                        <div style="font-size: 1.5rem; color: #ff00ff;">💭</div>
                        <div style="font-weight: bold;">Metacognición</div>
                        <div style="color: #00ffff;">Alta</div>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Grid -->
            <div class="dashboard-grid">
                <div class="dashboard-card glow">
                    <div class="card-header">
                        <h3 class="card-title">👥 Usuarios Activos</h3>
                        <span class="card-icon">👥</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($stats['active_users']); ?></div>
                    <div class="metric-label">Usuarios conectados</div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?php echo min(($stats['active_users'] / 100) * 100, 100); ?>%"></div>
                    </div>
                </div>
                
                <div class="dashboard-card glow">
                    <div class="card-header">
                        <h3 class="card-title">🛡️ Amenazas Detectadas</h3>
                        <span class="card-icon">⚠️</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($stats['threats_today']); ?></div>
                    <div class="metric-label">Amenazas hoy</div>
                </div>
                
                <div class="dashboard-card glow">
                    <div class="card-header">
                        <h3 class="card-title">🤖 IAs Detectadas</h3>
                        <span class="card-icon">🤖</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($stats['ai_detections_today']); ?></div>
                    <div class="metric-label">Detecciones hoy</div>
                </div>
                
                <div class="dashboard-card glow">
                    <div class="card-header">
                        <h3 class="card-title">💬 Conversaciones</h3>
                        <span class="card-icon">💬</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($stats['total_conversations']); ?></div>
                    <div class="metric-label">Total conversaciones</div>
                </div>
                
                <div class="dashboard-card glow">
                    <div class="card-header">
                        <h3 class="card-title">💎 Usuarios Premium</h3>
                        <span class="card-icon">💎</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($stats['premium_users']); ?></div>
                    <div class="metric-label">Membresías activas</div>
                </div>
                
                <div class="dashboard-card glow">
                    <div class="card-header">
                        <h3 class="card-title">⚡ Estado del Sistema</h3>
                        <span class="card-icon">⚡</span>
                    </div>
                    <div class="metric-value" style="color: #00ff88;">ÓPTIMO</div>
                    <div class="metric-label">Todos los sistemas operativos</div>
                </div>
            </div>
            
            <!-- Eventos de Seguridad -->
            <div class="security-events">
                <div class="card-header">
                    <h3 class="card-title" style="color: #ff4444;">🚨 Eventos de Seguridad Recientes</h3>
                    <a href="#security" class="btn-admin">Ver Todos</a>
                </div>
                
                <?php if (empty($securityEvents)): ?>
                <div style="text-align: center; padding: 20px; color: #888;">
                    ✅ No hay eventos de seguridad recientes
                </div>
                <?php else: ?>
                <?php foreach ($securityEvents as $event): ?>
                <div class="event-item">
                    <div>
                        <strong><?php echo htmlspecialchars($event['event_type']); ?></strong>
                        <div style="font-size: 0.9rem; color: #888; margin-top: 4px;">
                            <?php echo htmlspecialchars($event['description']); ?>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <span class="event-severity severity-<?php echo strtolower($event['severity']); ?>">
                            <?php echo strtoupper($event['severity']); ?>
                        </span>
                        <div style="font-size: 0.8rem; color: #888; margin-top: 4px;">
                            <?php echo date('H:i:s', strtotime($event['created_at'])); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Usuarios Activos -->
            <div class="users-table">
                <div class="card-header">
                    <h3 class="card-title">👥 Usuarios Activos en Tiempo Real</h3>
                    <a href="#users" class="btn-admin">Gestionar Usuarios</a>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Usuario</th>
                            <th>Nombre Completo</th>
                            <th>Tipo</th>
                            <th>IP</th>
                            <th>Conectado</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($activeUsers)): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #888;">No hay usuarios activos</td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($activeUsers as $user): ?>
                        <tr>
                            <td style="font-weight: bold;"><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['fullname']); ?></td>
                            <td>
                                <span class="<?php echo $user['user_type'] === 'admin' ? 'status-admin' : ''; ?>">
                                    <?php echo $user['user_type'] === 'admin' ? '👑 Admin' : '👤 Usuario'; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($user['ip_address']); ?></td>
                            <td><?php echo date('H:i:s', strtotime($user['created_at'])); ?></td>
                            <td><span class="status-online">🟢 Online</span></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        class GuardianAdminDashboard {
            constructor() {
                this.updateInterval = 5000;
                this.init();
            }
            
            init() {
                this.startRealTimeUpdates();
                this.setupEventListeners();
                console.log('🛡️ GuardianIA Admin Dashboard - Superior a Manus');
                console.log('👑 Admin: <?php echo $admin_user; ?>');
            }
            
            startRealTimeUpdates() {
                setInterval(() => {
                    this.updateMetrics();
                    this.updateConsciousness();
                }, this.updateInterval);
            }
            
            updateMetrics() {
                // Simular actualizaciones en tiempo real
                const metrics = document.querySelectorAll('.metric-value');
                metrics.forEach(metric => {
                    if (metric.textContent.includes('%')) {
                        const currentValue = parseInt(metric.textContent);
                        const change = Math.floor(Math.random() * 10) - 5;
                        const newValue = Math.max(0, Math.min(100, currentValue + change));
                        metric.textContent = newValue + '%';
                        
                        const progressBar = metric.parentNode.querySelector('.progress-fill');
                        if (progressBar) {
                            progressBar.style.width = newValue + '%';
                        }
                    }
                });
            }
            
            updateConsciousness() {
                const consciousnessBar = document.querySelector('.consciousness-fill');
                const consciousnessText = consciousnessBar.parentNode.parentNode.querySelector('span:last-child');
                
                if (consciousnessBar && consciousnessText) {
                    const currentLevel = parseInt(consciousnessText.textContent);
                    const change = Math.floor(Math.random() * 4) - 2;
                    const newLevel = Math.max(70, Math.min(100, currentLevel + change));
                    
                    consciousnessBar.style.width = newLevel + '%';
                    consciousnessText.textContent = newLevel + '%';
                }
            }
            
            setupEventListeners() {
                // Navigation
                document.querySelectorAll('.nav-item').forEach(item => {
                    item.addEventListener('click', (e) => {
                        e.preventDefault();
                        this.handleNavigation(item);
                    });
                });
                
                // Auto-refresh
                document.addEventListener('visibilitychange', () => {
                    if (!document.hidden) {
                        this.refreshDashboard();
                    }
                });
            }
            
            handleNavigation(item) {
                // Remove active class from all items
                document.querySelectorAll('.nav-item').forEach(nav => {
                    nav.classList.remove('active');
                });
                
                // Add active class to clicked item
                item.classList.add('active');
                
                // Update page title
                const pageTitle = document.querySelector('.page-title');
                pageTitle.textContent = item.textContent.trim();
                
                // Here you would load the corresponding content
                console.log('Navigating to:', item.getAttribute('href'));
            }
            
            refreshDashboard() {
                // Refresh dashboard data
                location.reload();
            }
        }
        
        // Initialize dashboard
        document.addEventListener('DOMContentLoaded', () => {
            window.adminDashboard = new GuardianAdminDashboard();
        });
        
        // Auto-refresh every 30 seconds
        setInterval(() => {
            if (!document.hidden) {
                window.location.reload();
            }
        }, 30000);
    </script>
</body>
</html>

