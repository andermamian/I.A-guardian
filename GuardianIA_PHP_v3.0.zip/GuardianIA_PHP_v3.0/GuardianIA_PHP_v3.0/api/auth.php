<?php
/**
 * GuardianIA v3.0 FINAL - API de Autenticación
 * Anderson Mamian Chicangana - Membresía Premium
 * Sistema Completamente Sincronizado
 */

require_once '../config/config.php';
require_once '../config/database.php';

header('Content-Type: application/json');
header('X-Powered-By: GuardianIA v3.0 FINAL');

class AuthAPI {
    private $db;
    
    public function __construct() {
        $this->db = DatabaseConfig::getInstance();
    }
    
    public function handleRequest() {
        try {
            // Verificar método
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método no permitido');
            }
            
            // Verificar token CSRF
            if (!$this->validateCSRF()) {
                throw new Exception('Token CSRF inválido');
            }
            
            $action = $_POST['action'] ?? '';
            
            switch ($action) {
                case 'login':
                    return $this->login();
                case 'register':
                    return $this->register();
                case 'logout':
                    return $this->logout();
                case 'check_session':
                    return $this->checkSession();
                default:
                    throw new Exception('Acción no válida');
            }
            
        } catch (Exception $e) {
            logEvent('ERROR', 'Auth API Error: ' . $e->getMessage());
            return $this->jsonResponse(false, $e->getMessage());
        }
    }
    
    private function login() {
        $username = sanitizeInput($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember_me']);
        
        if (empty($username) || empty($password)) {
            throw new Exception('Usuario y contraseña son requeridos');
        }
        
        // Verificar intentos de login
        if ($this->isLoginBlocked($username)) {
            throw new Exception('Demasiados intentos fallidos. Intenta en 15 minutos.');
        }
        
        // Buscar usuario
        $result = $this->db->executeQuery(
            "SELECT id, username, password_hash, fullname, email, user_type, status FROM users WHERE username = ? OR email = ?",
            [$username, $username]
        );
        
        if (!$result || $result->num_rows === 0) {
            $this->recordFailedLogin($username);
            throw new Exception('Credenciales incorrectas');
        }
        
        $user = $result->fetch_assoc();
        
        // Verificar contraseña
        if (!password_verify($password, $user['password_hash'])) {
            $this->recordFailedLogin($username);
            throw new Exception('Credenciales incorrectas');
        }
        
        // Verificar estado del usuario
        if ($user['status'] !== 'active') {
            throw new Exception('Cuenta desactivada');
        }
        
        // Crear sesión
        $this->createSession($user, $remember);
        
        // Limpiar intentos fallidos
        $this->clearFailedLogins($username);
        
        // Log del login exitoso
        logEvent('INFO', 'Login exitoso', [
            'user_id' => $user['id'],
            'username' => $user['username'],
            'user_type' => $user['user_type']
        ]);
        
        return $this->jsonResponse(true, 'Login exitoso', [
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'fullname' => $user['fullname'],
                'email' => $user['email'],
                'user_type' => $user['user_type']
            ],
            'redirect' => $user['user_type'] === 'admin' ? 'admin/' : 'modules/dashboard.php'
        ]);
    }
    
    private function register() {
        $fullname = sanitizeInput($_POST['fullname'] ?? '');
        $email = sanitizeInput($_POST['email'] ?? '');
        $username = sanitizeInput($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $acceptTerms = isset($_POST['accept_terms']);
        
        // Validaciones
        if (empty($fullname) || empty($email) || empty($username) || empty($password)) {
            throw new Exception('Todos los campos son requeridos');
        }
        
        if (!$acceptTerms) {
            throw new Exception('Debes aceptar los términos y condiciones');
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Email inválido');
        }
        
        if (strlen($password) < 6) {
            throw new Exception('La contraseña debe tener al menos 6 caracteres');
        }
        
        if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
            throw new Exception('Usuario debe tener 3-20 caracteres (letras, números, _)');
        }
        
        // Verificar si el usuario ya existe
        $result = $this->db->executeQuery(
            "SELECT id FROM users WHERE username = ? OR email = ?",
            [$username, $email]
        );
        
        if ($result && $result->num_rows > 0) {
            throw new Exception('Usuario o email ya existe');
        }
        
        // Crear usuario
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $userId = $this->createUser($fullname, $email, $username, $passwordHash);
        
        // Log del registro
        logEvent('INFO', 'Usuario registrado', [
            'user_id' => $userId,
            'username' => $username,
            'email' => $email
        ]);
        
        return $this->jsonResponse(true, 'Usuario registrado exitosamente', [
            'user_id' => $userId,
            'message' => 'Ahora puedes iniciar sesión'
        ]);
    }
    
    private function logout() {
        // Destruir sesión
        if (isset($_SESSION['user_id'])) {
            logEvent('INFO', 'Logout', ['user_id' => $_SESSION['user_id']]);
        }
        
        session_destroy();
        
        return $this->jsonResponse(true, 'Sesión cerrada exitosamente');
    }
    
    private function checkSession() {
        if (isset($_SESSION['user_id'])) {
            $result = $this->db->executeQuery(
                "SELECT id, username, fullname, email, user_type FROM users WHERE id = ? AND status = 'active'",
                [$_SESSION['user_id']]
            );
            
            if ($result && $result->num_rows > 0) {
                $user = $result->fetch_assoc();
                return $this->jsonResponse(true, 'Sesión válida', ['user' => $user]);
            }
        }
        
        return $this->jsonResponse(false, 'Sesión inválida');
    }
    
    private function createUser($fullname, $email, $username, $passwordHash) {
        $conn = $this->db->getConnection();
        
        $stmt = $conn->prepare(
            "INSERT INTO users (fullname, email, username, password_hash, user_type, status, created_at) VALUES (?, ?, ?, ?, 'user', 'active', NOW())"
        );
        
        $stmt->bind_param('ssss', $fullname, $email, $username, $passwordHash);
        
        if (!$stmt->execute()) {
            throw new Exception('Error creando usuario: ' . $stmt->error);
        }
        
        return $conn->insert_id;
    }
    
    private function createSession($user, $remember = false) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['user_type'] = $user['user_type'];
        $_SESSION['login_time'] = time();
        
        // Regenerar ID de sesión por seguridad
        session_regenerate_id(true);
        
        // Si "recordarme" está marcado, extender la sesión
        if ($remember) {
            ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
            session_set_cookie_params(SESSION_LIFETIME);
        }
        
        // Guardar sesión en base de datos
        $this->saveSessionToDB($user['id']);
    }
    
    private function saveSessionToDB($userId) {
        $sessionId = session_id();
        $expiresAt = date('Y-m-d H:i:s', time() + SESSION_LIFETIME);
        
        $this->db->executeQuery(
            "INSERT INTO user_sessions (user_id, session_id, ip_address, user_agent, expires_at, created_at) VALUES (?, ?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE expires_at = VALUES(expires_at)",
            [
                $userId,
                $sessionId,
                $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
                $expiresAt
            ]
        );
    }
    
    private function isLoginBlocked($username) {
        $result = $this->db->executeQuery(
            "SELECT COUNT(*) as attempts FROM login_attempts WHERE username = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
            [$username]
        );
        
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['attempts'] >= MAX_LOGIN_ATTEMPTS;
        }
        
        return false;
    }
    
    private function recordFailedLogin($username) {
        $this->db->executeQuery(
            "INSERT INTO login_attempts (username, ip_address, attempted_at) VALUES (?, ?, NOW())",
            [$username, $_SERVER['REMOTE_ADDR'] ?? 'unknown']
        );
    }
    
    private function clearFailedLogins($username) {
        $this->db->executeQuery(
            "DELETE FROM login_attempts WHERE username = ?",
            [$username]
        );
    }
    
    private function validateCSRF() {
        $token = $_POST['csrf_token'] ?? '';
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    private function jsonResponse($success, $message, $data = null) {
        $response = [
            'success' => $success,
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Crear tabla de intentos de login si no existe
try {
    $db = DatabaseConfig::getInstance();
    $db->executeQuery("
        CREATE TABLE IF NOT EXISTS login_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_username_time (username, attempted_at)
        )
    ");
} catch (Exception $e) {
    logEvent('ERROR', 'Error creando tabla login_attempts: ' . $e->getMessage());
}

// Procesar request
$auth = new AuthAPI();
$auth->handleRequest();
?>

