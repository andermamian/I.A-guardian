<?php
session_start();
require_once 'config.php';

// Verificar admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit;
}

class AdminDashboard {
    private $db;
    
    public function __construct($connection) {
        $this->db = $connection;
    }
    
    public function getSystemStats() {
        $stats = [
            'total_users' => $this->getTotalUsers(),
            'active_sessions' => $this->getActiveSessions(),
            'system_health' => $this->getSystemHealth(),
            'threat_level' => $this->getThreatLevel(),
            'ai_detections' => $this->getAIDetections(),
            'revenue' => $this->getRevenue(),
            'cpu_usage' => rand(15, 85),
            'memory_usage' => rand(40, 90),
            'uptime' => $this->getUptime()
        ];
        return $stats;
    }
    
    private function getTotalUsers() {
        $result = $this->db->query("SELECT COUNT(*) as count FROM users");
        return $result ? $result->fetch_assoc()['count'] : 0;
    }
    
    private function getActiveSessions() {
        $result = $this->db->query("SELECT COUNT(*) as count FROM user_sessions WHERE last_activity > DATE_SUB(NOW(), INTERVAL 30 MINUTE)");
        return $result ? $result->fetch_assoc()['count'] : 0;
    }
    
    private function getSystemHealth() {
        return rand(85, 99);
    }
    
    private function getThreatLevel() {
        return rand(0, 3);
    }
    
    private function getAIDetections() {
        $result = $this->db->query("SELECT COUNT(*) as count FROM ai_detections WHERE DATE(timestamp) = CURDATE()");
        return $result ? $result->fetch_assoc()['count'] : 0;
    }
    
    private function getRevenue() {
        $result = $this->db->query("SELECT SUM(amount) as total FROM payments WHERE MONTH(created_at) = MONTH(NOW())");
        return $result ? ($result->fetch_assoc()['total'] ?? 0) : 0;
    }
    
    private function getUptime() {
        return "99.9%";
    }
}

$admin = new AdminDashboard($conn);
$stats = $admin->getSystemStats();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'get_stats') {
        echo json_encode($stats);
        exit;
    }
    
    if ($_POST['action'] === 'system_action') {
        $action = $_POST['system_action'];
        $result = ['success' => true, 'message' => 'Acción ejecutada: ' . $action];
        echo json_encode($result);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA Admin Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
            color: #00ff88;
            min-height: 100vh;
        }
        
        .admin-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .admin-header {
            background: rgba(0, 255, 136, 0.1);
            border: 1px solid #00ff88;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .admin-header h1 {
            font-size: 2.5em;
            text-shadow: 0 0 20px #00ff88;
            margin-bottom: 10px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: rgba(0, 255, 136, 0.1);
            border: 1px solid #00ff88;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
        }
        
        .stat-value {
            font-size: 2.5em;
            font-weight: bold;
            color: #00ff88;
            text-shadow: 0 0 10px #00ff88;
        }
        
        .stat-label {
            font-size: 1.1em;
            margin-top: 10px;
            opacity: 0.8;
        }
        
        .controls-section {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid #00ff88;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
        }
        
        .controls-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .control-btn {
            background: linear-gradient(45deg, #00ff88, #00cc6a);
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .control-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 255, 136, 0.4);
        }
        
        .control-btn.danger {
            background: linear-gradient(45deg, #ff4444, #cc0000);
            color: #fff;
        }
        
        .monitoring-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .monitor-panel {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid #00ff88;
            border-radius: 15px;
            padding: 20px;
        }
        
        .progress-bar {
            background: rgba(0, 0, 0, 0.5);
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #00ff88, #00cc6a);
            transition: width 0.5s ease;
        }
        
        .users-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .users-table th, .users-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid rgba(0, 255, 136, 0.3);
        }
        
        .users-table th {
            background: rgba(0, 255, 136, 0.2);
        }
        
        .status-online { color: #00ff88; }
        .status-offline { color: #ff4444; }
        
        @media (max-width: 768px) {
            .monitoring-section { grid-template-columns: 1fr; }
            .stats-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1>🛡️ GuardianIA Admin Dashboard</h1>
            <p>Centro de Control y Monitoreo del Sistema</p>
            <div style="margin-top: 15px;">
                <span>Admin: <?php echo $_SESSION['username']; ?></span> | 
                <a href="logout.php" style="color: #ff4444;">Cerrar Sesión</a>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value" id="totalUsers"><?php echo $stats['total_users']; ?></div>
                <div class="stat-label">👥 Usuarios Totales</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="activeSessions"><?php echo $stats['active_sessions']; ?></div>
                <div class="stat-label">🟢 Sesiones Activas</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="systemHealth"><?php echo $stats['system_health']; ?>%</div>
                <div class="stat-label">💚 Salud del Sistema</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="threatLevel"><?php echo $stats['threat_level']; ?>/10</div>
                <div class="stat-label">⚠️ Nivel de Amenaza</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="aiDetections"><?php echo $stats['ai_detections']; ?></div>
                <div class="stat-label">🤖 IAs Detectadas Hoy</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="revenue">$<?php echo number_format($stats['revenue']); ?></div>
                <div class="stat-label">💰 Ingresos del Mes</div>
            </div>
        </div>

        <div class="controls-section">
            <h3>🎛️ Controles del Sistema</h3>
            <div class="controls-grid">
                <button class="control-btn" onclick="systemAction('security_scan')">🔍 Escaneo de Seguridad</button>
                <button class="control-btn" onclick="systemAction('backup_system')">💾 Backup del Sistema</button>
                <button class="control-btn" onclick="systemAction('update_system')">🔄 Actualizar Sistema</button>
                <button class="control-btn" onclick="systemAction('optimize_performance')">⚡ Optimizar Rendimiento</button>
                <button class="control-btn" onclick="systemAction('generate_report')">📊 Generar Reporte</button>
                <button class="control-btn" onclick="systemAction('maintenance_mode')">🔧 Modo Mantenimiento</button>
                <button class="control-btn danger" onclick="systemAction('emergency_shutdown')">🚨 Apagado de Emergencia</button>
                <button class="control-btn danger" onclick="systemAction('system_restart')">🔄 Reiniciar Sistema</button>
            </div>
        </div>

        <div class="monitoring-section">
            <div class="monitor-panel">
                <h3>📊 Monitoreo de Recursos</h3>
                
                <div>CPU Usage: <span id="cpuValue"><?php echo $stats['cpu_usage']; ?>%</span></div>
                <div class="progress-bar">
                    <div class="progress-fill" id="cpuProgress" style="width: <?php echo $stats['cpu_usage']; ?>%"></div>
                </div>
                
                <div>Memory Usage: <span id="memoryValue"><?php echo $stats['memory_usage']; ?>%</span></div>
                <div class="progress-bar">
                    <div class="progress-fill" id="memoryProgress" style="width: <?php echo $stats['memory_usage']; ?>%"></div>
                </div>
                
                <div>System Uptime: <span id="uptimeValue"><?php echo $stats['uptime']; ?></span></div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 99%"></div>
                </div>
            </div>

            <div class="monitor-panel">
                <h3>👥 Usuarios Recientes</h3>
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>Usuario</th>
                            <th>Estado</th>
                            <th>Última Actividad</th>
                        </tr>
                    </thead>
                    <tbody id="usersTable">
                        <tr>
                            <td>admin</td>
                            <td><span class="status-online">● Online</span></td>
                            <td>Ahora</td>
                        </tr>
                        <tr>
                            <td>user_demo</td>
                            <td><span class="status-online">● Online</span></td>
                            <td>5 min</td>
                        </tr>
                        <tr>
                            <td>test_user</td>
                            <td><span class="status-offline">● Offline</span></td>
                            <td>1 hora</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function systemAction(action) {
            if (action === 'emergency_shutdown' || action === 'system_restart') {
                if (!confirm('¿Estás seguro de ejecutar: ' + action + '?')) {
                    return;
                }
            }
            
            fetch('admin_dashboard.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=system_action&system_action=${action}`
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error ejecutando acción');
            });
        }

        function updateStats() {
            fetch('admin_dashboard.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=get_stats'
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('totalUsers').textContent = data.total_users;
                document.getElementById('activeSessions').textContent = data.active_sessions;
                document.getElementById('systemHealth').textContent = data.system_health + '%';
                document.getElementById('threatLevel').textContent = data.threat_level + '/10';
                document.getElementById('aiDetections').textContent = data.ai_detections;
                document.getElementById('revenue').textContent = '$' + data.revenue.toLocaleString();
                
                document.getElementById('cpuValue').textContent = data.cpu_usage + '%';
                document.getElementById('cpuProgress').style.width = data.cpu_usage + '%';
                document.getElementById('memoryValue').textContent = data.memory_usage + '%';
                document.getElementById('memoryProgress').style.width = data.memory_usage + '%';
            })
            .catch(error => console.error('Error updating stats:', error));
        }

        // Actualizar estadísticas cada 30 segundos
        setInterval(updateStats, 30000);
    </script>
</body>
</html>

