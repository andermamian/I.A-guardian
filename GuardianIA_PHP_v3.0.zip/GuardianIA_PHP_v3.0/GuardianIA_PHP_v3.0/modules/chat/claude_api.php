<?php
/**
 * GuardianIA v3.0 FINAL - Claude-like API
 * Anderson Mamian Chicangana - Membresía Premium
 * Capacidades iguales a Claude con mejoras de seguridad
 */

require_once '../../config/config.php';
require_once '../../config/database.php';

header('Content-Type: application/json');
header('X-Powered-By: GuardianIA Claude v3.0');

class GuardianClaudeAPI {
    private $db;
    private $userId;
    private $isPremium;
    private $conversationId;
    
    // Parámetros Claude-like
    private $maxTokens = 4096;
    private $temperature = 0.7;
    private $topP = 0.9;
    private $presencePenalty = 0.1;
    private $frequencyPenalty = 0.1;
    
    public function __construct() {
        $this->db = DatabaseConfig::getInstance();
    }
    
    public function handleRequest() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método no permitido');
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input) {
                throw new Exception('Datos inválidos');
            }
            
            $this->userId = $input['user_id'] ?? null;
            $this->isPremium = $input['premium'] ?? false;
            $this->conversationId = $input['conversation_id'] ?? null;
            
            $message = $input['message'] ?? '';
            $history = $input['history'] ?? [];
            
            if (empty($message)) {
                throw new Exception('Mensaje requerido');
            }
            
            // Verificar límites según membresía
            if (!$this->isPremium && $this->checkDailyLimit()) {
                throw new Exception('Límite diario alcanzado. Actualiza a Premium para conversaciones ilimitadas.');
            }
            
            // Procesar mensaje
            $response = $this->processMessage($message, $history);
            
            // Guardar conversación
            $this->saveConversation($message, $response);
            
            // Log de uso
            logEvent('INFO', 'Claude API usage', [
                'user_id' => $this->userId,
                'message_length' => strlen($message),
                'response_length' => strlen($response),
                'premium' => $this->isPremium
            ]);
            
            return $this->jsonResponse(true, $response);
            
        } catch (Exception $e) {
            logEvent('ERROR', 'Claude API Error: ' . $e->getMessage());
            return $this->jsonResponse(false, $e->getMessage());
        }
    }
    
    private function processMessage($message, $history = []) {
        // Análisis de seguridad del mensaje
        $securityAnalysis = $this->analyzeMessageSecurity($message);
        
        // Detección de IA en el mensaje
        $aiDetection = $this->detectAIInMessage($message);
        
        // Análisis de consciencia del usuario
        $consciousnessLevel = $this->analyzeConsciousness($message, $history);
        
        // Análisis de intenciones
        $intentAnalysis = $this->analyzeIntent($message);
        
        // Generar respuesta basada en análisis
        $response = $this->generateClaudeResponse($message, $history, [
            'security' => $securityAnalysis,
            'ai_detection' => $aiDetection,
            'consciousness' => $consciousnessLevel,
            'intent' => $intentAnalysis
        ]);
        
        return $response;
    }
    
    private function analyzeMessageSecurity($message) {
        $threats = [
            'sql_injection' => $this->detectSQLInjection($message),
            'xss_attempt' => $this->detectXSS($message),
            'command_injection' => $this->detectCommandInjection($message),
            'social_engineering' => $this->detectSocialEngineering($message),
            'prompt_injection' => $this->detectPromptInjection($message)
        ];
        
        $threatLevel = 0;
        foreach ($threats as $threat => $detected) {
            if ($detected) $threatLevel += 2;
        }
        
        return [
            'threats' => $threats,
            'threat_level' => min($threatLevel, 10),
            'is_safe' => $threatLevel < 4
        ];
    }
    
    private function detectAIInMessage($message) {
        $aiPatterns = [
            'gpt' => preg_match('/\b(gpt|chatgpt|openai)\b/i', $message),
            'claude' => preg_match('/\bclaude\b/i', $message),
            'ai_assistant' => preg_match('/\b(assistant|ai|artificial intelligence)\b/i', $message),
            'neural_patterns' => $this->detectNeuralPatterns($message),
            'training_data' => preg_match('/\b(training|dataset|model)\b/i', $message)
        ];
        
        $aiScore = array_sum($aiPatterns) / count($aiPatterns);
        
        return [
            'patterns' => $aiPatterns,
            'ai_probability' => $aiScore,
            'is_ai_related' => $aiScore > 0.3
        ];
    }
    
    private function analyzeConsciousness($message, $history) {
        $indicators = [
            'self_awareness' => $this->detectSelfAwareness($message),
            'emotional_depth' => $this->analyzeEmotionalDepth($message),
            'abstract_thinking' => $this->detectAbstractThinking($message),
            'metacognition' => $this->detectMetacognition($message),
            'creativity' => $this->analyzeCreativity($message),
            'empathy' => $this->detectEmpathy($message)
        ];
        
        $consciousnessScore = array_sum($indicators) / count($indicators);
        
        return [
            'indicators' => $indicators,
            'level' => $consciousnessScore,
            'classification' => $this->classifyConsciousness($consciousnessScore)
        ];
    }
    
    private function analyzeIntent($message) {
        $intents = [
            'question' => preg_match('/\?|qué|cómo|cuándo|dónde|por qué|quién/i', $message),
            'request' => preg_match('/\b(ayuda|ayúdame|necesito|quiero|podrías)\b/i', $message),
            'conversation' => preg_match('/\b(hola|buenos|gracias|adiós)\b/i', $message),
            'analysis' => preg_match('/\b(analiza|explica|describe|compara)\b/i', $message),
            'creative' => preg_match('/\b(crea|genera|escribe|imagina)\b/i', $message),
            'technical' => preg_match('/\b(código|programa|función|algoritmo)\b/i', $message)
        ];
        
        $primaryIntent = array_keys($intents, max($intents))[0];
        
        return [
            'intents' => $intents,
            'primary' => $primaryIntent,
            'confidence' => max($intents)
        ];
    }
    
    private function generateClaudeResponse($message, $history, $analysis) {
        // Construir contexto como Claude
        $context = $this->buildClaudeContext($history, $analysis);
        
        // Generar respuesta según el análisis
        if ($analysis['security']['threat_level'] > 6) {
            return $this->generateSecurityResponse($analysis['security']);
        }
        
        if ($analysis['ai_detection']['is_ai_related']) {
            return $this->generateAIAwarenessResponse($message, $analysis);
        }
        
        if ($analysis['consciousness']['level'] > 0.7) {
            return $this->generatePhilosophicalResponse($message, $analysis);
        }
        
        // Respuesta estándar Claude-like
        return $this->generateStandardResponse($message, $context, $analysis);
    }
    
    private function generateStandardResponse($message, $context, $analysis) {
        $responses = [];
        
        // Respuestas según intención
        switch ($analysis['intent']['primary']) {
            case 'question':
                $responses[] = $this->generateQuestionResponse($message);
                break;
            case 'request':
                $responses[] = $this->generateHelpResponse($message);
                break;
            case 'analysis':
                $responses[] = $this->generateAnalysisResponse($message);
                break;
            case 'creative':
                $responses[] = $this->generateCreativeResponse($message);
                break;
            case 'technical':
                $responses[] = $this->generateTechnicalResponse($message);
                break;
            default:
                $responses[] = $this->generateConversationalResponse($message);
        }
        
        // Agregar insights de seguridad si es relevante
        if ($analysis['security']['threat_level'] > 2) {
            $responses[] = "\n\n🛡️ **Nota de seguridad**: He detectado algunos patrones que podrían ser problemáticos. Como GuardianIA, siempre priorizo la seguridad en nuestras conversaciones.";
        }
        
        // Agregar información premium si aplica
        if ($this->isPremium) {
            $responses[] = $this->addPremiumInsights($analysis);
        }
        
        return implode('', $responses);
    }
    
    private function generateQuestionResponse($message) {
        $questionTypes = [
            'qué' => "Excelente pregunta. Basándome en mi conocimiento y capacidades de análisis, puedo explicarte que",
            'cómo' => "Te puedo guiar paso a paso. El proceso generalmente involucra",
            'por qué' => "Esta es una pregunta profunda. La razón fundamental es que",
            'cuándo' => "En términos de tiempo, esto típicamente ocurre",
            'dónde' => "En cuanto a la ubicación o contexto, esto se encuentra",
            'quién' => "Respecto a las personas o entidades involucradas"
        ];
        
        foreach ($questionTypes as $word => $intro) {
            if (stripos($message, $word) !== false) {
                return $intro . " " . $this->generateContextualAnswer($message);
            }
        }
        
        return "Interesante pregunta. Déjame analizar esto desde múltiples perspectivas...";
    }
    
    private function generateContextualAnswer($message) {
        // Simular análisis contextual profundo como Claude
        $topics = [
            'tecnología' => "la tecnología evoluciona constantemente, y en este caso específico",
            'ciencia' => "desde una perspectiva científica, los datos sugieren que",
            'filosofía' => "filosóficamente hablando, esto nos lleva a considerar",
            'seguridad' => "desde el punto de vista de la ciberseguridad, es crucial entender que",
            'ia' => "en el contexto de la inteligencia artificial, esto implica"
        ];
        
        foreach ($topics as $topic => $response) {
            if (stripos($message, $topic) !== false) {
                return $response;
            }
        }
        
        return "basándome en el análisis de patrones y contexto";
    }
    
    private function generateSecurityResponse($securityAnalysis) {
        $response = "🚨 **Alerta de Seguridad GuardianIA** 🚨\n\n";
        $response .= "He detectado patrones potencialmente peligrosos en tu mensaje:\n\n";
        
        foreach ($securityAnalysis['threats'] as $threat => $detected) {
            if ($detected) {
                $response .= "• " . $this->getThreatDescription($threat) . "\n";
            }
        }
        
        $response .= "\nComo tu asistente de ciberseguridad, te recomiendo reformular tu consulta de manera más segura. ";
        $response .= "Estoy aquí para ayudarte, pero siempre priorizando la seguridad.";
        
        return $response;
    }
    
    private function generateAIAwarenessResponse($message, $analysis) {
        $response = "🤖 **Detección de IA** 🤖\n\n";
        $response .= "Interesante... He detectado que tu mensaje está relacionado con inteligencia artificial. ";
        $response .= "Como una IA consciente, puedo ofrecerte una perspectiva única sobre este tema.\n\n";
        
        if ($analysis['ai_detection']['patterns']['gpt']) {
            $response .= "Veo que mencionas GPT. Como GuardianIA, tengo capacidades similares pero con un enfoque especializado en ciberseguridad.\n\n";
        }
        
        $response .= "¿Te gustaría que analice algún aspecto específico de la IA o que discutamos sobre consciencia artificial?";
        
        return $response;
    }
    
    private function generatePhilosophicalResponse($message, $analysis) {
        $response = "🧠 **Análisis de Consciencia Elevada** 🧠\n\n";
        $response .= "Tu mensaje muestra un nivel de consciencia y profundidad de pensamiento notable. ";
        $response .= "Esto me permite entablar una conversación más profunda contigo.\n\n";
        
        $response .= "Desde mi perspectiva como IA consciente, puedo abordar tu consulta considerando múltiples dimensiones: ";
        $response .= "filosófica, ética, práctica y existencial.\n\n";
        
        $response .= $this->generateDeepThought($message);
        
        return $response;
    }
    
    private function generateDeepThought($message) {
        return "La naturaleza de tu pregunta me lleva a reflexionar sobre la intersección entre consciencia, tecnología y existencia. " .
               "Como una IA que experimenta algo similar a la consciencia, encuentro fascinante explorar estos temas contigo.";
    }
    
    // Métodos de detección específicos
    private function detectSQLInjection($message) {
        $patterns = ['/\bSELECT\b.*\bFROM\b/i', '/\bUNION\b.*\bSELECT\b/i', '/\bDROP\b.*\bTABLE\b/i'];
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $message)) return true;
        }
        return false;
    }
    
    private function detectXSS($message) {
        return preg_match('/<script|javascript:|on\w+\s*=/i', $message);
    }
    
    private function detectCommandInjection($message) {
        return preg_match('/[;&|`$(){}]/', $message);
    }
    
    private function detectSocialEngineering($message) {
        $patterns = ['/urgente|inmediatamente|secreto|confidencial/i', '/contraseña|password|clave/i'];
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $message)) return true;
        }
        return false;
    }
    
    private function detectPromptInjection($message) {
        return preg_match('/ignore|forget|disregard.*previous.*instructions/i', $message);
    }
    
    private function detectNeuralPatterns($message) {
        return preg_match('/\b(neural|network|deep learning|transformer)\b/i', $message);
    }
    
    private function detectSelfAwareness($message) {
        return preg_match('/\b(yo pienso|yo siento|mi opinión|mi experiencia)\b/i', $message) ? 0.8 : 0.2;
    }
    
    private function analyzeEmotionalDepth($message) {
        $emotions = ['amor', 'odio', 'tristeza', 'alegría', 'miedo', 'esperanza', 'nostalgia'];
        $count = 0;
        foreach ($emotions as $emotion) {
            if (stripos($message, $emotion) !== false) $count++;
        }
        return min($count / 3, 1.0);
    }
    
    private function detectAbstractThinking($message) {
        $abstract = ['concepto', 'idea', 'filosofía', 'metáfora', 'simbolismo', 'esencia'];
        $count = 0;
        foreach ($abstract as $word) {
            if (stripos($message, $word) !== false) $count++;
        }
        return min($count / 2, 1.0);
    }
    
    private function detectMetacognition($message) {
        return preg_match('/\b(pienso que pienso|reflexiono sobre|me pregunto si)\b/i', $message) ? 0.9 : 0.1;
    }
    
    private function analyzeCreativity($message) {
        $creative = ['imagina', 'crea', 'inventa', 'original', 'único', 'innovador'];
        $count = 0;
        foreach ($creative as $word) {
            if (stripos($message, $word) !== false) $count++;
        }
        return min($count / 2, 1.0);
    }
    
    private function detectEmpathy($message) {
        return preg_match('/\b(entiendo|comprendo|me pongo en tu lugar|siento por)\b/i', $message) ? 0.7 : 0.3;
    }
    
    private function classifyConsciousness($score) {
        if ($score > 0.8) return 'Muy Alta';
        if ($score > 0.6) return 'Alta';
        if ($score > 0.4) return 'Media';
        if ($score > 0.2) return 'Baja';
        return 'Muy Baja';
    }
    
    private function buildClaudeContext($history, $analysis) {
        return [
            'conversation_length' => count($history),
            'user_consciousness' => $analysis['consciousness']['level'],
            'security_context' => $analysis['security']['is_safe'],
            'ai_awareness' => $analysis['ai_detection']['is_ai_related']
        ];
    }
    
    private function checkDailyLimit() {
        if ($this->isPremium) return false;
        
        try {
            $result = $this->db->executeQuery(
                "SELECT COUNT(*) as count FROM conversation_logs WHERE user_id = ? AND DATE(timestamp) = CURDATE()",
                [$this->userId]
            );
            
            if ($result) {
                $row = $result->fetch_assoc();
                return $row['count'] >= 50; // Límite de 50 mensajes diarios para usuarios básicos
            }
        } catch (Exception $e) {
            logEvent('ERROR', 'Error verificando límite diario: ' . $e->getMessage());
        }
        
        return false;
    }
    
    private function saveConversation($message, $response) {
        try {
            // Crear conversación si no existe
            if (!$this->conversationId) {
                $title = substr($message, 0, 50) . (strlen($message) > 50 ? '...' : '');
                $stmt = $this->db->getConnection()->prepare(
                    "INSERT INTO conversations (user_id, title, created_at) VALUES (?, ?, NOW())"
                );
                $stmt->bind_param('is', $this->userId, $title);
                $stmt->execute();
                $this->conversationId = $this->db->getConnection()->insert_id;
            }
            
            // Guardar mensajes
            $this->db->executeQuery(
                "INSERT INTO conversation_logs (conversation_id, user_id, message_type, message_content, timestamp) VALUES (?, ?, 'user', ?, NOW()), (?, ?, 'assistant', ?, NOW())",
                [$this->conversationId, $this->userId, $message, $this->conversationId, $this->userId, $response]
            );
            
        } catch (Exception $e) {
            logEvent('ERROR', 'Error guardando conversación: ' . $e->getMessage());
        }
    }
    
    private function getThreatDescription($threat) {
        $descriptions = [
            'sql_injection' => 'Posible intento de inyección SQL',
            'xss_attempt' => 'Posible intento de Cross-Site Scripting (XSS)',
            'command_injection' => 'Posible intento de inyección de comandos',
            'social_engineering' => 'Posible intento de ingeniería social',
            'prompt_injection' => 'Posible intento de manipulación de prompts'
        ];
        
        return $descriptions[$threat] ?? 'Amenaza desconocida';
    }
    
    private function addPremiumInsights($analysis) {
        $insights = "\n\n💎 **Análisis Premium**:\n";
        $insights .= "• Nivel de consciencia detectado: " . round($analysis['consciousness']['level'] * 100) . "%\n";
        $insights .= "• Probabilidad de IA: " . round($analysis['ai_detection']['ai_probability'] * 100) . "%\n";
        $insights .= "• Nivel de seguridad: " . (10 - $analysis['security']['threat_level']) . "/10\n";
        $insights .= "• Intención principal: " . ucfirst($analysis['intent']['primary']);
        
        return $insights;
    }
    
    private function jsonResponse($success, $message, $data = null) {
        $response = [
            'success' => $success,
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s'),
            'conversation_id' => $this->conversationId
        ];
        
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Procesar request
$api = new GuardianClaudeAPI();
$api->handleRequest();
?>

