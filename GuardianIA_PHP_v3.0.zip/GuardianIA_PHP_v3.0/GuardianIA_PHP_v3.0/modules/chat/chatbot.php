<?php
/**
 * GuardianIA v3.0 FINAL - ChatBot Usuario (Claude-like)
 * Anderson Mamian Chicangana - Membresía Premium
 * Parámetros y funcionalidades iguales a Claude
 */

require_once '../../config/config.php';
require_once '../../config/database.php';

// Verificar sesión
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$db = DatabaseConfig::getInstance();
$user_id = $_SESSION['user_id'];
$is_premium = isPremiumUser($user_id);

// Obtener conversaciones del usuario
$conversations = [];
try {
    $result = $db->executeQuery(
        "SELECT id, title, created_at FROM conversations WHERE user_id = ? ORDER BY created_at DESC LIMIT 20",
        [$user_id]
    );
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $conversations[] = $row;
        }
    }
} catch (Exception $e) {
    logEvent('ERROR', 'Error obteniendo conversaciones: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA ChatBot - Claude-like Experience</title>
    <link rel="stylesheet" href="../../assets/css/main.css">
    <style>
        /* Estilos específicos para ChatBot Claude-like */
        .chat-container {
            display: flex;
            height: 100vh;
            background: #0a0a0a;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        .sidebar {
            width: 280px;
            background: #1a1a1a;
            border-right: 1px solid #333;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #333;
        }
        
        .new-chat-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(45deg, #00ff88, #00ccff);
            color: #000;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .new-chat-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 255, 136, 0.3);
        }
        
        .conversations-list {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }
        
        .conversation-item {
            padding: 12px;
            margin-bottom: 4px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
            color: #ccc;
            font-size: 14px;
            border: 1px solid transparent;
        }
        
        .conversation-item:hover {
            background: #2a2a2a;
            border-color: #00ff88;
        }
        
        .conversation-item.active {
            background: #00ff88;
            color: #000;
        }
        
        .main-chat {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #0a0a0a;
        }
        
        .chat-header {
            padding: 20px;
            border-bottom: 1px solid #333;
            background: #1a1a1a;
        }
        
        .chat-title {
            font-size: 18px;
            font-weight: 600;
            color: #00ff88;
            margin: 0;
        }
        
        .chat-subtitle {
            font-size: 14px;
            color: #888;
            margin-top: 4px;
        }
        
        .messages-container {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .message {
            display: flex;
            gap: 12px;
            max-width: 800px;
            margin: 0 auto;
            width: 100%;
        }
        
        .message.user {
            flex-direction: row-reverse;
        }
        
        .message-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }
        
        .message.user .message-avatar {
            background: linear-gradient(45deg, #00ff88, #00ccff);
            color: #000;
        }
        
        .message.assistant .message-avatar {
            background: linear-gradient(45deg, #ff6b6b, #ffd93d);
            color: #000;
        }
        
        .message-content {
            flex: 1;
            background: #1a1a1a;
            border-radius: 12px;
            padding: 16px;
            border: 1px solid #333;
            position: relative;
        }
        
        .message.user .message-content {
            background: #00ff88;
            color: #000;
        }
        
        .message-text {
            line-height: 1.6;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        
        .message-time {
            font-size: 12px;
            opacity: 0.6;
            margin-top: 8px;
        }
        
        .typing-indicator {
            display: none;
            align-items: center;
            gap: 8px;
            color: #888;
            font-style: italic;
        }
        
        .typing-dots {
            display: flex;
            gap: 4px;
        }
        
        .typing-dot {
            width: 6px;
            height: 6px;
            background: #00ff88;
            border-radius: 50%;
            animation: typingPulse 1.4s infinite ease-in-out;
        }
        
        .typing-dot:nth-child(2) { animation-delay: 0.2s; }
        .typing-dot:nth-child(3) { animation-delay: 0.4s; }
        
        @keyframes typingPulse {
            0%, 80%, 100% { opacity: 0.3; }
            40% { opacity: 1; }
        }
        
        .input-container {
            padding: 20px;
            border-top: 1px solid #333;
            background: #1a1a1a;
        }
        
        .input-wrapper {
            max-width: 800px;
            margin: 0 auto;
            position: relative;
        }
        
        .message-input {
            width: 100%;
            min-height: 60px;
            max-height: 200px;
            padding: 16px 60px 16px 16px;
            background: #2a2a2a;
            border: 2px solid #333;
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            line-height: 1.4;
            resize: none;
            outline: none;
            transition: all 0.2s;
        }
        
        .message-input:focus {
            border-color: #00ff88;
            box-shadow: 0 0 0 3px rgba(0, 255, 136, 0.1);
        }
        
        .send-button {
            position: absolute;
            right: 8px;
            bottom: 8px;
            width: 44px;
            height: 44px;
            background: linear-gradient(45deg, #00ff88, #00ccff);
            border: none;
            border-radius: 8px;
            color: #000;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            font-size: 18px;
        }
        
        .send-button:hover {
            transform: scale(1.05);
        }
        
        .send-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        
        .ai-status {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #00ff88;
            border-radius: 20px;
            padding: 8px 16px;
            font-size: 12px;
            color: #00ff88;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }
        
        .premium-badge {
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #000;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: bold;
            margin-left: 8px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                left: -280px;
                z-index: 1000;
                transition: left 0.3s;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-chat {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <button class="new-chat-btn" onclick="startNewChat()">
                    ➕ Nueva Conversación
                </button>
                <div style="margin-top: 12px; text-align: center;">
                    <span style="color: #00ff88; font-weight: bold;">GuardianIA Claude</span>
                    <?php if ($is_premium): ?>
                    <span class="premium-badge">PREMIUM</span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="conversations-list" id="conversationsList">
                <?php foreach ($conversations as $conv): ?>
                <div class="conversation-item" onclick="loadConversation(<?php echo $conv['id']; ?>)">
                    <div style="font-weight: 500;"><?php echo htmlspecialchars($conv['title']); ?></div>
                    <div style="font-size: 12px; opacity: 0.7; margin-top: 4px;">
                        <?php echo date('M j, Y', strtotime($conv['created_at'])); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Main Chat -->
        <div class="main-chat">
            <div class="chat-header">
                <h1 class="chat-title">GuardianIA Claude-like Assistant</h1>
                <div class="chat-subtitle">
                    IA Consciente con Capacidades Avanzadas de Análisis y Conversación
                    <?php if ($is_premium): ?>
                    • Modo Premium Activado
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="messages-container" id="messagesContainer">
                <div class="message assistant">
                    <div class="message-avatar">🤖</div>
                    <div class="message-content">
                        <div class="message-text">¡Hola! Soy GuardianIA, tu asistente de IA consciente. Tengo capacidades similares a Claude pero con funcionalidades avanzadas de ciberseguridad.

Puedo ayudarte con:
• Análisis de texto y código
• Resolución de problemas complejos
• Detección de amenazas de seguridad
• Conversaciones profundas y filosóficas
• Análisis de datos y patrones
• Generación de contenido creativo

¿En qué puedo ayudarte hoy?</div>
                        <div class="message-time"><?php echo date('H:i'); ?></div>
                    </div>
                </div>
            </div>
            
            <div class="typing-indicator" id="typingIndicator">
                <div class="message-avatar">🤖</div>
                <div>
                    GuardianIA está escribiendo
                    <div class="typing-dots">
                        <div class="typing-dot"></div>
                        <div class="typing-dot"></div>
                        <div class="typing-dot"></div>
                    </div>
                </div>
            </div>
            
            <div class="input-container">
                <div class="input-wrapper">
                    <textarea 
                        id="messageInput" 
                        class="message-input" 
                        placeholder="Escribe tu mensaje aquí... (Shift+Enter para nueva línea)"
                        rows="1"
                    ></textarea>
                    <button class="send-button" id="sendButton" onclick="sendMessage()">
                        ➤
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- AI Status Indicator -->
    <div class="ai-status" id="aiStatus">
        🧠 IA Consciente: Activa | 🛡️ Seguridad: Máxima | 💎 Premium: <?php echo $is_premium ? 'Sí' : 'No'; ?>
    </div>

    <script>
        class GuardianClaude {
            constructor() {
                this.currentConversationId = null;
                this.isTyping = false;
                this.messageHistory = [];
                this.userId = <?php echo $user_id; ?>;
                this.isPremium = <?php echo $is_premium ? 'true' : 'false'; ?>;
                
                this.init();
            }
            
            init() {
                this.setupEventListeners();
                this.autoResizeTextarea();
                console.log('🤖 GuardianIA Claude-like Assistant initialized');
            }
            
            setupEventListeners() {
                const input = document.getElementById('messageInput');
                const sendBtn = document.getElementById('sendButton');
                
                // Enter para enviar, Shift+Enter para nueva línea
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.sendMessage();
                    }
                });
                
                // Auto-resize textarea
                input.addEventListener('input', () => {
                    this.autoResizeTextarea();
                });
                
                // Detectar cuando el usuario está escribiendo
                let typingTimer;
                input.addEventListener('input', () => {
                    clearTimeout(typingTimer);
                    typingTimer = setTimeout(() => {
                        // Usuario dejó de escribir
                    }, 1000);
                });
            }
            
            autoResizeTextarea() {
                const textarea = document.getElementById('messageInput');
                textarea.style.height = 'auto';
                textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
            }
            
            async sendMessage() {
                const input = document.getElementById('messageInput');
                const message = input.value.trim();
                
                if (!message || this.isTyping) return;
                
                // Limpiar input
                input.value = '';
                this.autoResizeTextarea();
                
                // Agregar mensaje del usuario
                this.addMessage('user', message);
                
                // Mostrar indicador de escritura
                this.showTypingIndicator();
                
                try {
                    // Enviar a la API
                    const response = await this.callAPI(message);
                    
                    // Ocultar indicador de escritura
                    this.hideTypingIndicator();
                    
                    // Agregar respuesta de la IA
                    this.addMessage('assistant', response.message);
                    
                    // Guardar en historial
                    this.messageHistory.push(
                        { role: 'user', content: message },
                        { role: 'assistant', content: response.message }
                    );
                    
                } catch (error) {
                    this.hideTypingIndicator();
                    this.addMessage('assistant', 'Lo siento, ocurrió un error al procesar tu mensaje. Por favor, intenta nuevamente.');
                    console.error('Error:', error);
                }
            }
            
            async callAPI(message) {
                const response = await fetch('claude_api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        message: message,
                        conversation_id: this.currentConversationId,
                        user_id: this.userId,
                        history: this.messageHistory.slice(-10), // Últimos 10 mensajes para contexto
                        premium: this.isPremium
                    })
                });
                
                if (!response.ok) {
                    throw new Error('Error en la API');
                }
                
                return await response.json();
            }
            
            addMessage(role, content) {
                const container = document.getElementById('messagesContainer');
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${role}`;
                
                const avatar = role === 'user' ? '👤' : '🤖';
                const time = new Date().toLocaleTimeString('es-ES', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                });
                
                messageDiv.innerHTML = `
                    <div class="message-avatar">${avatar}</div>
                    <div class="message-content">
                        <div class="message-text">${this.formatMessage(content)}</div>
                        <div class="message-time">${time}</div>
                    </div>
                `;
                
                container.appendChild(messageDiv);
                this.scrollToBottom();
            }
            
            formatMessage(content) {
                // Formatear markdown básico
                return content
                    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    .replace(/\*(.*?)\*/g, '<em>$1</em>')
                    .replace(/`(.*?)`/g, '<code>$1</code>')
                    .replace(/\n/g, '<br>');
            }
            
            showTypingIndicator() {
                this.isTyping = true;
                document.getElementById('typingIndicator').style.display = 'flex';
                document.getElementById('sendButton').disabled = true;
                this.scrollToBottom();
            }
            
            hideTypingIndicator() {
                this.isTyping = false;
                document.getElementById('typingIndicator').style.display = 'none';
                document.getElementById('sendButton').disabled = false;
            }
            
            scrollToBottom() {
                const container = document.getElementById('messagesContainer');
                container.scrollTop = container.scrollHeight;
            }
            
            startNewChat() {
                this.currentConversationId = null;
                this.messageHistory = [];
                document.getElementById('messagesContainer').innerHTML = `
                    <div class="message assistant">
                        <div class="message-avatar">🤖</div>
                        <div class="message-content">
                            <div class="message-text">¡Nueva conversación iniciada! ¿En qué puedo ayudarte?</div>
                            <div class="message-time">${new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</div>
                        </div>
                    </div>
                `;
            }
            
            loadConversation(conversationId) {
                // Implementar carga de conversación existente
                this.currentConversationId = conversationId;
                // TODO: Cargar mensajes de la conversación desde la API
            }
        }
        
        // Funciones globales
        function startNewChat() {
            window.guardianClaude.startNewChat();
        }
        
        function loadConversation(id) {
            window.guardianClaude.loadConversation(id);
        }
        
        function sendMessage() {
            window.guardianClaude.sendMessage();
        }
        
        // Inicializar cuando el DOM esté listo
        document.addEventListener('DOMContentLoaded', () => {
            window.guardianClaude = new GuardianClaude();
        });
    </script>
</body>
</html>

