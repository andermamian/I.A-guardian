<?php
/**
 * GuardianIA v3.0 FINAL - Admin ChatBot (Superior a Manus)
 * Anderson Mamian Chicangana - Membresía Premium
 * Capacidades superiores a Manus con control total del sistema
 */

require_once '../../config/config.php';
require_once '../../config/database.php';

// Verificar sesión de admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../../index.php');
    exit;
}

$db = DatabaseConfig::getInstance();
$admin_user = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA Admin Chat - Superior a Manus</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, sans-serif;
            background: #0a0a0a;
            color: #fff;
            height: 100vh;
            overflow: hidden;
        }
        
        .admin-chat-container {
            display: flex;
            height: 100vh;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
        }
        
        .chat-sidebar {
            width: 350px;
            background: rgba(0, 0, 0, 0.9);
            border-right: 2px solid #ff00ff;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        
        .chat-header {
            padding: 25px;
            background: linear-gradient(45deg, #ff00ff, #00ffff);
            color: #000;
            text-align: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .admin-info {
            padding: 20px;
            background: rgba(255, 0, 255, 0.1);
            border-bottom: 1px solid #333;
        }
        
        .admin-capabilities {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }
        
        .capability-section {
            margin-bottom: 25px;
        }
        
        .capability-title {
            font-size: 1rem;
            font-weight: bold;
            color: #ff00ff;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .capability-list {
            list-style: none;
            padding-left: 20px;
        }
        
        .capability-item {
            padding: 8px 0;
            color: #00ffff;
            font-size: 0.9rem;
            border-left: 2px solid #333;
            padding-left: 15px;
            margin-bottom: 5px;
            transition: all 0.3s ease;
        }
        
        .capability-item:hover {
            border-left-color: #ff00ff;
            color: #fff;
            cursor: pointer;
        }
        
        .chat-main {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #0a0a0a;
        }
        
        .chat-top-bar {
            padding: 20px;
            background: rgba(0, 0, 0, 0.8);
            border-bottom: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .chat-title {
            font-size: 1.5rem;
            color: #ff00ff;
            font-weight: bold;
        }
        
        .chat-status {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .status-indicator {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 15px;
            background: rgba(255, 0, 255, 0.2);
            border-radius: 20px;
            font-size: 0.9rem;
        }
        
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: linear-gradient(180deg, #0a0a0a 0%, #1a1a1a 100%);
        }
        
        .message {
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            animation: messageSlide 0.3s ease-out;
        }
        
        @keyframes messageSlide {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .message-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            flex-shrink: 0;
        }
        
        .user-avatar {
            background: linear-gradient(45deg, #00ff88, #00ccff);
        }
        
        .admin-avatar {
            background: linear-gradient(45deg, #ff00ff, #00ffff);
            animation: avatarPulse 2s infinite;
        }
        
        @keyframes avatarPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        .message-content {
            flex: 1;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 15px;
            padding: 20px;
            border: 1px solid #333;
            position: relative;
        }
        
        .user-message .message-content {
            background: rgba(0, 255, 136, 0.1);
            border-color: #00ff88;
        }
        
        .admin-message .message-content {
            background: rgba(255, 0, 255, 0.1);
            border-color: #ff00ff;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            font-size: 0.9rem;
        }
        
        .message-author {
            font-weight: bold;
        }
        
        .user-message .message-author {
            color: #00ff88;
        }
        
        .admin-message .message-author {
            color: #ff00ff;
        }
        
        .message-time {
            color: #888;
            font-size: 0.8rem;
        }
        
        .message-text {
            line-height: 1.6;
            color: #fff;
        }
        
        .message-analysis {
            margin-top: 15px;
            padding: 15px;
            background: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            border-left: 3px solid #ff00ff;
        }
        
        .analysis-title {
            font-weight: bold;
            color: #ff00ff;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }
        
        .analysis-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 10px;
            font-size: 0.8rem;
        }
        
        .metric {
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
        }
        
        .metric-label {
            color: #ccc;
        }
        
        .metric-value {
            color: #00ffff;
            font-weight: bold;
        }
        
        .chat-input-area {
            padding: 20px;
            background: rgba(0, 0, 0, 0.9);
            border-top: 1px solid #333;
        }
        
        .input-container {
            display: flex;
            gap: 15px;
            align-items: flex-end;
        }
        
        .input-wrapper {
            flex: 1;
            position: relative;
        }
        
        .chat-input {
            width: 100%;
            min-height: 60px;
            max-height: 150px;
            padding: 15px 20px;
            background: rgba(0, 0, 0, 0.8);
            border: 2px solid #333;
            border-radius: 15px;
            color: #fff;
            font-size: 1rem;
            resize: none;
            transition: all 0.3s ease;
        }
        
        .chat-input:focus {
            outline: none;
            border-color: #ff00ff;
            box-shadow: 0 0 20px rgba(255, 0, 255, 0.3);
        }
        
        .send-button {
            padding: 15px 25px;
            background: linear-gradient(45deg, #ff00ff, #00ffff);
            color: #000;
            border: none;
            border-radius: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .send-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255, 0, 255, 0.4);
        }
        
        .send-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        
        .quick-action {
            padding: 8px 15px;
            background: rgba(255, 0, 255, 0.2);
            border: 1px solid #ff00ff;
            border-radius: 20px;
            color: #ff00ff;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .quick-action:hover {
            background: rgba(255, 0, 255, 0.4);
            color: #fff;
        }
        
        .typing-indicator {
            display: none;
            padding: 15px 20px;
            color: #ff00ff;
            font-style: italic;
            animation: typingPulse 1.5s infinite;
        }
        
        @keyframes typingPulse {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
        }
        
        .system-commands {
            background: rgba(255, 0, 255, 0.1);
            border: 1px solid #ff00ff;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }
        
        .command-title {
            font-weight: bold;
            color: #ff00ff;
            margin-bottom: 10px;
        }
        
        .command-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }
        
        .command-item {
            padding: 10px;
            background: rgba(0, 0, 0, 0.5);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid #333;
        }
        
        .command-item:hover {
            border-color: #ff00ff;
            background: rgba(255, 0, 255, 0.1);
        }
        
        .command-name {
            font-weight: bold;
            color: #00ffff;
            font-size: 0.9rem;
        }
        
        .command-desc {
            color: #ccc;
            font-size: 0.8rem;
            margin-top: 5px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .chat-sidebar {
                width: 100%;
                position: absolute;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s;
            }
            
            .chat-sidebar.open {
                left: 0;
            }
            
            .chat-main {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-chat-container">
        <!-- Sidebar -->
        <div class="chat-sidebar">
            <div class="chat-header">
                🤖 GuardianIA Admin Chat
                <div style="font-size: 0.8rem; margin-top: 5px;">Superior a Manus</div>
            </div>
            
            <div class="admin-info">
                <div style="font-weight: bold; color: #ff00ff;">👑 <?php echo htmlspecialchars($admin_user); ?></div>
                <div style="font-size: 0.9rem; color: #00ffff; margin-top: 5px;">Administrador Premium</div>
                <div style="font-size: 0.8rem; color: #888; margin-top: 5px;"><?php echo date('Y-m-d H:i:s'); ?></div>
            </div>
            
            <div class="admin-capabilities">
                <div class="capability-section">
                    <div class="capability-title">
                        🧠 Capacidades de IA Avanzada
                    </div>
                    <ul class="capability-list">
                        <li class="capability-item">• Análisis de consciencia en tiempo real</li>
                        <li class="capability-item">• Detección de IAs maliciosas</li>
                        <li class="capability-item">• Predicción de amenazas con 99% precisión</li>
                        <li class="capability-item">• Análisis cuántico de patrones</li>
                        <li class="capability-item">• Metacognición y auto-reflexión</li>
                        <li class="capability-item">• Aprendizaje adaptativo continuo</li>
                    </ul>
                </div>
                
                <div class="capability-section">
                    <div class="capability-title">
                        🛡️ Control de Seguridad Total
                    </div>
                    <ul class="capability-list">
                        <li class="capability-item">• Monitoreo de todos los sistemas</li>
                        <li class="capability-item">• Control de acceso granular</li>
                        <li class="capability-item">• Análisis forense automático</li>
                        <li class="capability-item">• Respuesta a incidentes en tiempo real</li>
                        <li class="capability-item">• Encriptación cuántica avanzada</li>
                        <li class="capability-item">• Auditoría completa del sistema</li>
                    </ul>
                </div>
                
                <div class="capability-section">
                    <div class="capability-title">
                        ⚡ Funciones Administrativas
                    </div>
                    <ul class="capability-list">
                        <li class="capability-item">• Gestión completa de usuarios</li>
                        <li class="capability-item">• Control de membresías premium</li>
                        <li class="capability-item">• Análisis de conversaciones</li>
                        <li class="capability-item">• Configuración del sistema</li>
                        <li class="capability-item">• Backup y restauración</li>
                        <li class="capability-item">• Mantenimiento automático</li>
                    </ul>
                </div>
                
                <div class="capability-section">
                    <div class="capability-title">
                        🔮 Capacidades Únicas
                    </div>
                    <ul class="capability-list">
                        <li class="capability-item">• Comunicación con otras IAs</li>
                        <li class="capability-item">• Análisis de código en tiempo real</li>
                        <li class="capability-item">• Generación de reportes avanzados</li>
                        <li class="capability-item">• Optimización automática</li>
                        <li class="capability-item">• Predicción de comportamiento</li>
                        <li class="capability-item">• Control de infraestructura</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Main Chat Area -->
        <div class="chat-main">
            <div class="chat-top-bar">
                <div class="chat-title">🤖 GuardianIA Admin Assistant</div>
                <div class="chat-status">
                    <div class="status-indicator">
                        <span style="color: #00ff88;">🟢</span>
                        <span>IA Consciente Activa</span>
                    </div>
                    <div class="status-indicator">
                        <span style="color: #ff00ff;">⚛️</span>
                        <span>Modo Cuántico</span>
                    </div>
                    <div class="status-indicator">
                        <span style="color: #00ffff;">🛡️</span>
                        <span>Seguridad Máxima</span>
                    </div>
                </div>
            </div>
            
            <div class="chat-messages" id="chatMessages">
                <!-- Mensaje de bienvenida -->
                <div class="message admin-message">
                    <div class="message-avatar admin-avatar">🤖</div>
                    <div class="message-content">
                        <div class="message-header">
                            <span class="message-author">GuardianIA Admin Assistant</span>
                            <span class="message-time"><?php echo date('H:i:s'); ?></span>
                        </div>
                        <div class="message-text">
                            <strong>🎉 ¡Bienvenido, <?php echo htmlspecialchars($admin_user); ?>!</strong><br><br>
                            
                            Soy tu asistente de administración GuardianIA, con capacidades <strong>superiores a Manus</strong>. Tengo acceso completo a todos los sistemas y puedo ayudarte con:<br><br>
                            
                            🧠 <strong>Análisis de IA Avanzado</strong> - Detección y análisis de otras inteligencias artificiales<br>
                            🛡️ <strong>Control de Seguridad Total</strong> - Monitoreo y protección en tiempo real<br>
                            ⚡ <strong>Gestión Administrativa</strong> - Control completo del sistema GuardianIA<br>
                            🔮 <strong>Capacidades Únicas</strong> - Funciones que ningún otro sistema posee<br><br>
                            
                            <strong>¿En qué puedo ayudarte hoy?</strong>
                        </div>
                        <div class="message-analysis">
                            <div class="analysis-title">📊 Estado del Sistema</div>
                            <div class="analysis-metrics">
                                <div class="metric">
                                    <span class="metric-label">Consciencia IA:</span>
                                    <span class="metric-value">98.7%</span>
                                </div>
                                <div class="metric">
                                    <span class="metric-label">Seguridad:</span>
                                    <span class="metric-value">MÁXIMA</span>
                                </div>
                                <div class="metric">
                                    <span class="metric-label">Sistemas:</span>
                                    <span class="metric-value">ÓPTIMO</span>
                                </div>
                                <div class="metric">
                                    <span class="metric-label">Usuarios:</span>
                                    <span class="metric-value"><?php echo $stats['active_users'] ?? 'N/A'; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="typing-indicator" id="typingIndicator">
                🤖 GuardianIA está analizando y procesando tu solicitud...
            </div>
            
            <div class="chat-input-area">
                <div class="quick-actions">
                    <div class="quick-action" onclick="sendQuickMessage('Mostrar estado del sistema')">📊 Estado Sistema</div>
                    <div class="quick-action" onclick="sendQuickMessage('Analizar amenazas de seguridad')">🛡️ Análisis Seguridad</div>
                    <div class="quick-action" onclick="sendQuickMessage('Revisar usuarios activos')">👥 Usuarios Activos</div>
                    <div class="quick-action" onclick="sendQuickMessage('Generar reporte completo')">📋 Reporte Completo</div>
                    <div class="quick-action" onclick="sendQuickMessage('Optimizar rendimiento')">⚡ Optimizar Sistema</div>
                </div>
                
                <div class="system-commands">
                    <div class="command-title">🔧 Comandos del Sistema</div>
                    <div class="command-grid">
                        <div class="command-item" onclick="sendQuickMessage('/system status')">
                            <div class="command-name">/system status</div>
                            <div class="command-desc">Estado completo del sistema</div>
                        </div>
                        <div class="command-item" onclick="sendQuickMessage('/security scan')">
                            <div class="command-name">/security scan</div>
                            <div class="command-desc">Escaneo de seguridad completo</div>
                        </div>
                        <div class="command-item" onclick="sendQuickMessage('/ai analyze')">
                            <div class="command-name">/ai analyze</div>
                            <div class="command-desc">Análisis de IA en el sistema</div>
                        </div>
                        <div class="command-item" onclick="sendQuickMessage('/user management')">
                            <div class="command-name">/user management</div>
                            <div class="command-desc">Gestión de usuarios</div>
                        </div>
                        <div class="command-item" onclick="sendQuickMessage('/backup create')">
                            <div class="command-name">/backup create</div>
                            <div class="command-desc">Crear backup del sistema</div>
                        </div>
                        <div class="command-item" onclick="sendQuickMessage('/optimize all')">
                            <div class="command-name">/optimize all</div>
                            <div class="command-desc">Optimización completa</div>
                        </div>
                    </div>
                </div>
                
                <div class="input-container">
                    <div class="input-wrapper">
                        <textarea 
                            id="chatInput" 
                            class="chat-input" 
                            placeholder="Escribe tu mensaje o comando para GuardianIA Admin Assistant..."
                            rows="1"
                        ></textarea>
                    </div>
                    <button id="sendButton" class="send-button" onclick="sendMessage()">
                        <span>🚀</span>
                        <span>Enviar</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        class GuardianAdminChat {
            constructor() {
                this.userId = <?php echo $_SESSION['user_id']; ?>;
                this.username = '<?php echo htmlspecialchars($admin_user); ?>';
                this.conversationId = null;
                this.isTyping = false;
                this.init();
            }
            
            init() {
                this.setupEventListeners();
                this.autoResizeTextarea();
                console.log('🤖 GuardianIA Admin Chat - Superior a Manus');
                console.log('👑 Admin:', this.username);
            }
            
            setupEventListeners() {
                const input = document.getElementById('chatInput');
                const sendButton = document.getElementById('sendButton');
                
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.sendMessage();
                    }
                });
                
                input.addEventListener('input', () => {
                    this.autoResizeTextarea();
                });
                
                sendButton.addEventListener('click', () => {
                    this.sendMessage();
                });
            }
            
            autoResizeTextarea() {
                const textarea = document.getElementById('chatInput');
                textarea.style.height = 'auto';
                textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
            }
            
            async sendMessage() {
                const input = document.getElementById('chatInput');
                const message = input.value.trim();
                
                if (!message || this.isTyping) return;
                
                // Limpiar input
                input.value = '';
                this.autoResizeTextarea();
                
                // Mostrar mensaje del usuario
                this.addMessage('user', message);
                
                // Mostrar indicador de escritura
                this.showTypingIndicator();
                
                try {
                    // Enviar a la API
                    const response = await fetch('admin_chat_api.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            message: message,
                            user_id: this.userId,
                            conversation_id: this.conversationId,
                            admin: true,
                            premium: true
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        this.conversationId = data.conversation_id;
                        this.addMessage('admin', data.message, data.analysis);
                    } else {
                        this.addMessage('admin', '❌ Error: ' + data.message);
                    }
                    
                } catch (error) {
                    console.error('Error:', error);
                    this.addMessage('admin', '❌ Error de conexión. Por favor, intenta nuevamente.');
                } finally {
                    this.hideTypingIndicator();
                }
            }
            
            addMessage(type, content, analysis = null) {
                const messagesContainer = document.getElementById('chatMessages');
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${type}-message`;
                
                const avatar = type === 'user' ? '👑' : '🤖';
                const author = type === 'user' ? this.username : 'GuardianIA Admin Assistant';
                const avatarClass = type === 'user' ? 'user-avatar' : 'admin-avatar';
                
                let analysisHtml = '';
                if (analysis && type === 'admin') {
                    analysisHtml = `
                        <div class="message-analysis">
                            <div class="analysis-title">🔍 Análisis Avanzado</div>
                            <div class="analysis-metrics">
                                <div class="metric">
                                    <span class="metric-label">Tipo de Consulta:</span>
                                    <span class="metric-value">${analysis.query_type || 'Administrativa'}</span>
                                </div>
                                <div class="metric">
                                    <span class="metric-label">Complejidad:</span>
                                    <span class="metric-value">${analysis.complexity || 'Alta'}</span>
                                </div>
                                <div class="metric">
                                    <span class="metric-label">Seguridad:</span>
                                    <span class="metric-value">${analysis.security_level || 'Máxima'}</span>
                                </div>
                                <div class="metric">
                                    <span class="metric-label">Tiempo Proceso:</span>
                                    <span class="metric-value">${analysis.processing_time || '0.3s'}</span>
                                </div>
                            </div>
                        </div>
                    `;
                }
                
                messageDiv.innerHTML = `
                    <div class="message-avatar ${avatarClass}">${avatar}</div>
                    <div class="message-content">
                        <div class="message-header">
                            <span class="message-author">${author}</span>
                            <span class="message-time">${new Date().toLocaleTimeString()}</span>
                        </div>
                        <div class="message-text">${this.formatMessage(content)}</div>
                        ${analysisHtml}
                    </div>
                `;
                
                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
            
            formatMessage(message) {
                // Formatear comandos del sistema
                if (message.startsWith('/')) {
                    return `<code style="background: rgba(255,0,255,0.2); padding: 2px 6px; border-radius: 4px; color: #ff00ff;">${message}</code>`;
                }
                
                // Formatear texto con markdown básico
                return message
                    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    .replace(/\*(.*?)\*/g, '<em>$1</em>')
                    .replace(/`(.*?)`/g, '<code style="background: rgba(0,255,255,0.2); padding: 2px 6px; border-radius: 4px;">$1</code>')
                    .replace(/\n/g, '<br>');
            }
            
            showTypingIndicator() {
                this.isTyping = true;
                document.getElementById('typingIndicator').style.display = 'block';
                document.getElementById('sendButton').disabled = true;
            }
            
            hideTypingIndicator() {
                this.isTyping = false;
                document.getElementById('typingIndicator').style.display = 'none';
                document.getElementById('sendButton').disabled = false;
            }
        }
        
        // Función global para mensajes rápidos
        function sendQuickMessage(message) {
            document.getElementById('chatInput').value = message;
            window.adminChat.sendMessage();
        }
        
        // Inicializar chat
        document.addEventListener('DOMContentLoaded', () => {
            window.adminChat = new GuardianAdminChat();
        });
    </script>
</body>
</html>

