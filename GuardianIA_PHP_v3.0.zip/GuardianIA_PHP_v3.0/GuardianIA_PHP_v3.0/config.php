<?php
/**
 * GuardianIA v3.0 FINAL - Configuración Principal ACTUALIZADA
 * Anderson Mamian Chicangana - Membresía Premium Activada
 * Sistema con Soporte Dual de Base de Datos (MySQL + Fallback)
 */

// Configuración de errores
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/error.log');

// Zona horaria
date_default_timezone_set('America/Bogota');

// Configuración de la aplicación
define('APP_NAME', 'GuardianIA v3.0 FINAL');
define('APP_VERSION', '3.0.0');
define('APP_URL', 'http://localhost');
define('DEVELOPER', 'Anderson Mamian Chicangana');
define('DEVELOPER_EMAIL', 'anderson@guardianai.com');

// ========================================
// CONFIGURACIÓN DUAL DE BASE DE DATOS
// ========================================

// Base de datos principal (Anderson)
define('DB_PRIMARY_HOST', 'localhost');
define('DB_PRIMARY_USER', 'anderson');
define('DB_PRIMARY_PASS', 'Ander12345@');
define('DB_PRIMARY_NAME', 'guardianai_db');
define('DB_PRIMARY_PORT', 3306);

// Base de datos fallback (Root)
define('DB_FALLBACK_HOST', 'localhost');
define('DB_FALLBACK_USER', 'root');
define('DB_FALLBACK_PASS', '0987654321');
define('DB_FALLBACK_NAME', 'guardianai_db');
define('DB_FALLBACK_PORT', 3306);

// Configuración de conexión
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATION', 'utf8mb4_unicode_ci');
define('DB_TIMEOUT', 5);
define('DB_RETRY_ATTEMPTS', 3);

// Usuarios por defecto (si no hay base de datos)
$GLOBALS['DEFAULT_USERS'] = [
    'anderson' => [
        'id' => 1,
        'username' => 'anderson',
        'password' => 'Ander12345@',
        'password_hash' => password_hash('Ander12345@', PASSWORD_DEFAULT),
        'email' => 'anderson@guardianai.com',
        'fullname' => 'Anderson Mamian Chicangana',
        'user_type' => 'admin',
        'premium_status' => 'premium',
        'status' => 'active',
        'created_at' => '2025-08-23 00:00:00',
        'last_login' => date('Y-m-d H:i:s')
    ],
    'admin' => [
        'id' => 2,
        'username' => 'admin',
        'password' => 'admin123',
        'password_hash' => password_hash('admin123', PASSWORD_DEFAULT),
        'email' => 'admin@guardianai.com',
        'fullname' => 'Administrador GuardianIA',
        'user_type' => 'admin',
        'premium_status' => 'basic',
        'status' => 'active',
        'created_at' => '2025-08-23 00:00:00',
        'last_login' => date('Y-m-d H:i:s')
    ]
];

/**
 * Clase para manejo de conexión dual de base de datos
 */
class DatabaseManager {
    private static $instance = null;
    private $connection = null;
    private $connection_info = [];
    
    private function __construct() {
        $this->connect();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function connect() {
        // Intentar conexión principal (Anderson)
        $this->connection = $this->tryConnection(
            DB_PRIMARY_HOST,
            DB_PRIMARY_USER,
            DB_PRIMARY_PASS,
            DB_PRIMARY_NAME,
            DB_PRIMARY_PORT,
            'primary'
        );
        
        // Si falla, intentar conexión fallback (Root)
        if (!$this->connection) {
            $this->connection = $this->tryConnection(
                DB_FALLBACK_HOST,
                DB_FALLBACK_USER,
                DB_FALLBACK_PASS,
                DB_FALLBACK_NAME,
                DB_FALLBACK_PORT,
                'fallback'
            );
        }
        
        // Configurar conexión si existe
        if ($this->connection) {
            $this->connection->set_charset(DB_CHARSET);
            $this->connection->query("SET time_zone = '-05:00'");
            $this->connection->query("SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
        }
    }
    
    private function tryConnection($host, $user, $pass, $db, $port, $type) {
        try {
            // Configurar timeout
            ini_set('mysql.connect_timeout', DB_TIMEOUT);
            ini_set('default_socket_timeout', DB_TIMEOUT);
            
            // Intentar conexión con diferentes métodos
            $connection = null;
            
            // Método 1: Conexión estándar
            try {
                $connection = new mysqli($host, $user, $pass, $db, $port);
            } catch (Exception $e) {
                // Método 2: Conexión sin base de datos primero
                try {
                    $connection = new mysqli($host, $user, $pass, '', $port);
                    if ($connection && !$connection->connect_error) {
                        $connection->query("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET " . DB_CHARSET . " COLLATE " . DB_COLLATION);
                        $connection->select_db($db);
                    }
                } catch (Exception $e2) {
                    $connection = null;
                }
            }
            
            // Verificar conexión
            if ($connection && !$connection->connect_error) {
                $this->connection_info = [
                    'type' => $type,
                    'host' => $host,
                    'user' => $user,
                    'database' => $db,
                    'port' => $port,
                    'connected_at' => date('Y-m-d H:i:s'),
                    'server_version' => $connection->server_info ?? 'unknown'
                ];
                
                $this->logConnection($type, 'SUCCESS', "Conectado exitosamente como $user@$host:$port");
                return $connection;
            } else {
                $error = $connection ? $connection->connect_error : 'Connection failed';
                $this->logConnection($type, 'ERROR', "Error conectando como $user@$host:$port - $error");
                return null;
            }
            
        } catch (Exception $e) {
            $this->logConnection($type, 'ERROR', "Excepción conectando como $user@$host:$port - " . $e->getMessage());
            return null;
        }
    }
    
    private function logConnection($type, $status, $message) {
        $log_entry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'type' => $type,
            'status' => $status,
            'message' => $message
        ];
        
        $log_line = json_encode($log_entry, JSON_UNESCAPED_UNICODE) . PHP_EOL;
        @file_put_contents(__DIR__ . '/logs/database.log', $log_line, FILE_APPEND | LOCK_EX);
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function getConnectionInfo() {
        return $this->connection_info;
    }
    
    public function isConnected() {
        return $this->connection !== null && !$this->connection->connect_error;
    }
    
    public function query($sql, $params = []) {
        if (!$this->isConnected()) {
            return false;
        }
        
        try {
            if (empty($params)) {
                return $this->connection->query($sql);
            } else {
                $stmt = $this->connection->prepare($sql);
                if ($stmt) {
                    $types = str_repeat('s', count($params));
                    $stmt->bind_param($types, ...$params);
                    $stmt->execute();
                    return $stmt->get_result();
                }
            }
        } catch (Exception $e) {
            $this->logConnection('query', 'ERROR', "Error ejecutando query: " . $e->getMessage());
            return false;
        }
        
        return false;
    }
    
    public function testConnection() {
        $result = [
            'connected' => $this->isConnected(),
            'connection_info' => $this->connection_info,
            'server_info' => null,
            'database_exists' => false,
            'tables_count' => 0,
            'users_count' => 0
        ];
        
        if ($this->isConnected()) {
            $result['server_info'] = $this->connection->server_info;
            
            // Verificar base de datos
            $db_result = $this->connection->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '" . $this->connection_info['database'] . "'");
            $result['database_exists'] = $db_result && $db_result->num_rows > 0;
            
            if ($result['database_exists']) {
                // Contar tablas
                $tables_result = $this->connection->query("SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '" . $this->connection_info['database'] . "'");
                if ($tables_result) {
                    $row = $tables_result->fetch_assoc();
                    $result['tables_count'] = $row['count'];
                }
                
                // Contar usuarios
                $users_result = $this->connection->query("SELECT COUNT(*) as count FROM users WHERE 1");
                if ($users_result) {
                    $row = $users_result->fetch_assoc();
                    $result['users_count'] = $row['count'];
                }
            }
        }
        
        return $result;
    }
}

// Inicializar conexión de base de datos
$db = DatabaseManager::getInstance();
$GLOBALS['db'] = $db;

// Variable global para conexión (compatibilidad)
$conn = $db->getConnection();
$GLOBALS['conn'] = $conn;

/**
 * Función para autenticar usuario (con fallback)
 */
function authenticateUser($username, $password) {
    global $db, $DEFAULT_USERS;
    
    // Intentar autenticación con base de datos
    if ($db->isConnected()) {
        $result = $db->query("SELECT * FROM users WHERE username = ? AND status = 'active'", [$username]);
        
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Verificar contraseña (hash o texto plano para compatibilidad)
            if (password_verify($password, $user['password']) || $password === $user['password']) {
                // Actualizar último login
                $db->query("UPDATE users SET last_login = NOW() WHERE id = ?", [$user['id']]);
                
                return [
                    'success' => true,
                    'user' => $user,
                    'source' => 'database',
                    'connection' => $db->getConnectionInfo()
                ];
            }
        }
    }
    
    // Fallback a usuarios por defecto
    if (isset($DEFAULT_USERS[$username])) {
        $user = $DEFAULT_USERS[$username];
        
        if ($password === $user['password']) {
            return [
                'success' => true,
                'user' => $user,
                'source' => 'default',
                'connection' => ['type' => 'fallback', 'status' => 'no_database']
            ];
        }
    }
    
    return [
        'success' => false,
        'message' => 'Credenciales incorrectas',
        'connection' => $db->getConnectionInfo()
    ];
}

/**
 * Función para obtener estadísticas del sistema
 */
function getSystemStats() {
    global $db;
    
    $stats = [
        'users_active' => 0,
        'threats_detected_today' => 0,
        'ai_detections_today' => 0,
        'system_uptime' => '99.9%',
        'security_level' => 95,
        'database_status' => 'disconnected'
    ];
    
    if ($db->isConnected()) {
        $stats['database_status'] = 'connected';
        
        // Usuarios activos
        $result = $db->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'");
        if ($result) {
            $row = $result->fetch_assoc();
            $stats['users_active'] = $row['count'];
        }
        
        // Amenazas detectadas hoy
        $result = $db->query("SELECT COUNT(*) as count FROM security_events WHERE DATE(created_at) = CURDATE()");
        if ($result) {
            $row = $result->fetch_assoc();
            $stats['threats_detected_today'] = $row['count'];
        }
        
        // Detecciones de IA hoy
        $result = $db->query("SELECT COUNT(*) as count FROM ai_detections WHERE DATE(created_at) = CURDATE()");
        if ($result) {
            $row = $result->fetch_assoc();
            $stats['ai_detections_today'] = $row['count'];
        }
    } else {
        // Estadísticas simuladas si no hay base de datos
        $stats['users_active'] = 2;
        $stats['threats_detected_today'] = rand(15, 45);
        $stats['ai_detections_today'] = rand(5, 15);
    }
    
    return $stats;
}

// Configuración de seguridad
define('ENCRYPTION_KEY', 'GuardianIA_v3.0_Anderson_Premium_SecretKey_2024');
define('SESSION_LIFETIME', 3600 * 24 * 30);
define('CSRF_TOKEN_LIFETIME', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900);

// Configuración Premium (ACTIVADA)
define('PREMIUM_ENABLED', true);
define('PREMIUM_USER', 'anderson');
define('MONTHLY_PRICE', 60000);
define('ANNUAL_DISCOUNT', 0.15);
define('PREMIUM_FEATURES', [
    'ai_antivirus' => true,
    'quantum_encryption' => true,
    'predictive_analysis' => true,
    'ai_vpn' => true,
    'advanced_chatbot' => true,
    'real_time_monitoring' => true,
    'unlimited_conversations' => true,
    'priority_support' => true
]);

// Configuración de IA
define('AI_DETECTION_THRESHOLD', 0.85);
define('CONSCIOUSNESS_THRESHOLD', 0.7);
define('THREAT_LEVEL_HIGH', 8);
define('AI_LEARNING_ENABLED', true);
define('NEURAL_NETWORK_DEPTH', 7);

// Configuración de VPN
define('VPN_ENABLED', true);
define('VPN_SERVERS', [
    'colombia-bogota' => 'Bogotá, Colombia',
    'usa-miami' => 'Miami, USA',
    'spain-madrid' => 'Madrid, España',
    'japan-tokyo' => 'Tokio, Japón'
]);

// Configuración de logs
define('LOG_LEVEL', 'INFO');
define('LOG_ROTATION_SIZE', 10485760);
define('LOG_RETENTION_DAYS', 30);

// Crear directorios necesarios
$directories = ['logs', 'uploads', 'cache'];
foreach ($directories as $dir) {
    if (!file_exists(__DIR__ . '/' . $dir)) {
        @mkdir(__DIR__ . '/' . $dir, 0755, true);
    }
}

// Funciones globales
function logEvent($level, $message, $context = []) {
    $timestamp = date('Y-m-d H:i:s');
    $user_id = $_SESSION['user_id'] ?? 'anonymous';
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    $log_entry = [
        'timestamp' => $timestamp,
        'level' => $level,
        'user_id' => $user_id,
        'ip' => $ip,
        'message' => $message,
        'context' => $context
    ];
    
    $log_line = json_encode($log_entry, JSON_UNESCAPED_UNICODE) . PHP_EOL;
    @file_put_contents(__DIR__ . '/logs/guardian.log', $log_line, FILE_APPEND | LOCK_EX);
}

function encryptData($data) {
    $key = hash('sha256', ENCRYPTION_KEY);
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

function decryptData($data) {
    $key = hash('sha256', ENCRYPTION_KEY);
    list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encrypted_data, 'AES-256-CBC', $key, 0, $iv);
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function isPremiumUser($user_id = null) {
    if (!PREMIUM_ENABLED) return false;
    
    $username = $_SESSION['username'] ?? null;
    if ($username === PREMIUM_USER) return true;
    
    global $db;
    if ($db->isConnected() && $user_id) {
        $result = $db->query("SELECT COUNT(*) as count FROM users WHERE id = ? AND premium_status = 'premium'", [$user_id]);
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['count'] > 0;
        }
    }
    
    return false;
}

function hasFeature($feature) {
    return PREMIUM_FEATURES[$feature] ?? false;
}

// Configuración de sesión segura
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

session_set_cookie_params([
    'lifetime' => SESSION_LIFETIME,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Strict'
]);

// Headers de seguridad
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Inicializar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Test de conexión automático
$connection_test = $db->testConnection();

// Log de inicialización
logEvent('INFO', 'GuardianIA v3.0 FINAL initialized', [
    'version' => APP_VERSION,
    'developer' => DEVELOPER,
    'premium_enabled' => PREMIUM_ENABLED,
    'php_version' => PHP_VERSION,
    'database_connected' => $connection_test['connected'],
    'connection_type' => $connection_test['connection_info']['type'] ?? 'none'
]);

define('GUARDIAN_CONFIG_LOADED', true);

// Función de respuesta JSON para APIs
function jsonResponse($data, $status_code = 200) {
    http_response_code($status_code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Función para verificar conexión (para debugging)
function checkDatabaseConnection() {
    global $db;
    
    $test = $db->testConnection();
    
    return [
        'success' => $test['connected'],
        'message' => $test['connected'] ? 'Conexión exitosa' : 'Error de conexión',
        'timestamp' => date('Y-m-d H:i:s'),
        'data' => $test
    ];
}

?>

