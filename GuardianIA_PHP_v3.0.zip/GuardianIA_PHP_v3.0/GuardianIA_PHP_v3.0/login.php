<?php
/**
 * Sistema de Login y Registro - GuardianIA v3.0
 * Anderson Mamian Chicangana - Membresía Premium
 * Sistema que funciona con o sin MySQL
 */

session_start();

// Configuración
$config = [
    'db_host' => 'localhost',
    'db_user' => 'root',  // Usar root temporalmente
    'db_pass' => '0987654321',
    'db_name' => 'guardianai_db',
    'use_database' => true
];

// Usuarios por defecto (si no hay base de datos)
$default_users = [
    'anderson' => [
        'password' => 'Ander12345@',
        'email' => 'anderson@guardianai.com',
        'fullname' => 'Anderson Mamian Chicangana',
        'user_type' => 'admin',
        'premium_status' => 'premium',
        'status' => 'active'
    ],
    'admin' => [
        'password' => 'admin123',
        'email' => 'admin@guardianai.com',
        'fullname' => 'Administrador GuardianIA',
        'user_type' => 'admin',
        'premium_status' => 'basic',
        'status' => 'active'
    ]
];

/**
 * Función para conectar a base de datos
 */
function connectDB($config) {
    try {
        $conn = new mysqli($config['db_host'], $config['db_user'], $config['db_pass'], $config['db_name']);
        
        if ($conn->connect_error) {
            return false;
        }
        
        return $conn;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Función para autenticar usuario
 */
function authenticateUser($username, $password, $config, $default_users) {
    // Intentar con base de datos primero
    if ($config['use_database']) {
        $conn = connectDB($config);
        
        if ($conn) {
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $user = $result->fetch_assoc();
                
                // Verificar contraseña (hash o texto plano para compatibilidad)
                if (password_verify($password, $user['password']) || $password === $user['password']) {
                    $conn->close();
                    return [
                        'success' => true,
                        'user' => $user,
                        'source' => 'database'
                    ];
                }
            }
            
            $conn->close();
        }
    }
    
    // Fallback a usuarios por defecto
    if (isset($default_users[$username])) {
        $user = $default_users[$username];
        
        if ($password === $user['password']) {
            return [
                'success' => true,
                'user' => array_merge($user, ['username' => $username, 'id' => 1]),
                'source' => 'default'
            ];
        }
    }
    
    return [
        'success' => false,
        'message' => 'Credenciales incorrectas'
    ];
}

/**
 * Función para registrar usuario
 */
function registerUser($data, $config) {
    // Validar datos
    if (empty($data['username']) || empty($data['password']) || empty($data['email'])) {
        return [
            'success' => false,
            'message' => 'Todos los campos son obligatorios'
        ];
    }
    
    // Validar formato de email
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        return [
            'success' => false,
            'message' => 'Formato de email inválido'
        ];
    }
    
    // Intentar registrar en base de datos
    if ($config['use_database']) {
        $conn = connectDB($config);
        
        if ($conn) {
            // Verificar si el usuario ya existe
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->bind_param('ss', $data['username'], $data['email']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $conn->close();
                return [
                    'success' => false,
                    'message' => 'Usuario o email ya existe'
                ];
            }
            
            // Insertar nuevo usuario
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, fullname, user_type, premium_status, status, created_at) VALUES (?, ?, ?, ?, 'user', 'basic', 'active', NOW())");
            $stmt->bind_param('ssss', $data['username'], $data['email'], $hashedPassword, $data['fullname']);
            
            if ($stmt->execute()) {
                $userId = $conn->insert_id;
                $conn->close();
                
                return [
                    'success' => true,
                    'message' => 'Usuario registrado exitosamente',
                    'user_id' => $userId
                ];
            }
            
            $conn->close();
        }
    }
    
    return [
        'success' => false,
        'message' => 'Error del sistema. Intente más tarde.'
    ];
}

/**
 * Procesar formularios
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'login') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        $result = authenticateUser($username, $password, $config, $default_users);
        
        if ($result['success']) {
            $_SESSION['user'] = $result['user'];
            $_SESSION['logged_in'] = true;
            $_SESSION['login_time'] = time();
            
            echo json_encode([
                'success' => true,
                'message' => 'Login exitoso',
                'redirect' => $result['user']['user_type'] === 'admin' ? 'admin/index.php' : 'user_dashboard.php',
                'user' => $result['user'],
                'source' => $result['source']
            ]);
        } else {
            echo json_encode($result);
        }
        
        exit;
    }
    
    if ($action === 'register') {
        $data = [
            'username' => $_POST['username'] ?? '',
            'email' => $_POST['email'] ?? '',
            'password' => $_POST['password'] ?? '',
            'fullname' => $_POST['fullname'] ?? ''
        ];
        
        $result = registerUser($data, $config);
        echo json_encode($result);
        exit;
    }
}

/**
 * Verificar si ya está logueado
 */
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    $user = $_SESSION['user'];
    $redirect = $user['user_type'] === 'admin' ? 'admin/index.php' : 'user_dashboard.php';
    header("Location: $redirect");
    exit;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA v3.0 - Login & Registro</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        /* Partículas de fondo */
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 100%;
            max-width: 450px;
            position: relative;
            z-index: 10;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logo {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo h1 {
            color: #333;
            font-size: 2.5em;
            font-weight: 700;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .logo p {
            color: #666;
            font-size: 1.1em;
            font-weight: 500;
        }

        .form-container {
            position: relative;
        }

        .form-tabs {
            display: flex;
            margin-bottom: 30px;
            background: #f8f9fa;
            border-radius: 10px;
            padding: 5px;
        }

        .tab-button {
            flex: 1;
            padding: 12px 20px;
            border: none;
            background: transparent;
            color: #666;
            font-size: 1em;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .tab-button.active {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 0.95em;
        }

        .form-group input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 1em;
            transition: all 0.3s ease;
            background: #fff;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .submit-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }

        .submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
            text-align: center;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .form-section {
            display: none;
        }

        .form-section.active {
            display: block;
        }

        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .credentials-info {
            background: #e3f2fd;
            border: 1px solid #bbdefb;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            font-size: 0.9em;
        }

        .credentials-info h4 {
            color: #1976d2;
            margin-bottom: 10px;
        }

        .credentials-info p {
            color: #424242;
            margin: 5px 0;
        }

        @media (max-width: 480px) {
            .container {
                margin: 20px;
                padding: 30px 25px;
            }
            
            .logo h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <!-- Partículas de fondo -->
    <div class="particles" id="particles"></div>

    <div class="container">
        <div class="logo">
            <h1>🛡️ GuardianIA</h1>
            <p>Sistema de Ciberseguridad v3.0</p>
        </div>

        <div id="message-container"></div>
        
        <div class="form-container">
            <div class="form-tabs">
                <button class="tab-button active" onclick="switchTab('login')">Iniciar Sesión</button>
                <button class="tab-button" onclick="switchTab('register')">Registrarse</button>
            </div>

            <!-- Formulario de Login -->
            <div id="login-section" class="form-section active">
                <form id="login-form">
                    <input type="hidden" name="action" value="login">
                    
                    <div class="form-group">
                        <label for="login-username">Usuario</label>
                        <input type="text" id="login-username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="login-password">Contraseña</label>
                        <input type="password" id="login-password" name="password" required>
                    </div>
                    
                    <button type="submit" class="submit-btn">Iniciar Sesión</button>
                </form>

                <div class="credentials-info">
                    <h4>👑 Credenciales de Administrador</h4>
                    <p><strong>Usuario:</strong> anderson</p>
                    <p><strong>Contraseña:</strong> Ander12345@</p>
                    <p><strong>Tipo:</strong> Admin Premium</p>
                    <hr style="margin: 10px 0; border: none; border-top: 1px solid #ccc;">
                    <p><strong>Usuario:</strong> admin</p>
                    <p><strong>Contraseña:</strong> admin123</p>
                    <p><strong>Tipo:</strong> Admin Básico</p>
                </div>
            </div>

            <!-- Formulario de Registro -->
            <div id="register-section" class="form-section">
                <form id="register-form">
                    <input type="hidden" name="action" value="register">
                    
                    <div class="form-group">
                        <label for="register-fullname">Nombre Completo</label>
                        <input type="text" id="register-fullname" name="fullname" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="register-username">Usuario</label>
                        <input type="text" id="register-username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="register-email">Email</label>
                        <input type="email" id="register-email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="register-password">Contraseña</label>
                        <input type="password" id="register-password" name="password" required>
                    </div>
                    
                    <button type="submit" class="submit-btn">Registrarse</button>
                </form>
            </div>

            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p>Procesando...</p>
            </div>
        </div>
    </div>

    <script>
        // Crear partículas de fondo
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 50;

            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.top = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 6 + 's';
                particle.style.animationDuration = (Math.random() * 3 + 3) + 's';
                particlesContainer.appendChild(particle);
            }
        }

        // Cambiar entre tabs
        function switchTab(tab) {
            // Actualizar botones
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            event.target.classList.add('active');

            // Actualizar secciones
            document.querySelectorAll('.form-section').forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(tab + '-section').classList.add('active');

            // Limpiar mensajes
            document.getElementById('message-container').innerHTML = '';
        }

        // Mostrar mensaje
        function showMessage(message, type) {
            const container = document.getElementById('message-container');
            container.innerHTML = `<div class="message ${type}">${message}</div>`;
        }

        // Mostrar loading
        function showLoading(show) {
            const loading = document.getElementById('loading');
            const forms = document.querySelectorAll('.form-section');
            
            if (show) {
                loading.style.display = 'block';
                forms.forEach(form => form.style.display = 'none');
            } else {
                loading.style.display = 'none';
                forms.forEach(form => form.style.display = 'none');
                document.querySelector('.form-section.active').style.display = 'block';
            }
        }

        // Manejar formulario de login
        document.getElementById('login-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            showLoading(true);
            
            const formData = new FormData(this);
            
            try {
                const response = await fetch('', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                showLoading(false);
                
                if (result.success) {
                    showMessage('¡Login exitoso! Redirigiendo...', 'success');
                    setTimeout(() => {
                        window.location.href = result.redirect;
                    }, 1500);
                } else {
                    showMessage(result.message, 'error');
                }
            } catch (error) {
                showLoading(false);
                showMessage('Error de conexión. Intente nuevamente.', 'error');
            }
        });

        // Manejar formulario de registro
        document.getElementById('register-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            showLoading(true);
            
            const formData = new FormData(this);
            
            try {
                const response = await fetch('', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                showLoading(false);
                
                if (result.success) {
                    showMessage('¡Usuario registrado exitosamente! Ahora puedes iniciar sesión.', 'success');
                    setTimeout(() => {
                        switchTab('login');
                    }, 2000);
                } else {
                    showMessage(result.message, 'error');
                }
            } catch (error) {
                showLoading(false);
                showMessage('Error de conexión. Intente nuevamente.', 'error');
            }
        });

        // Inicializar
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
        });
    </script>
</body>
</html>

