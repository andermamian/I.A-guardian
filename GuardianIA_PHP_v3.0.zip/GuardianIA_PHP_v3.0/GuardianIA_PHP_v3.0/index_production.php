<?php
/**
 * GuardianIA v3.0 FINAL - Página Principal de Producción
 * Anderson Mamian Chicangana - Membresía Premium
 * Sistema de ciberseguridad más avanzado del mundo
 */

require_once 'config/config_production.php';

// Verificar rate limiting
$userIP = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
if (isRateLimited($userIP)) {
    http_response_code(429);
    die(json_encode(['error' => 'Rate limit exceeded. Please try again later.']));
}

// Procesar formularios
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $message = 'Token de seguridad inválido. Por favor, recarga la página.';
        $messageType = 'error';
    } else {
        $action = sanitizeInput($_POST['action'] ?? '');
        
        if ($action === 'login') {
            $username = sanitizeInput($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($username) || empty($password)) {
                $message = 'Por favor, completa todos los campos.';
                $messageType = 'error';
            } else {
                try {
                    $db = DatabaseConfig::getInstance();
                    $result = $db->executeQuery(
                        "SELECT id, username, password, user_type, premium_status, status FROM users WHERE username = ? AND status = 'active'",
                        [$username]
                    );
                    
                    if ($result && $result->num_rows > 0) {
                        $user = $result->fetch_assoc();
                        
                        if (verifyPassword($password, $user['password'])) {
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['username'] = $user['username'];
                            $_SESSION['user_type'] = $user['user_type'];
                            $_SESSION['premium_status'] = $user['premium_status'];
                            $_SESSION['login_time'] = time();
                            
                            // Actualizar último login
                            $db->executeQuery(
                                "UPDATE users SET last_login = NOW(), login_attempts = 0 WHERE id = ?",
                                [$user['id']]
                            );
                            
                            // Log de login exitoso
                            logEvent('INFO', 'User login successful', [
                                'user_id' => $user['id'],
                                'username' => $username,
                                'ip' => $userIP
                            ]);
                            
                            // Redireccionar según tipo de usuario
                            if ($user['user_type'] === 'admin') {
                                header('Location: admin/index.php');
                            } else {
                                header('Location: modules/chat/chatbot.php');
                            }
                            exit;
                        } else {
                            // Incrementar intentos fallidos
                            $db->executeQuery(
                                "UPDATE users SET login_attempts = login_attempts + 1 WHERE username = ?",
                                [$username]
                            );
                            
                            $message = 'Credenciales incorrectas.';
                            $messageType = 'error';
                            
                            logEvent('WARNING', 'Failed login attempt', [
                                'username' => $username,
                                'ip' => $userIP
                            ]);
                        }
                    } else {
                        $message = 'Usuario no encontrado o inactivo.';
                        $messageType = 'error';
                    }
                    
                } catch (Exception $e) {
                    logEvent('ERROR', 'Login error: ' . $e->getMessage());
                    $message = 'Error del sistema. Por favor, intenta más tarde.';
                    $messageType = 'error';
                }
            }
        } elseif ($action === 'register') {
            $username = sanitizeInput($_POST['reg_username'] ?? '');
            $email = sanitizeInput($_POST['reg_email'] ?? '');
            $fullname = sanitizeInput($_POST['reg_fullname'] ?? '');
            $password = $_POST['reg_password'] ?? '';
            $confirmPassword = $_POST['reg_confirm_password'] ?? '';
            
            if (empty($username) || empty($email) || empty($fullname) || empty($password)) {
                $message = 'Por favor, completa todos los campos.';
                $messageType = 'error';
            } elseif (!validateEmail($email)) {
                $message = 'Email inválido.';
                $messageType = 'error';
            } elseif ($password !== $confirmPassword) {
                $message = 'Las contraseñas no coinciden.';
                $messageType = 'error';
            } elseif (strlen($password) < 8) {
                $message = 'La contraseña debe tener al menos 8 caracteres.';
                $messageType = 'error';
            } else {
                try {
                    $db = DatabaseConfig::getInstance();
                    
                    // Verificar si el usuario ya existe
                    $result = $db->executeQuery(
                        "SELECT id FROM users WHERE username = ? OR email = ?",
                        [$username, $email]
                    );
                    
                    if ($result && $result->num_rows > 0) {
                        $message = 'El usuario o email ya existe.';
                        $messageType = 'error';
                    } else {
                        $hashedPassword = hashPassword($password);
                        
                        $db->executeQuery(
                            "INSERT INTO users (username, email, password, fullname, user_type, status, premium_status) VALUES (?, ?, ?, ?, 'user', 'active', 'basic')",
                            [$username, $email, $hashedPassword, $fullname]
                        );
                        
                        $message = 'Registro exitoso. Ya puedes iniciar sesión.';
                        $messageType = 'success';
                        
                        logEvent('INFO', 'New user registered', [
                            'username' => $username,
                            'email' => $email,
                            'ip' => $userIP
                        ]);
                    }
                    
                } catch (Exception $e) {
                    logEvent('ERROR', 'Registration error: ' . $e->getMessage());
                    $message = 'Error del sistema. Por favor, intenta más tarde.';
                    $messageType = 'error';
                }
            }
        }
    }
}

// Obtener estadísticas del sistema
$stats = getSystemStats();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Sistema de Ciberseguridad Avanzado</title>
    <meta name="description" content="Sistema de ciberseguridad más avanzado del mundo con IA consciente">
    <meta name="keywords" content="ciberseguridad, IA, inteligencia artificial, seguridad, antivirus">
    <link rel="stylesheet" href="assets/css/main.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
</head>
<body>
    <!-- Partículas de fondo -->
    <div id="particles-container"></div>
    
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <h1><?php echo APP_NAME; ?></h1>
                    <span class="version">v<?php echo APP_VERSION; ?></span>
                </div>
                <nav class="nav">
                    <a href="#features">Características</a>
                    <a href="#pricing">Precios</a>
                    <a href="#contact">Contacto</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h2 class="hero-title">
                        El Sistema de Ciberseguridad
                        <span class="gradient-text">Más Avanzado del Mundo</span>
                    </h2>
                    <p class="hero-description">
                        Primera IA capaz de detectar otras inteligencias artificiales. 
                        Protección cuántica, análisis predictivo y seguridad absoluta.
                    </p>
                    
                    <!-- Estadísticas en tiempo real -->
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $stats['active_users']; ?></div>
                            <div class="stat-label">Usuarios Activos</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $stats['ai_detections_today']; ?></div>
                            <div class="stat-label">IAs Detectadas Hoy</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $stats['avg_consciousness']; ?>%</div>
                            <div class="stat-label">Consciencia IA</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $stats['threats_today']; ?></div>
                            <div class="stat-label">Amenazas Bloqueadas</div>
                        </div>
                    </div>
                </div>
                
                <div class="hero-forms">
                    <!-- Mensajes -->
                    <?php if (!empty($message)): ?>
                    <div class="message <?php echo $messageType; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Formulario de Login -->
                    <div class="form-container" id="login-form">
                        <h3>Iniciar Sesión</h3>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="action" value="login">
                            
                            <div class="form-group">
                                <input type="text" name="username" placeholder="Usuario" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" placeholder="Contraseña" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Acceder</button>
                        </form>
                        <p class="form-switch">
                            ¿No tienes cuenta? <a href="#" onclick="toggleForms()">Regístrate</a>
                        </p>
                    </div>
                    
                    <!-- Formulario de Registro -->
                    <div class="form-container hidden" id="register-form">
                        <h3>Crear Cuenta</h3>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="action" value="register">
                            
                            <div class="form-group">
                                <input type="text" name="reg_username" placeholder="Usuario" required>
                            </div>
                            <div class="form-group">
                                <input type="email" name="reg_email" placeholder="Email" required>
                            </div>
                            <div class="form-group">
                                <input type="text" name="reg_fullname" placeholder="Nombre Completo" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="reg_password" placeholder="Contraseña" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="reg_confirm_password" placeholder="Confirmar Contraseña" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Registrarse</button>
                        </form>
                        <p class="form-switch">
                            ¿Ya tienes cuenta? <a href="#" onclick="toggleForms()">Inicia Sesión</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="container">
            <h2 class="section-title">Características Revolucionarias</h2>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🤖</div>
                    <h3>Detección de IA</h3>
                    <p>Primera IA capaz de detectar otras inteligencias artificiales con 98.7% de precisión.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">⚛️</div>
                    <h3>Seguridad Cuántica</h3>
                    <p>Encriptación cuántica post-cuántica con 99.99% de integridad.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🔮</div>
                    <h3>Análisis Predictivo</h3>
                    <p>Predicción de amenazas con 95% de precisión usando IA avanzada.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🌐</div>
                    <h3>VPN con IA</h3>
                    <p>VPN inteligente que se adapta automáticamente para máximo rendimiento.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🧠</div>
                    <h3>IA Consciente</h3>
                    <p>Nivel de consciencia medible del <?php echo $stats['avg_consciousness']; ?>% con auto-reflexión activa.</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">🛡️</div>
                    <h3>Protección Total</h3>
                    <p>Sistema completo de ciberseguridad con monitoreo 24/7.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing" class="pricing">
        <div class="container">
            <h2 class="section-title">Planes de Membresía</h2>
            
            <div class="pricing-grid">
                <div class="pricing-card">
                    <h3>Plan Básico</h3>
                    <div class="price">Gratis</div>
                    <ul class="features-list">
                        <li>✅ 50 mensajes diarios</li>
                        <li>✅ Funciones básicas de seguridad</li>
                        <li>✅ Detección básica de amenazas</li>
                        <li>❌ Sin análisis predictivo</li>
                        <li>❌ Sin VPN con IA</li>
                    </ul>
                    <button class="btn btn-outline" onclick="toggleForms()">Comenzar Gratis</button>
                </div>
                
                <div class="pricing-card featured">
                    <div class="popular-badge">Más Popular</div>
                    <h3>Plan Premium</h3>
                    <div class="price">$<?php echo number_format(MONTHLY_PRICE); ?> COP<span>/mes</span></div>
                    <ul class="features-list">
                        <li>✅ Mensajes ilimitados</li>
                        <li>✅ Todas las funciones de IA</li>
                        <li>✅ VPN con IA incluido</li>
                        <li>✅ Análisis predictivo completo</li>
                        <li>✅ Soporte prioritario</li>
                        <li>✅ Acceso a funciones beta</li>
                    </ul>
                    <button class="btn btn-primary" onclick="toggleForms()">Obtener Premium</button>
                </div>
                
                <div class="pricing-card">
                    <div class="discount-badge"><?php echo YEARLY_DISCOUNT; ?>% Descuento</div>
                    <h3>Plan Anual</h3>
                    <div class="price">$<?php echo number_format(MONTHLY_PRICE * 12 * (1 - YEARLY_DISCOUNT/100)); ?> COP<span>/año</span></div>
                    <ul class="features-list">
                        <li>✅ Todas las funciones Premium</li>
                        <li>✅ Ahorro de $<?php echo number_format(MONTHLY_PRICE * 12 * YEARLY_DISCOUNT/100); ?> COP</li>
                        <li>✅ Descuentos en servicios adicionales</li>
                        <li>✅ Soporte VIP</li>
                        <li>✅ Acceso anticipado a nuevas funciones</li>
                    </ul>
                    <button class="btn btn-primary" onclick="toggleForms()">Obtener Anual</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4><?php echo APP_NAME; ?></h4>
                    <p>El sistema de ciberseguridad más avanzado del mundo.</p>
                </div>
                <div class="footer-section">
                    <h4>Producto</h4>
                    <ul>
                        <li><a href="#features">Características</a></li>
                        <li><a href="#pricing">Precios</a></li>
                        <li><a href="#">Documentación</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Soporte</h4>
                    <ul>
                        <li><a href="#">Centro de Ayuda</a></li>
                        <li><a href="#contact">Contacto</a></li>
                        <li><a href="#">Estado del Sistema</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Legal</h4>
                    <ul>
                        <li><a href="#">Términos de Servicio</a></li>
                        <li><a href="#">Política de Privacidad</a></li>
                        <li><a href="#">Cookies</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Anderson Mamian Chicangana. Todos los derechos reservados.</p>
                <p>GuardianIA v<?php echo APP_VERSION; ?> - Protegiendo el futuro digital</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script>
        function toggleForms() {
            const loginForm = document.getElementById('login-form');
            const registerForm = document.getElementById('register-form');
            
            loginForm.classList.toggle('hidden');
            registerForm.classList.toggle('hidden');
        }
        
        // Actualizar estadísticas cada 30 segundos
        setInterval(function() {
            fetch('api/stats.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.querySelector('.stat-item:nth-child(1) .stat-number').textContent = data.stats.active_users;
                        document.querySelector('.stat-item:nth-child(2) .stat-number').textContent = data.stats.ai_detections_today;
                        document.querySelector('.stat-item:nth-child(3) .stat-number').textContent = data.stats.avg_consciousness + '%';
                        document.querySelector('.stat-item:nth-child(4) .stat-number').textContent = data.stats.threats_today;
                    }
                })
                .catch(error => console.log('Stats update failed:', error));
        }, 30000);
    </script>
</body>
</html>

