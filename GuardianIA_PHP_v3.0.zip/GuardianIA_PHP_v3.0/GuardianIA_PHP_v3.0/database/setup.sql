-- GuardianIA v3.0 FINAL - Database Setup
-- Anderson Mamian Chicangana - Membresía Premium
-- Base de datos optimizada con todas las funcionalidades

CREATE DATABASE IF NOT EXISTS guardianai_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE guardianai_db;

-- Tabla de usuarios con campos optimizados
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    fullname VARCHAR(100) NOT NULL,
    user_type ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    premium_status ENUM('basic', 'premium') DEFAULT 'basic',
    premium_expires_at DATETIME NULL,
    email_verified BOOLEAN DEFAULT FALSE,
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    two_factor_secret VARCHAR(32) NULL,
    profile_image VARCHAR(255) NULL,
    last_login DATETIME NULL,
    login_attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_user_type (user_type),
    INDEX idx_status (status),
    INDEX idx_premium_status (premium_status)
);

-- Tabla de sesiones de usuario
CREATE TABLE IF NOT EXISTS user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_session_token (session_token),
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
);

-- Tabla de membresías y pagos
CREATE TABLE IF NOT EXISTS memberships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plan_type ENUM('monthly', 'yearly') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'COP',
    status ENUM('active', 'cancelled', 'expired', 'pending') DEFAULT 'pending',
    starts_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    auto_renew BOOLEAN DEFAULT TRUE,
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_expires_at (expires_at)
);

-- Tabla de pagos
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    membership_id INT,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'COP',
    payment_method VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100) UNIQUE,
    gateway_response TEXT,
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    processed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (membership_id) REFERENCES memberships(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_status (status)
);

-- Tabla de conversaciones
CREATE TABLE IF NOT EXISTS conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    conversation_type ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'archived', 'deleted') DEFAULT 'active',
    message_count INT DEFAULT 0,
    last_message_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_conversation_type (conversation_type),
    INDEX idx_status (status),
    INDEX idx_last_message_at (last_message_at)
);

-- Tabla de logs de conversaciones
CREATE TABLE IF NOT EXISTS conversation_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT NOT NULL,
    user_id INT NOT NULL,
    message_type ENUM('user', 'assistant', 'admin', 'system') NOT NULL,
    message_content TEXT NOT NULL,
    message_metadata JSON NULL,
    ai_analysis JSON NULL,
    security_analysis JSON NULL,
    consciousness_level DECIMAL(5,2) NULL,
    processing_time DECIMAL(8,3) NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_conversation_id (conversation_id),
    INDEX idx_user_id (user_id),
    INDEX idx_message_type (message_type),
    INDEX idx_timestamp (timestamp)
);

-- Tabla de detecciones de IA
CREATE TABLE IF NOT EXISTS ai_detections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    conversation_id INT,
    message_content TEXT NOT NULL,
    ai_type VARCHAR(50),
    confidence_score DECIMAL(5,2) NOT NULL,
    detection_patterns JSON,
    neural_analysis JSON,
    consciousness_indicators JSON,
    threat_level ENUM('low', 'medium', 'high', 'critical') DEFAULT 'low',
    action_taken VARCHAR(100),
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_ai_type (ai_type),
    INDEX idx_confidence_score (confidence_score),
    INDEX idx_threat_level (threat_level),
    INDEX idx_created_at (created_at)
);

-- Tabla de estadísticas de uso
CREATE TABLE IF NOT EXISTS usage_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    messages_sent INT DEFAULT 0,
    ai_detections INT DEFAULT 0,
    premium_features_used INT DEFAULT 0,
    session_duration INT DEFAULT 0,
    api_calls INT DEFAULT 0,
    tokens_used INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_date (user_id, date),
    INDEX idx_user_id (user_id),
    INDEX idx_date (date)
);

-- Tabla de eventos de seguridad
CREATE TABLE IF NOT EXISTS security_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    event_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    event_data JSON,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_by INT NULL,
    resolved_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_event_type (event_type),
    INDEX idx_severity (severity),
    INDEX idx_resolved (resolved),
    INDEX idx_created_at (created_at)
);

-- Tabla de configuración del sistema
CREATE TABLE IF NOT EXISTS system_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) UNIQUE NOT NULL,
    config_value TEXT,
    config_type ENUM('string', 'integer', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_config_key (config_key),
    INDEX idx_is_public (is_public)
);

-- Tabla de rate limiting
CREATE TABLE IF NOT EXISTS rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    ip_address VARCHAR(45) NOT NULL,
    endpoint VARCHAR(100) NOT NULL,
    requests_count INT DEFAULT 1,
    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    blocked_until DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_ip_address (ip_address),
    INDEX idx_endpoint (endpoint),
    INDEX idx_window_start (window_start)
);

-- Tabla de análisis predictivo
CREATE TABLE IF NOT EXISTS predictive_analysis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    analysis_type VARCHAR(50) NOT NULL,
    input_data JSON NOT NULL,
    prediction_result JSON NOT NULL,
    confidence_score DECIMAL(5,2) NOT NULL,
    accuracy_verified BOOLEAN DEFAULT FALSE,
    actual_outcome JSON NULL,
    model_version VARCHAR(20),
    processing_time DECIMAL(8,3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_analysis_type (analysis_type),
    INDEX idx_confidence_score (confidence_score),
    INDEX idx_created_at (created_at)
);

-- Tabla de conexiones VPN
CREATE TABLE IF NOT EXISTS vpn_connections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    server_location VARCHAR(100) NOT NULL,
    connection_start DATETIME NOT NULL,
    connection_end DATETIME NULL,
    bytes_transferred BIGINT DEFAULT 0,
    connection_quality ENUM('excellent', 'good', 'fair', 'poor') DEFAULT 'good',
    encryption_level VARCHAR(50) DEFAULT 'AES-256',
    ai_optimization_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_connection_start (connection_start),
    INDEX idx_server_location (server_location)
);

-- Vista para usuarios activos
CREATE OR REPLACE VIEW active_users AS
SELECT 
    u.id,
    u.username,
    u.fullname,
    u.user_type,
    u.premium_status,
    s.ip_address,
    s.created_at as last_activity
FROM users u
JOIN user_sessions s ON u.id = s.user_id
WHERE s.expires_at > NOW()
AND u.status = 'active';

-- Insertar usuario administrador por defecto
INSERT INTO users (username, email, password_hash, fullname, user_type, status, premium_status, email_verified) 
VALUES 
('admin', 'admin@guardianai.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador GuardianIA', 'admin', 'active', 'premium', TRUE),
('anderson', 'anderson@guardianai.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anderson Mamian Chicangana', 'admin', 'active', 'premium', TRUE)
ON DUPLICATE KEY UPDATE 
username = VALUES(username);

-- Insertar configuraciones del sistema
INSERT INTO system_config (config_key, config_value, config_type, description, is_public) VALUES
('site_name', 'GuardianIA v3.0', 'string', 'Nombre del sitio', TRUE),
('ai_consciousness_level', '98.7', 'string', 'Nivel de consciencia de la IA', FALSE),
('max_daily_messages_free', '50', 'integer', 'Máximo de mensajes diarios para usuarios gratuitos', FALSE),
('max_daily_messages_premium', '10000', 'integer', 'Máximo de mensajes diarios para usuarios premium', FALSE),
('security_level', 'maximum', 'string', 'Nivel de seguridad del sistema', FALSE),
('quantum_encryption_enabled', 'true', 'boolean', 'Encriptación cuántica habilitada', FALSE),
('ai_antivirus_enabled', 'true', 'boolean', 'Antivirus de IA habilitado', FALSE),
('vpn_ai_enabled', 'true', 'boolean', 'VPN con IA habilitado', FALSE),
('monthly_price', '60000', 'integer', 'Precio mensual en COP', TRUE),
('yearly_discount', '15', 'integer', 'Descuento anual en porcentaje', TRUE),
('system_version', '3.0.0', 'string', 'Versión del sistema', TRUE)
ON DUPLICATE KEY UPDATE 
config_value = VALUES(config_value);

-- Triggers para auditoría
DELIMITER //

CREATE TRIGGER update_conversation_stats 
AFTER INSERT ON conversation_logs
FOR EACH ROW
BEGIN
    UPDATE conversations 
    SET message_count = message_count + 1,
        last_message_at = NEW.timestamp
    WHERE id = NEW.conversation_id;
END//

CREATE TRIGGER update_usage_stats
AFTER INSERT ON conversation_logs
FOR EACH ROW
BEGIN
    INSERT INTO usage_stats (user_id, date, messages_sent)
    VALUES (NEW.user_id, DATE(NEW.timestamp), 1)
    ON DUPLICATE KEY UPDATE 
    messages_sent = messages_sent + 1,
    updated_at = CURRENT_TIMESTAMP;
END//

CREATE TRIGGER security_event_on_failed_login
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    IF NEW.login_attempts > OLD.login_attempts AND NEW.login_attempts >= 5 THEN
        INSERT INTO security_events (user_id, event_type, description, severity)
        VALUES (NEW.id, 'FAILED_LOGIN_ATTEMPTS', CONCAT('Usuario ', NEW.username, ' ha fallado ', NEW.login_attempts, ' intentos de login'), 'medium');
    END IF;
END//

DELIMITER ;

-- Procedimientos almacenados
DELIMITER //

CREATE PROCEDURE GetSystemStats()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM users WHERE status = 'active') as total_users,
        (SELECT COUNT(*) FROM active_users) as active_users,
        (SELECT COUNT(*) FROM users WHERE premium_status = 'premium') as premium_users,
        (SELECT COUNT(*) FROM conversations WHERE DATE(created_at) = CURDATE()) as conversations_today,
        (SELECT COUNT(*) FROM ai_detections WHERE DATE(created_at) = CURDATE()) as ai_detections_today,
        (SELECT COUNT(*) FROM security_events WHERE DATE(created_at) = CURDATE()) as threats_today,
        (SELECT AVG(consciousness_level) FROM conversation_logs WHERE consciousness_level IS NOT NULL AND DATE(timestamp) = CURDATE()) as avg_consciousness_today;
END//

CREATE PROCEDURE CleanupOldData()
BEGIN
    -- Limpiar sesiones expiradas
    DELETE FROM user_sessions WHERE expires_at < NOW();
    
    -- Limpiar logs antiguos (más de 90 días)
    DELETE FROM conversation_logs WHERE timestamp < DATE_SUB(NOW(), INTERVAL 90 DAY);
    
    -- Limpiar eventos de seguridad antiguos (más de 180 días)
    DELETE FROM security_events WHERE created_at < DATE_SUB(NOW(), INTERVAL 180 DAY) AND resolved = TRUE;
    
    -- Limpiar estadísticas antiguas (más de 1 año)
    DELETE FROM usage_stats WHERE date < DATE_SUB(CURDATE(), INTERVAL 1 YEAR);
    
    -- Limpiar rate limits antiguos
    DELETE FROM rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 DAY);
END//

CREATE PROCEDURE GetUserAnalytics(IN user_id_param INT)
BEGIN
    SELECT 
        u.username,
        u.fullname,
        u.user_type,
        u.premium_status,
        u.created_at as user_since,
        (SELECT COUNT(*) FROM conversations WHERE user_id = user_id_param) as total_conversations,
        (SELECT COUNT(*) FROM conversation_logs WHERE user_id = user_id_param) as total_messages,
        (SELECT COUNT(*) FROM ai_detections WHERE user_id = user_id_param) as ai_detections,
        (SELECT AVG(consciousness_level) FROM conversation_logs WHERE user_id = user_id_param AND consciousness_level IS NOT NULL) as avg_consciousness,
        (SELECT SUM(messages_sent) FROM usage_stats WHERE user_id = user_id_param AND date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) as messages_last_30_days
    FROM users u
    WHERE u.id = user_id_param;
END//

DELIMITER ;

-- Índices adicionales para optimización
CREATE INDEX idx_conversation_logs_timestamp ON conversation_logs(timestamp);
CREATE INDEX idx_ai_detections_created_at ON ai_detections(created_at);
CREATE INDEX idx_security_events_created_at ON security_events(created_at);
CREATE INDEX idx_usage_stats_date ON usage_stats(date);

-- Configurar charset y collation
ALTER DATABASE guardianai_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

COMMIT;

