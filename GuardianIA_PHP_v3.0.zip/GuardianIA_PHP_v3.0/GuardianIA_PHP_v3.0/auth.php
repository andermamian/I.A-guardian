<?php
require_once 'config.php';

// Iniciar sesión
session_start();

// Procesar solicitudes AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'login':
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $remember = $_POST['remember'] ?? false;
            
            $result = authenticateUser($conn, $email, $password, $remember);
            echo json_encode($result);
            exit;
            
        case 'register':
            $full_name = $_POST['full_name'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            $result = registerUser($conn, $full_name, $email, $password, $confirm_password);
            echo json_encode($result);
            exit;
            
        case 'logout':
            $result = logoutUser();
            echo json_encode($result);
            exit;
            
        case 'forgot_password':
            $email = $_POST['email'] ?? '';
            $result = sendPasswordReset($conn, $email);
            echo json_encode($result);
            exit;
            
        case 'reset_password':
            $token = $_POST['token'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            $result = resetPassword($conn, $token, $password, $confirm_password);
            echo json_encode($result);
            exit;
            
        case 'verify_email':
            $token = $_POST['token'] ?? '';
            $result = verifyEmail($conn, $token);
            echo json_encode($result);
            exit;
            
        case 'resend_verification':
            $email = $_POST['email'] ?? '';
            $result = resendVerification($conn, $email);
            echo json_encode($result);
            exit;
    }
}

// Funciones de autenticación
function authenticateUser($conn, $email, $password, $remember = false) {
    try {
        // Validar entrada
        if (empty($email) || empty($password)) {
            return ['success' => false, 'error' => 'Email y contraseña son requeridos'];
        }
        
        // Buscar usuario
        $stmt = $conn->prepare("SELECT id, full_name, email, password, email_verified, is_active, failed_attempts, locked_until FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (!$user) {
            return ['success' => false, 'error' => 'Credenciales inválidas'];
        }
        
        // Verificar si la cuenta está bloqueada
        if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
            $remaining = strtotime($user['locked_until']) - time();
            return ['success' => false, 'error' => "Cuenta bloqueada. Intenta en " . ceil($remaining / 60) . " minutos"];
        }
        
        // Verificar contraseña
        if (!password_verify($password, $user['password'])) {
            // Incrementar intentos fallidos
            $failed_attempts = $user['failed_attempts'] + 1;
            $locked_until = null;
            
            if ($failed_attempts >= 5) {
                $locked_until = date('Y-m-d H:i:s', time() + (30 * 60)); // Bloquear por 30 minutos
            }
            
            $stmt = $conn->prepare("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?");
            $stmt->bind_param("isi", $failed_attempts, $locked_until, $user['id']);
            $stmt->execute();
            
            return ['success' => false, 'error' => 'Credenciales inválidas'];
        }
        
        // Verificar si la cuenta está activa
        if (!$user['is_active']) {
            return ['success' => false, 'error' => 'Cuenta desactivada. Contacta al administrador'];
        }
        
        // Verificar si el email está verificado
        if (!$user['email_verified']) {
            return ['success' => false, 'error' => 'Email no verificado. Revisa tu bandeja de entrada', 'needs_verification' => true];
        }
        
        // Login exitoso - resetear intentos fallidos
        $stmt = $conn->prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login = NOW() WHERE id = ?");
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        
        // Crear sesión
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['full_name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['login_time'] = time();
        
        // Crear cookie de recordar si se solicita
        if ($remember) {
            $token = generateSecureToken();
            $expires = time() + (30 * 24 * 60 * 60); // 30 días
            
            $stmt = $conn->prepare("INSERT INTO remember_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
            $expires_date = date('Y-m-d H:i:s', $expires);
            $stmt->bind_param("iss", $user['id'], $token, $expires_date);
            $stmt->execute();
            
            setcookie('remember_token', $token, $expires, '/', '', true, true);
        }
        
        // Registrar login en logs
        logUserActivity($conn, $user['id'], 'login', 'Usuario inició sesión');
        
        return [
            'success' => true, 
            'message' => 'Login exitoso',
            'user' => [
                'id' => $user['id'],
                'name' => $user['full_name'],
                'email' => $user['email']
            ]
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error del servidor: ' . $e->getMessage()];
    }
}

function registerUser($conn, $full_name, $email, $password, $confirm_password) {
    try {
        // Validar entrada
        if (empty($full_name) || empty($email) || empty($password)) {
            return ['success' => false, 'error' => 'Todos los campos son requeridos'];
        }
        
        if ($password !== $confirm_password) {
            return ['success' => false, 'error' => 'Las contraseñas no coinciden'];
        }
        
        if (strlen($password) < 8) {
            return ['success' => false, 'error' => 'La contraseña debe tener al menos 8 caracteres'];
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'error' => 'Email inválido'];
        }
        
        // Verificar si el email ya existe
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return ['success' => false, 'error' => 'El email ya está registrado'];
        }
        
        // Crear usuario
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $verification_token = generateSecureToken();
        
        $stmt = $conn->prepare("
            INSERT INTO users (full_name, email, password, email_verification_token, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("ssss", $full_name, $email, $hashed_password, $verification_token);
        
        if ($stmt->execute()) {
            $user_id = $conn->insert_id;
            
            // Enviar email de verificación
            $verification_sent = sendVerificationEmail($email, $full_name, $verification_token);
            
            // Registrar actividad
            logUserActivity($conn, $user_id, 'register', 'Usuario registrado');
            
            return [
                'success' => true, 
                'message' => 'Registro exitoso. Revisa tu email para verificar tu cuenta',
                'verification_sent' => $verification_sent
            ];
        } else {
            return ['success' => false, 'error' => 'Error al crear la cuenta'];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error del servidor: ' . $e->getMessage()];
    }
}

function logoutUser() {
    try {
        // Eliminar token de recordar si existe
        if (isset($_COOKIE['remember_token'])) {
            global $conn;
            $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE token = ?");
            $stmt->bind_param("s", $_COOKIE['remember_token']);
            $stmt->execute();
            
            setcookie('remember_token', '', time() - 3600, '/', '', true, true);
        }
        
        // Registrar logout
        if (isset($_SESSION['user_id'])) {
            logUserActivity($conn, $_SESSION['user_id'], 'logout', 'Usuario cerró sesión');
        }
        
        // Destruir sesión
        session_destroy();
        
        return ['success' => true, 'message' => 'Sesión cerrada correctamente'];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error al cerrar sesión: ' . $e->getMessage()];
    }
}

function sendPasswordReset($conn, $email) {
    try {
        if (empty($email)) {
            return ['success' => false, 'error' => 'Email es requerido'];
        }
        
        // Verificar si el usuario existe
        $stmt = $conn->prepare("SELECT id, full_name FROM users WHERE email = ? AND is_active = 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (!$user) {
            // Por seguridad, no revelar si el email existe o no
            return ['success' => true, 'message' => 'Si el email existe, recibirás instrucciones para restablecer tu contraseña'];
        }
        
        // Generar token de reset
        $reset_token = generateSecureToken();
        $expires_at = date('Y-m-d H:i:s', time() + (60 * 60)); // 1 hora
        
        $stmt = $conn->prepare("
            INSERT INTO password_resets (user_id, token, expires_at) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE token = VALUES(token), expires_at = VALUES(expires_at)
        ");
        $stmt->bind_param("iss", $user['id'], $reset_token, $expires_at);
        $stmt->execute();
        
        // Enviar email
        $email_sent = sendPasswordResetEmail($email, $user['full_name'], $reset_token);
        
        // Registrar actividad
        logUserActivity($conn, $user['id'], 'password_reset_request', 'Solicitud de restablecimiento de contraseña');
        
        return [
            'success' => true, 
            'message' => 'Si el email existe, recibirás instrucciones para restablecer tu contraseña',
            'email_sent' => $email_sent
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error del servidor: ' . $e->getMessage()];
    }
}

function resetPassword($conn, $token, $password, $confirm_password) {
    try {
        if (empty($token) || empty($password) || empty($confirm_password)) {
            return ['success' => false, 'error' => 'Todos los campos son requeridos'];
        }
        
        if ($password !== $confirm_password) {
            return ['success' => false, 'error' => 'Las contraseñas no coinciden'];
        }
        
        if (strlen($password) < 8) {
            return ['success' => false, 'error' => 'La contraseña debe tener al menos 8 caracteres'];
        }
        
        // Verificar token
        $stmt = $conn->prepare("
            SELECT pr.user_id, u.email 
            FROM password_resets pr 
            JOIN users u ON pr.user_id = u.id 
            WHERE pr.token = ? AND pr.expires_at > NOW()
        ");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        $reset = $result->fetch_assoc();
        
        if (!$reset) {
            return ['success' => false, 'error' => 'Token inválido o expirado'];
        }
        
        // Actualizar contraseña
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $reset['user_id']);
        $stmt->execute();
        
        // Eliminar token usado
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE user_id = ?");
        $stmt->bind_param("i", $reset['user_id']);
        $stmt->execute();
        
        // Eliminar todos los tokens de recordar
        $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE user_id = ?");
        $stmt->bind_param("i", $reset['user_id']);
        $stmt->execute();
        
        // Registrar actividad
        logUserActivity($conn, $reset['user_id'], 'password_reset', 'Contraseña restablecida');
        
        return ['success' => true, 'message' => 'Contraseña restablecida correctamente'];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error del servidor: ' . $e->getMessage()];
    }
}

function verifyEmail($conn, $token) {
    try {
        if (empty($token)) {
            return ['success' => false, 'error' => 'Token requerido'];
        }
        
        // Verificar token
        $stmt = $conn->prepare("SELECT id, email FROM users WHERE email_verification_token = ? AND email_verified = 0");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (!$user) {
            return ['success' => false, 'error' => 'Token inválido o email ya verificado'];
        }
        
        // Marcar email como verificado
        $stmt = $conn->prepare("UPDATE users SET email_verified = 1, email_verification_token = NULL, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        
        // Registrar actividad
        logUserActivity($conn, $user['id'], 'email_verified', 'Email verificado');
        
        return ['success' => true, 'message' => 'Email verificado correctamente'];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error del servidor: ' . $e->getMessage()];
    }
}

function resendVerification($conn, $email) {
    try {
        if (empty($email)) {
            return ['success' => false, 'error' => 'Email requerido'];
        }
        
        // Buscar usuario no verificado
        $stmt = $conn->prepare("SELECT id, full_name FROM users WHERE email = ? AND email_verified = 0");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (!$user) {
            return ['success' => false, 'error' => 'Email no encontrado o ya verificado'];
        }
        
        // Generar nuevo token
        $verification_token = generateSecureToken();
        $stmt = $conn->prepare("UPDATE users SET email_verification_token = ? WHERE id = ?");
        $stmt->bind_param("si", $verification_token, $user['id']);
        $stmt->execute();
        
        // Enviar email
        $email_sent = sendVerificationEmail($email, $user['full_name'], $verification_token);
        
        return [
            'success' => true, 
            'message' => 'Email de verificación reenviado',
            'email_sent' => $email_sent
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error del servidor: ' . $e->getMessage()];
    }
}

// Funciones auxiliares
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length));
}

function sendVerificationEmail($email, $name, $token) {
    // En un entorno real, aquí se enviaría el email
    // Por ahora, solo simulamos el envío
    $verification_url = "http://localhost/GuardianIA_PHP/verify.php?token=" . $token;
    
    // Simular envío de email
    error_log("Email de verificación enviado a: $email");
    error_log("URL de verificación: $verification_url");
    
    return true;
}

function sendPasswordResetEmail($email, $name, $token) {
    // En un entorno real, aquí se enviaría el email
    // Por ahora, solo simulamos el envío
    $reset_url = "http://localhost/GuardianIA_PHP/reset_password.php?token=" . $token;
    
    // Simular envío de email
    error_log("Email de restablecimiento enviado a: $email");
    error_log("URL de restablecimiento: $reset_url");
    
    return true;
}

function logUserActivity($conn, $user_id, $action, $description) {
    try {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        
        $stmt = $conn->prepare("
            INSERT INTO user_activity_logs (user_id, action, description, ip_address, user_agent, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("issss", $user_id, $action, $description, $ip_address, $user_agent);
        $stmt->execute();
    } catch (Exception $e) {
        error_log("Error logging user activity: " . $e->getMessage());
    }
}

function checkRememberToken($conn) {
    if (isset($_COOKIE['remember_token']) && !isset($_SESSION['user_id'])) {
        $token = $_COOKIE['remember_token'];
        
        $stmt = $conn->prepare("
            SELECT rt.user_id, u.full_name, u.email 
            FROM remember_tokens rt 
            JOIN users u ON rt.user_id = u.id 
            WHERE rt.token = ? AND rt.expires_at > NOW() AND u.is_active = 1
        ");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if ($user) {
            // Restaurar sesión
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['login_time'] = time();
            
            // Actualizar último login
            $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $stmt->bind_param("i", $user['user_id']);
            $stmt->execute();
            
            return true;
        } else {
            // Token inválido, eliminar cookie
            setcookie('remember_token', '', time() - 3600, '/', '', true, true);
        }
    }
    
    return false;
}

function requireAuth() {
    global $conn;
    
    // Verificar token de recordar
    checkRememberToken($conn);
    
    if (!isset($_SESSION['user_id'])) {
        if (isAjaxRequest()) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'No autenticado', 'redirect' => 'login.php']);
            exit;
        } else {
            header('Location: login.php');
            exit;
        }
    }
    
    return $_SESSION['user_id'];
}

function isAjaxRequest() {
    return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

function getUserInfo($conn, $user_id) {
    $stmt = $conn->prepare("SELECT id, full_name, email, phone, language, timezone, theme, created_at, last_login FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Limpiar tokens expirados (ejecutar periódicamente)
function cleanupExpiredTokens($conn) {
    try {
        // Limpiar tokens de recordar expirados
        $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE expires_at < NOW()");
        $stmt->execute();
        
        // Limpiar tokens de reset de contraseña expirados
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE expires_at < NOW()");
        $stmt->execute();
        
        // Limpiar logs de actividad antiguos (más de 90 días)
        $stmt = $conn->prepare("DELETE FROM user_activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)");
        $stmt->execute();
        
    } catch (Exception $e) {
        error_log("Error cleaning up expired tokens: " . $e->getMessage());
    }
}

// Ejecutar limpieza si es necesario
if (rand(1, 100) <= 5) { // 5% de probabilidad
    cleanupExpiredTokens($conn);
}
?>

