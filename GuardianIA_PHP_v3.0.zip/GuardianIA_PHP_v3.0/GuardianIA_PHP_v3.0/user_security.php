<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Protección - GuardianIA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --warning-gradient: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(102, 126, 234, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(118, 75, 162, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(67, 233, 123, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        /* Navigation */
        .navbar {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .nav-link:hover {
            color: var(--text-primary);
            background: rgba(255, 255, 255, 0.1);
        }

        .nav-link.active {
            background: var(--success-gradient);
            color: white;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        /* Main Container */
        .main-container {
            margin-top: 80px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Security Header */
        .security-header {
            background: var(--success-gradient);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .security-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            animation: securityShine 4s infinite;
        }

        @keyframes securityShine {
            0% { left: -100%; }
            100% { left: 100%; }
        }

        .security-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .security-subtitle {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 1.5rem;
        }

        .shield-status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            font-weight: 600;
            color: white;
        }

        .shield-icon {
            font-size: 1.5rem;
            animation: shieldPulse 2s infinite;
        }

        @keyframes shieldPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        /* Protection Status Cards */
        .protection-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .protection-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            position: relative;
            overflow: hidden;
            transition: all var(--animation-speed) ease;
        }

        .protection-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px var(--shadow-color);
        }

        .protection-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
        }

        .protection-card.realtime::before {
            background: var(--success-gradient);
        }

        .protection-card.firewall::before {
            background: var(--info-gradient);
        }

        .protection-card.antivirus::before {
            background: var(--warning-gradient);
        }

        .protection-card.updates::before {
            background: var(--primary-gradient);
        }

        .protection-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .protection-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }

        .protection-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 600;
        }

        .status-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            animation: statusBlink 2s infinite;
        }

        .status-dot.active {
            background: #2ed573;
        }

        .status-dot.warning {
            background: #ffa502;
        }

        .status-dot.inactive {
            background: #ff4757;
        }

        @keyframes statusBlink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .protection-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .protection-description {
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }

        .protection-metrics {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .metric {
            text-align: center;
        }

        .metric-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .metric-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .protection-button {
            width: 100%;
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .protection-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .protection-button.active {
            background: var(--success-gradient);
        }

        .protection-button.warning {
            background: var(--warning-gradient);
        }

        /* Scan Section */
        .scan-section {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            margin-bottom: 2rem;
        }

        .scan-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .scan-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .last-scan {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .scan-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .scan-option {
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid transparent;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            text-align: center;
        }

        .scan-option:hover {
            border-color: var(--primary-gradient);
            background: rgba(255, 255, 255, 0.1);
        }

        .scan-option.selected {
            border-color: var(--success-gradient);
            background: rgba(67, 233, 123, 0.1);
        }

        .scan-option-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--text-primary);
        }

        .scan-option-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .scan-option-description {
            color: var(--text-secondary);
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .scan-option-time {
            font-size: 0.8rem;
            color: var(--text-secondary);
            font-style: italic;
        }

        .scan-controls {
            display: flex;
            gap: 1rem;
            justify-content: center;
        }

        .scan-button {
            background: var(--success-gradient);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .scan-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(67, 233, 123, 0.4);
        }

        .scan-button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .schedule-button {
            background: var(--info-gradient);
        }

        .schedule-button:hover {
            box-shadow: 0 8px 25px rgba(79, 172, 254, 0.4);
        }

        /* Threat History */
        .threat-history {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            margin-bottom: 2rem;
        }

        .history-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .history-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .history-filter {
            display: flex;
            gap: 0.5rem;
        }

        .filter-button {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
        }

        .filter-button.active {
            background: var(--primary-gradient);
            color: white;
        }

        .threat-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            margin-bottom: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            border-left: 4px solid transparent;
            transition: all var(--animation-speed) ease;
        }

        .threat-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .threat-item.resolved {
            border-left-color: #2ed573;
        }

        .threat-item.quarantined {
            border-left-color: #ffa502;
        }

        .threat-item.blocked {
            border-left-color: #ff4757;
        }

        .threat-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            color: white;
        }

        .threat-content {
            flex: 1;
        }

        .threat-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .threat-details {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .threat-time {
            color: var(--text-secondary);
            font-size: 0.8rem;
            text-align: right;
        }

        .threat-status {
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .threat-status.resolved {
            background: rgba(46, 213, 115, 0.2);
            color: #2ed573;
        }

        .threat-status.quarantined {
            background: rgba(255, 165, 2, 0.2);
            color: #ffa502;
        }

        .threat-status.blocked {
            background: rgba(255, 71, 87, 0.2);
            color: #ff4757;
        }

        /* Progress Bar */
        .scan-progress {
            margin: 2rem 0;
            display: none;
        }

        .scan-progress.active {
            display: block;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 1rem;
        }

        .progress-fill {
            height: 100%;
            background: var(--success-gradient);
            border-radius: 4px;
            transition: width 0.3s ease;
            width: 0%;
        }

        .progress-text {
            text-align: center;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Real-time Protection Toggle */
        .protection-toggle {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-top: 1rem;
        }

        .toggle-switch {
            position: relative;
            width: 60px;
            height: 30px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
        }

        .toggle-switch.active {
            background: var(--success-gradient);
        }

        .toggle-slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 24px;
            height: 24px;
            background: white;
            border-radius: 50%;
            transition: all var(--animation-speed) ease;
        }

        .toggle-switch.active .toggle-slider {
            transform: translateX(30px);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .protection-grid {
                grid-template-columns: 1fr;
            }

            .scan-options {
                grid-template-columns: 1fr;
            }

            .scan-controls {
                flex-direction: column;
            }

            .security-title {
                font-size: 2rem;
            }

            .main-container {
                padding: 1rem;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            top: 100px;
            right: 2rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem 1.5rem;
            color: var(--text-primary);
            box-shadow: 0 8px 25px var(--shadow-color);
            transform: translateX(400px);
            transition: transform var(--animation-speed) ease;
            z-index: 1001;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #2ed573;
        }

        .toast.error {
            border-left: 4px solid #ff4757;
        }

        .toast.warning {
            border-left: 4px solid #ffa502;
        }

        .toast.info {
            border-left: 4px solid #4facfe;
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <span>GuardianIA</span>
            </div>
            <ul class="nav-menu">
                <li><a href="user_dashboard.php" class="nav-link">Mi Seguridad</a></li>
                <li><a href="#" class="nav-link active">Protección</a></li>
                <li><a href="user_performance.php" class="nav-link">Optimización</a></li>
                <li><a href="user_assistant.php" class="nav-link">Asistente IA</a></li>
                <li><a href="user_settings.php" class="nav-link">Configuración</a></li>
            </ul>
            <div class="user-profile">
                <div class="user-avatar">JD</div>
                <span>Juan Pérez</span>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Security Header -->
        <div class="security-header">
            <h1 class="security-title">🛡️ Centro de Protección</h1>
            <p class="security-subtitle">
                Tu escudo digital inteligente está activo las 24 horas
            </p>
            <div class="shield-status">
                <i class="fas fa-shield-check shield-icon"></i>
                <span>Protección Máxima Activada</span>
            </div>
        </div>

        <!-- Protection Status Cards -->
        <div class="protection-grid">
            <div class="protection-card realtime">
                <div class="protection-header">
                    <div class="protection-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-eye"></i>
                    </div>
                    <div class="protection-status">
                        <div class="status-dot active"></div>
                        <span style="color: #2ed573;">ACTIVO</span>
                    </div>
                </div>
                <h3 class="protection-title">Protección en Tiempo Real</h3>
                <p class="protection-description">
                    Monitoreo continuo de amenazas con IA avanzada
                </p>
                <div class="protection-metrics">
                    <div class="metric">
                        <div class="metric-value" style="color: #2ed573;">24/7</div>
                        <div class="metric-label">Monitoreo</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #2ed573;">94.2%</div>
                        <div class="metric-label">Precisión</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #2ed573;">0</div>
                        <div class="metric-label">Amenazas</div>
                    </div>
                </div>
                <div class="protection-toggle">
                    <div class="toggle-switch active" onclick="toggleRealTimeProtection()">
                        <div class="toggle-slider"></div>
                    </div>
                    <span>Protección activada</span>
                </div>
            </div>

            <div class="protection-card firewall">
                <div class="protection-header">
                    <div class="protection-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-fire"></i>
                    </div>
                    <div class="protection-status">
                        <div class="status-dot active"></div>
                        <span style="color: #2ed573;">ACTIVO</span>
                    </div>
                </div>
                <h3 class="protection-title">Firewall Inteligente</h3>
                <p class="protection-description">
                    Bloqueo automático de conexiones sospechosas
                </p>
                <div class="protection-metrics">
                    <div class="metric">
                        <div class="metric-value" style="color: #4facfe;">127</div>
                        <div class="metric-label">Bloqueados</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #4facfe;">99.8%</div>
                        <div class="metric-label">Efectividad</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #4facfe;">5</div>
                        <div class="metric-label">Reglas IA</div>
                    </div>
                </div>
                <button class="protection-button active" onclick="configureFirewall()">
                    <i class="fas fa-cog"></i>
                    Configurar Firewall
                </button>
            </div>

            <div class="protection-card antivirus">
                <div class="protection-header">
                    <div class="protection-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-virus-slash"></i>
                    </div>
                    <div class="protection-status">
                        <div class="status-dot active"></div>
                        <span style="color: #2ed573;">ACTUALIZADO</span>
                    </div>
                </div>
                <h3 class="protection-title">Antivirus IA</h3>
                <p class="protection-description">
                    Detección avanzada con machine learning
                </p>
                <div class="protection-metrics">
                    <div class="metric">
                        <div class="metric-value" style="color: #ffa726;">1,247</div>
                        <div class="metric-label">Firmas</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #ffa726;">98.7%</div>
                        <div class="metric-label">Detección</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #ffa726;">0</div>
                        <div class="metric-label">Infectados</div>
                    </div>
                </div>
                <button class="protection-button warning" onclick="updateDefinitions()">
                    <i class="fas fa-download"></i>
                    Actualizar Definiciones
                </button>
            </div>

            <div class="protection-card updates">
                <div class="protection-header">
                    <div class="protection-icon" style="background: var(--primary-gradient);">
                        <i class="fas fa-sync-alt"></i>
                    </div>
                    <div class="protection-status">
                        <div class="status-dot active"></div>
                        <span style="color: #2ed573;">AL DÍA</span>
                    </div>
                </div>
                <h3 class="protection-title">Actualizaciones Automáticas</h3>
                <p class="protection-description">
                    Sistema siempre actualizado con las últimas defensas
                </p>
                <div class="protection-metrics">
                    <div class="metric">
                        <div class="metric-value" style="color: #667eea;">Auto</div>
                        <div class="metric-label">Modo</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #667eea;">Hoy</div>
                        <div class="metric-label">Última</div>
                    </div>
                    <div class="metric">
                        <div class="metric-value" style="color: #667eea;">3</div>
                        <div class="metric-label">Pendientes</div>
                    </div>
                </div>
                <button class="protection-button" onclick="checkUpdates()">
                    <i class="fas fa-search"></i>
                    Buscar Actualizaciones
                </button>
            </div>
        </div>

        <!-- Scan Section -->
        <div class="scan-section">
            <div class="scan-header">
                <h2 class="scan-title">🔍 Análisis de Seguridad</h2>
                <div class="last-scan">
                    Último escaneo: Hoy a las 14:30 - Sin amenazas detectadas
                </div>
            </div>

            <div class="scan-options">
                <div class="scan-option selected" onclick="selectScanType('quick')">
                    <div class="scan-option-icon">⚡</div>
                    <h3 class="scan-option-title">Escaneo Rápido</h3>
                    <p class="scan-option-description">
                        Análisis básico de archivos críticos y memoria
                    </p>
                    <div class="scan-option-time">Duración: 2-5 minutos</div>
                </div>

                <div class="scan-option" onclick="selectScanType('full')">
                    <div class="scan-option-icon">🔍</div>
                    <h3 class="scan-option-title">Escaneo Completo</h3>
                    <p class="scan-option-description">
                        Análisis profundo de todo el sistema
                    </p>
                    <div class="scan-option-time">Duración: 30-60 minutos</div>
                </div>

                <div class="scan-option" onclick="selectScanType('custom')">
                    <div class="scan-option-icon">⚙️</div>
                    <h3 class="scan-option-title">Escaneo Personalizado</h3>
                    <p class="scan-option-description">
                        Selecciona carpetas y opciones específicas
                    </p>
                    <div class="scan-option-time">Duración: Variable</div>
                </div>

                <div class="scan-option" onclick="selectScanType('ai')">
                    <div class="scan-option-icon">🤖</div>
                    <h3 class="scan-option-title">Análisis IA Avanzado</h3>
                    <p class="scan-option-description">
                        Detección de amenazas con inteligencia artificial
                    </p>
                    <div class="scan-option-time">Duración: 10-20 minutos</div>
                </div>
            </div>

            <div class="scan-progress" id="scanProgress">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
                <div class="progress-text" id="progressText">Preparando escaneo...</div>
            </div>

            <div class="scan-controls">
                <button class="scan-button" onclick="startScan()" id="scanButton">
                    <i class="fas fa-play"></i>
                    Iniciar Escaneo Rápido
                </button>
                <button class="scan-button schedule-button" onclick="scheduleScan()">
                    <i class="fas fa-calendar-alt"></i>
                    Programar Escaneo
                </button>
            </div>
        </div>

        <!-- Threat History -->
        <div class="threat-history">
            <div class="history-header">
                <h2 class="history-title">📊 Historial de Amenazas</h2>
                <div class="history-filter">
                    <button class="filter-button active" onclick="filterThreats('all')">Todas</button>
                    <button class="filter-button" onclick="filterThreats('resolved')">Resueltas</button>
                    <button class="filter-button" onclick="filterThreats('quarantined')">Cuarentena</button>
                    <button class="filter-button" onclick="filterThreats('blocked')">Bloqueadas</button>
                </div>
            </div>

            <div id="threatList">
                <div class="threat-item resolved">
                    <div class="threat-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-virus-slash"></i>
                    </div>
                    <div class="threat-content">
                        <div class="threat-name">Malware.Generic.KX47</div>
                        <div class="threat-details">Archivo: temp_installer.exe - Eliminado automáticamente</div>
                    </div>
                    <div class="threat-time">
                        <div class="threat-status resolved">Resuelto</div>
                        <div>Hace 2 días</div>
                    </div>
                </div>

                <div class="threat-item quarantined">
                    <div class="threat-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="threat-content">
                        <div class="threat-name">Adware.Suspicious.Browser</div>
                        <div class="threat-details">Extensión de navegador sospechosa - En cuarentena</div>
                    </div>
                    <div class="threat-time">
                        <div class="threat-status quarantined">Cuarentena</div>
                        <div>Hace 1 semana</div>
                    </div>
                </div>

                <div class="threat-item blocked">
                    <div class="threat-icon" style="background: var(--danger-gradient);">
                        <i class="fas fa-ban"></i>
                    </div>
                    <div class="threat-content">
                        <div class="threat-name">Phishing.Email.Fake</div>
                        <div class="threat-details">Intento de phishing por email - Bloqueado por IA</div>
                    </div>
                    <div class="threat-time">
                        <div class="threat-status blocked">Bloqueado</div>
                        <div>Hace 2 semanas</div>
                    </div>
                </div>

                <div class="threat-item resolved">
                    <div class="threat-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-shield-check"></i>
                    </div>
                    <div class="threat-content">
                        <div class="threat-name">Trojan.Win32.Suspicious</div>
                        <div class="threat-details">Comportamiento sospechoso detectado - Neutralizado</div>
                    </div>
                    <div class="threat-time">
                        <div class="threat-status resolved">Resuelto</div>
                        <div>Hace 3 semanas</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <span id="toast-message"></span>
    </div>

    <script>
        // Variables globales
        let selectedScanType = 'quick';
        let isScanning = false;
        let scanProgress = 0;
        let scanInterval;

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            initializeSecurity();
            updateProtectionStatus();
            loadThreatHistory();
        });

        // Inicializar módulo de seguridad
        function initializeSecurity() {
            console.log('Inicializando módulo de seguridad...');
            checkRealTimeProtection();
            updateSecurityMetrics();
        }

        // Seleccionar tipo de escaneo
        function selectScanType(type) {
            selectedScanType = type;
            
            // Actualizar UI
            document.querySelectorAll('.scan-option').forEach(option => {
                option.classList.remove('selected');
            });
            
            event.target.closest('.scan-option').classList.add('selected');
            
            // Actualizar botón
            const scanButton = document.getElementById('scanButton');
            const scanTypes = {
                'quick': 'Iniciar Escaneo Rápido',
                'full': 'Iniciar Escaneo Completo',
                'custom': 'Configurar Escaneo',
                'ai': 'Iniciar Análisis IA'
            };
            
            scanButton.innerHTML = `<i class="fas fa-play"></i> ${scanTypes[type]}`;
        }

        // Iniciar escaneo
        function startScan() {
            if (isScanning) {
                showToast('Ya hay un escaneo en progreso...', 'warning');
                return;
            }

            isScanning = true;
            scanProgress = 0;
            
            const scanButton = document.getElementById('scanButton');
            const progressSection = document.getElementById('scanProgress');
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');
            
            // Mostrar barra de progreso
            progressSection.classList.add('active');
            scanButton.innerHTML = '<div class="loading"></div> Escaneando...';
            scanButton.disabled = true;
            
            showToast(`Iniciando ${getScanTypeName(selectedScanType)}...`, 'info');
            
            // Simular proceso de escaneo
            const scanSteps = getScanSteps(selectedScanType);
            let currentStep = 0;
            
            scanInterval = setInterval(() => {
                if (currentStep < scanSteps.length) {
                    progressText.textContent = scanSteps[currentStep];
                    scanProgress = ((currentStep + 1) / scanSteps.length) * 100;
                    progressFill.style.width = scanProgress + '%';
                    currentStep++;
                } else {
                    completeScan();
                }
            }, getScanStepDuration(selectedScanType));
        }

        // Completar escaneo
        function completeScan() {
            clearInterval(scanInterval);
            
            const scanButton = document.getElementById('scanButton');
            const progressSection = document.getElementById('scanProgress');
            const progressText = document.getElementById('progressText');
            
            progressText.textContent = 'Escaneo completado - Sistema limpio';
            
            setTimeout(() => {
                progressSection.classList.remove('active');
                scanButton.innerHTML = `<i class="fas fa-play"></i> Iniciar ${getScanTypeName(selectedScanType)}`;
                scanButton.disabled = false;
                isScanning = false;
                
                showToast('Escaneo completado exitosamente. No se encontraron amenazas.', 'success');
                updateLastScanTime();
                updateSecurityMetrics();
            }, 2000);
        }

        // Obtener nombre del tipo de escaneo
        function getScanTypeName(type) {
            const names = {
                'quick': 'Escaneo Rápido',
                'full': 'Escaneo Completo',
                'custom': 'Escaneo Personalizado',
                'ai': 'Análisis IA Avanzado'
            };
            return names[type] || 'Escaneo';
        }

        // Obtener pasos del escaneo
        function getScanSteps(type) {
            const steps = {
                'quick': [
                    'Preparando escaneo...',
                    'Analizando memoria RAM...',
                    'Verificando archivos críticos...',
                    'Escaneando procesos activos...',
                    'Finalizando análisis...'
                ],
                'full': [
                    'Preparando escaneo completo...',
                    'Analizando memoria y procesos...',
                    'Escaneando archivos del sistema...',
                    'Verificando registro de Windows...',
                    'Analizando archivos de usuario...',
                    'Escaneando archivos temporales...',
                    'Verificando conexiones de red...',
                    'Análisis heurístico avanzado...',
                    'Finalizando escaneo completo...'
                ],
                'custom': [
                    'Configurando parámetros...',
                    'Analizando carpetas seleccionadas...',
                    'Aplicando filtros personalizados...',
                    'Ejecutando análisis específico...',
                    'Generando reporte personalizado...'
                ],
                'ai': [
                    'Inicializando IA de seguridad...',
                    'Cargando modelos de machine learning...',
                    'Analizando patrones de comportamiento...',
                    'Detectando anomalías con IA...',
                    'Clasificando amenazas potenciales...',
                    'Aplicando algoritmos heurísticos...',
                    'Generando reporte inteligente...'
                ]
            };
            return steps[type] || steps['quick'];
        }

        // Obtener duración de paso
        function getScanStepDuration(type) {
            const durations = {
                'quick': 1000,    // 1 segundo por paso
                'full': 2000,     // 2 segundos por paso
                'custom': 1500,   // 1.5 segundos por paso
                'ai': 1800        // 1.8 segundos por paso
            };
            return durations[type] || 1000;
        }

        // Programar escaneo
        function scheduleScan() {
            showToast('Abriendo programador de escaneos...', 'info');
            // Aquí se abriría un modal para programar escaneos
        }

        // Toggle protección en tiempo real
        function toggleRealTimeProtection() {
            const toggle = event.target.closest('.toggle-switch');
            const isActive = toggle.classList.contains('active');
            
            if (isActive) {
                toggle.classList.remove('active');
                showToast('Protección en tiempo real desactivada', 'warning');
                updateProtectionStatus('realtime', false);
            } else {
                toggle.classList.add('active');
                showToast('Protección en tiempo real activada', 'success');
                updateProtectionStatus('realtime', true);
            }
        }

        // Configurar firewall
        function configureFirewall() {
            showToast('Abriendo configuración del firewall...', 'info');
            // Aquí se abriría la configuración del firewall
        }

        // Actualizar definiciones
        function updateDefinitions() {
            const button = event.target;
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Actualizando...';
            button.disabled = true;
            
            showToast('Descargando nuevas definiciones de virus...', 'info');
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.disabled = false;
                showToast('Definiciones actualizadas exitosamente. 1,247 nuevas firmas agregadas.', 'success');
                updateSecurityMetrics();
            }, 3000);
        }

        // Buscar actualizaciones
        function checkUpdates() {
            const button = event.target;
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Buscando...';
            button.disabled = true;
            
            showToast('Verificando actualizaciones disponibles...', 'info');
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.disabled = false;
                showToast('Sistema actualizado. No hay actualizaciones pendientes.', 'success');
            }, 2000);
        }

        // Filtrar amenazas
        function filterThreats(filter) {
            // Actualizar botones de filtro
            document.querySelectorAll('.filter-button').forEach(btn => {
                btn.classList.remove('active');
            });
            event.target.classList.add('active');
            
            // Filtrar elementos
            const threatItems = document.querySelectorAll('.threat-item');
            threatItems.forEach(item => {
                if (filter === 'all') {
                    item.style.display = 'flex';
                } else {
                    if (item.classList.contains(filter)) {
                        item.style.display = 'flex';
                    } else {
                        item.style.display = 'none';
                    }
                }
            });
            
            showToast(`Mostrando amenazas: ${getFilterName(filter)}`, 'info');
        }

        // Obtener nombre del filtro
        function getFilterName(filter) {
            const names = {
                'all': 'Todas',
                'resolved': 'Resueltas',
                'quarantined': 'En cuarentena',
                'blocked': 'Bloqueadas'
            };
            return names[filter] || 'Todas';
        }

        // Actualizar estado de protección
        function updateProtectionStatus(module, status) {
            console.log(`Actualizando ${module}: ${status ? 'Activo' : 'Inactivo'}`);
        }

        // Verificar protección en tiempo real
        function checkRealTimeProtection() {
            console.log('Verificando protección en tiempo real...');
        }

        // Actualizar métricas de seguridad
        function updateSecurityMetrics() {
            // Simular actualización de métricas
            const metrics = {
                threatsBlocked: Math.floor(Math.random() * 10) + 120,
                firewallEffectiveness: (Math.random() * 2 + 98).toFixed(1),
                virusDefinitions: Math.floor(Math.random() * 100) + 1200,
                detectionRate: (Math.random() * 2 + 97).toFixed(1)
            };
            
            console.log('Métricas actualizadas:', metrics);
        }

        // Actualizar hora del último escaneo
        function updateLastScanTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('es-ES', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            const lastScanElement = document.querySelector('.last-scan');
            lastScanElement.textContent = `Último escaneo: Hoy a las ${timeString} - Sin amenazas detectadas`;
        }

        // Cargar historial de amenazas
        function loadThreatHistory() {
            console.log('Cargando historial de amenazas...');
        }

        // Mostrar notificación toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type}`;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 4000);
        }

        // Actualizar estado de protección periódicamente
        setInterval(() => {
            updateSecurityMetrics();
        }, 30000); // Cada 30 segundos

        // Simular detección de amenazas ocasional
        setInterval(() => {
            if (Math.random() < 0.05) { // 5% de probabilidad
                const threats = [
                    'Intento de conexión sospechosa bloqueado',
                    'Archivo potencialmente peligroso detectado',
                    'Actividad de red anómala identificada',
                    'Proceso sospechoso neutralizado'
                ];
                
                const randomThreat = threats[Math.floor(Math.random() * threats.length)];
                showToast(randomThreat, 'warning');
            }
        }, 60000); // Cada minuto

        // Manejo de errores
        window.addEventListener('error', function(e) {
            console.log('Error capturado:', e.message);
            showToast('Se produjo un error en el sistema de seguridad. Reintentando...', 'error');
        });

        // Cleanup al salir
        window.addEventListener('beforeunload', function() {
            if (scanInterval) {
                clearInterval(scanInterval);
            }
        });
    </script>
</body>
</html>

