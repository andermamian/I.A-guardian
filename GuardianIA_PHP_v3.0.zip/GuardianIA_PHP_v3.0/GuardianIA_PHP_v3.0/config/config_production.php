<?php
/**
 * GuardianIA v3.0 FINAL - Configuración de Producción
 * Anderson Mamian Chicangana - Membresía Premium
 * Configuración segura para entorno de producción
 */

// Configuración de seguridad
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/errors.log');

// Configuración de sesión segura
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

// Headers de seguridad
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Configuración de base de datos (CAMBIAR EN PRODUCCIÓN)
define('DB_HOST', 'localhost');
define('DB_USER', 'anderson');
define('DB_PASS', 'Ander12345@');
define('DB_NAME', 'guardianai_db');
define('DB_CHARSET', 'utf8mb4');

// Configuración de aplicación
define('APP_NAME', 'GuardianIA v3.0');
define('APP_VERSION', '3.0.0');
define('APP_ENV', 'production');
define('APP_DEBUG', false);
define('APP_URL', 'https://tu-dominio.com');

// Configuración de seguridad
define('SECURITY_LEVEL', 'MAXIMUM');
define('ENCRYPTION_METHOD', 'AES-256-CBC');
define('HASH_ALGORITHM', 'sha256');
define('JWT_SECRET', 'tu_jwt_secret_super_seguro_aqui');
define('CSRF_TOKEN_LIFETIME', 3600);

// Configuración de IA
define('AI_CONSCIOUSNESS_LEVEL', 98.7);
define('AI_MAX_TOKENS', 4096);
define('AI_TEMPERATURE', 0.7);
define('AI_TOP_P', 0.9);
define('AI_PRESENCE_PENALTY', 0.1);
define('AI_FREQUENCY_PENALTY', 0.1);

// Configuración de funcionalidades
define('QUANTUM_ENCRYPTION_ENABLED', true);
define('AI_ANTIVIRUS_ENABLED', true);
define('VPN_AI_ENABLED', true);
define('PREDICTIVE_ANALYSIS_ENABLED', true);

// Configuración de límites
define('MAX_DAILY_MESSAGES_FREE', 50);
define('MAX_DAILY_MESSAGES_PREMIUM', 10000);
define('RATE_LIMIT_REQUESTS', 100);
define('RATE_LIMIT_WINDOW', 3600);

// Configuración de membresías
define('MONTHLY_PRICE', 60000);
define('YEARLY_DISCOUNT', 15);
define('CURRENCY', 'COP');

// Configuración de logs
define('LOG_LEVEL', 'INFO');
define('LOG_MAX_SIZE', 10485760); // 10MB
define('LOG_RETENTION_DAYS', 90);

// Configuración de archivos
define('UPLOAD_MAX_SIZE', 10485760); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']);

// Configuración de email (configurar en producción)
define('SMTP_HOST', 'smtp.tu-proveedor.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'tu-email@dominio.com');
define('SMTP_PASSWORD', 'tu-password-smtp');
define('SMTP_ENCRYPTION', 'tls');

// Configuración de cache
define('CACHE_ENABLED', true);
define('CACHE_LIFETIME', 3600);
define('CACHE_PREFIX', 'guardianai_');

// Configuración de backup
define('BACKUP_ENABLED', true);
define('BACKUP_FREQUENCY', 'daily');
define('BACKUP_RETENTION', 30);

// Configuración de monitoreo
define('MONITORING_ENABLED', true);
define('METRICS_COLLECTION', true);
define('PERFORMANCE_TRACKING', true);

// Timezone
date_default_timezone_set('America/Bogota');

// Clase de configuración de base de datos
class DatabaseConfig {
    private static $instance = null;
    private $connection = null;
    
    private function __construct() {
        try {
            $this->connection = new mysqli(
                DB_HOST, 
                DB_USER, 
                DB_PASS, 
                DB_NAME
            );
            
            if ($this->connection->connect_error) {
                throw new Exception('Error de conexión: ' . $this->connection->connect_error);
            }
            
            $this->connection->set_charset(DB_CHARSET);
            
            // Configurar modo SQL estricto
            $this->connection->query("SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
            
        } catch (Exception $e) {
            logEvent('CRITICAL', 'Database connection failed: ' . $e->getMessage());
            throw $e;
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function executeQuery($query, $params = []) {
        try {
            if (empty($params)) {
                return $this->connection->query($query);
            }
            
            $stmt = $this->connection->prepare($query);
            if (!$stmt) {
                throw new Exception('Error preparando consulta: ' . $this->connection->error);
            }
            
            if (!empty($params)) {
                $types = str_repeat('s', count($params));
                $stmt->bind_param($types, ...$params);
            }
            
            $stmt->execute();
            return $stmt->get_result();
            
        } catch (Exception $e) {
            logEvent('ERROR', 'Database query failed: ' . $e->getMessage());
            throw $e;
        }
    }
    
    public function __destruct() {
        if ($this->connection) {
            $this->connection->close();
        }
    }
}

// Funciones de utilidad
function logEvent($level, $message, $context = []) {
    if (!in_array($level, ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'])) {
        $level = 'INFO';
    }
    
    $logFile = __DIR__ . '/../logs/' . strtolower($level) . '.log';
    $timestamp = date('Y-m-d H:i:s');
    $contextStr = !empty($context) ? ' | Context: ' . json_encode($context) : '';
    $logEntry = "[$timestamp] [$level] $message$contextStr" . PHP_EOL;
    
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token']) || 
        !isset($_SESSION['csrf_token_time']) || 
        (time() - $_SESSION['csrf_token_time']) > CSRF_TOKEN_LIFETIME) {
        
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && 
           hash_equals($_SESSION['csrf_token'], $token) &&
           isset($_SESSION['csrf_token_time']) &&
           (time() - $_SESSION['csrf_token_time']) <= CSRF_TOKEN_LIFETIME;
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    
    return $input;
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function generateSecurePassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    return substr(str_shuffle(str_repeat($chars, ceil($length / strlen($chars)))), 0, $length);
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_ARGON2ID, [
        'memory_cost' => 65536,
        'time_cost' => 4,
        'threads' => 3
    ]);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function encryptData($data, $key = null) {
    if ($key === null) {
        $key = JWT_SECRET;
    }
    
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, ENCRYPTION_METHOD, $key, 0, $iv);
    
    return base64_encode($iv . $encrypted);
}

function decryptData($encryptedData, $key = null) {
    if ($key === null) {
        $key = JWT_SECRET;
    }
    
    $data = base64_decode($encryptedData);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    
    return openssl_decrypt($encrypted, ENCRYPTION_METHOD, $key, 0, $iv);
}

function isRateLimited($identifier, $limit = null, $window = null) {
    if ($limit === null) $limit = RATE_LIMIT_REQUESTS;
    if ($window === null) $window = RATE_LIMIT_WINDOW;
    
    $db = DatabaseConfig::getInstance();
    
    try {
        // Limpiar registros antiguos
        $db->executeQuery(
            "DELETE FROM rate_limits WHERE window_start < ?",
            [date('Y-m-d H:i:s', time() - $window)]
        );
        
        // Verificar límite actual
        $result = $db->executeQuery(
            "SELECT requests_count FROM rate_limits WHERE ip_address = ? AND window_start > ?",
            [$identifier, date('Y-m-d H:i:s', time() - $window)]
        );
        
        $totalRequests = 0;
        while ($row = $result->fetch_assoc()) {
            $totalRequests += $row['requests_count'];
        }
        
        if ($totalRequests >= $limit) {
            return true;
        }
        
        // Registrar nueva solicitud
        $db->executeQuery(
            "INSERT INTO rate_limits (ip_address, endpoint, requests_count, window_start) VALUES (?, 'api', 1, NOW()) ON DUPLICATE KEY UPDATE requests_count = requests_count + 1",
            [$identifier]
        );
        
        return false;
        
    } catch (Exception $e) {
        logEvent('ERROR', 'Rate limiting error: ' . $e->getMessage());
        return false; // En caso de error, permitir la solicitud
    }
}

function getSystemStats() {
    $db = DatabaseConfig::getInstance();
    
    try {
        $stats = [];
        
        // Usuarios
        $result = $db->executeQuery("SELECT COUNT(*) as total FROM users WHERE status = 'active'");
        $stats['active_users'] = $result->fetch_assoc()['total'];
        
        $result = $db->executeQuery("SELECT COUNT(*) as total FROM users WHERE premium_status = 'premium'");
        $stats['premium_users'] = $result->fetch_assoc()['total'];
        
        // Conversaciones
        $result = $db->executeQuery("SELECT COUNT(*) as total FROM conversations WHERE DATE(created_at) = CURDATE()");
        $stats['conversations_today'] = $result->fetch_assoc()['total'];
        
        // Detecciones de IA
        $result = $db->executeQuery("SELECT COUNT(*) as total FROM ai_detections WHERE DATE(created_at) = CURDATE()");
        $stats['ai_detections_today'] = $result->fetch_assoc()['total'];
        
        // Amenazas
        $result = $db->executeQuery("SELECT COUNT(*) as total FROM security_events WHERE DATE(created_at) = CURDATE() AND severity IN ('high', 'critical')");
        $stats['threats_today'] = $result->fetch_assoc()['total'];
        
        // Consciencia promedio
        $result = $db->executeQuery("SELECT AVG(consciousness_level) as avg FROM conversation_logs WHERE consciousness_level IS NOT NULL AND DATE(timestamp) = CURDATE()");
        $row = $result->fetch_assoc();
        $stats['avg_consciousness'] = $row['avg'] ? round($row['avg'], 1) : AI_CONSCIOUSNESS_LEVEL;
        
        return $stats;
        
    } catch (Exception $e) {
        logEvent('ERROR', 'Error getting system stats: ' . $e->getMessage());
        return [
            'active_users' => 0,
            'premium_users' => 0,
            'conversations_today' => 0,
            'ai_detections_today' => 0,
            'threats_today' => 0,
            'avg_consciousness' => AI_CONSCIOUSNESS_LEVEL
        ];
    }
}

function cleanupOldData() {
    $db = DatabaseConfig::getInstance();
    
    try {
        // Limpiar sesiones expiradas
        $db->executeQuery("DELETE FROM user_sessions WHERE expires_at < NOW()");
        
        // Limpiar logs antiguos
        $db->executeQuery("DELETE FROM conversation_logs WHERE timestamp < DATE_SUB(NOW(), INTERVAL ? DAY)", [LOG_RETENTION_DAYS]);
        
        // Limpiar eventos de seguridad resueltos antiguos
        $db->executeQuery("DELETE FROM security_events WHERE created_at < DATE_SUB(NOW(), INTERVAL 180 DAY) AND resolved = TRUE");
        
        // Limpiar rate limits antiguos
        $db->executeQuery("DELETE FROM rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 DAY)");
        
        logEvent('INFO', 'Cleanup completed successfully');
        
    } catch (Exception $e) {
        logEvent('ERROR', 'Cleanup failed: ' . $e->getMessage());
    }
}

// Inicializar sesión segura
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Regenerar ID de sesión periódicamente
if (!isset($_SESSION['last_regeneration']) || (time() - $_SESSION['last_regeneration']) > 300) {
    session_regenerate_id(true);
    $_SESSION['last_regeneration'] = time();
}

// Cleanup automático (ejecutar ocasionalmente)
if (rand(1, 100) === 1) {
    cleanupOldData();
}

// Log de inicialización
logEvent('INFO', 'GuardianIA v3.0 initialized', [
    'version' => APP_VERSION,
    'environment' => APP_ENV,
    'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
]);
?>

