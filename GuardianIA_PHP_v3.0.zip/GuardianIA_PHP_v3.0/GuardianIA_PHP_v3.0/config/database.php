<?php
/**
 * GuardianIA v3.0 FINAL - Configuración de Base de Datos
 * Anderson Mamian Chicangana - Membresía Premium
 * Optimizado y sincronizado
 */

class DatabaseConfig {
    // Configuración de conexión
    private const DB_HOST = 'localhost';
    private const DB_USER = 'anderson';
    private const DB_PASS = 'Ander12345@';
    private const DB_NAME = 'guardianai_db';
    private const DB_PORT = 3306;
    private const DB_CHARSET = 'utf8mb4';
    
    // Pool de conexiones
    private static $connections = [];
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection($pool_id = 'default') {
        if (!isset(self::$connections[$pool_id])) {
            self::$connections[$pool_id] = $this->createConnection();
        }
        
        // Verificar si la conexión sigue activa
        if (!self::$connections[$pool_id]->ping()) {
            self::$connections[$pool_id] = $this->createConnection();
        }
        
        return self::$connections[$pool_id];
    }
    
    private function createConnection() {
        try {
            $conn = new mysqli(
                self::DB_HOST,
                self::DB_USER,
                self::DB_PASS,
                self::DB_NAME,
                self::DB_PORT
            );
            
            if ($conn->connect_error) {
                throw new Exception("Error de conexión: " . $conn->connect_error);
            }
            
            // Configurar conexión
            $conn->set_charset(self::DB_CHARSET);
            $conn->query("SET time_zone = '-05:00'");
            $conn->query("SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
            
            return $conn;
            
        } catch (Exception $e) {
            error_log("GuardianIA DB Error: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function executeQuery($sql, $params = [], $pool_id = 'default') {
        $conn = $this->getConnection($pool_id);
        
        if (empty($params)) {
            return $conn->query($sql);
        }
        
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparando consulta: " . $conn->error);
        }
        
        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        return $stmt->get_result();
    }
    
    public function getStats() {
        try {
            $conn = $this->getConnection();
            
            $stats = [
                'active_users' => 0,
                'threats_today' => 0,
                'ai_detections_today' => 0,
                'total_conversations' => 0,
                'premium_users' => 0
            ];
            
            // Usuarios activos
            $result = $conn->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'");
            if ($result) $stats['active_users'] = $result->fetch_assoc()['count'];
            
            // Amenazas detectadas hoy
            $result = $conn->query("SELECT COUNT(*) as count FROM security_events WHERE DATE(created_at) = CURDATE()");
            if ($result) $stats['threats_today'] = $result->fetch_assoc()['count'];
            
            // Detecciones de IA hoy
            $result = $conn->query("SELECT COUNT(*) as count FROM ai_detections WHERE DATE(timestamp) = CURDATE()");
            if ($result) $stats['ai_detections_today'] = $result->fetch_assoc()['count'];
            
            // Total conversaciones
            $result = $conn->query("SELECT COUNT(*) as count FROM conversations");
            if ($result) $stats['total_conversations'] = $result->fetch_assoc()['count'];
            
            // Usuarios premium
            $result = $conn->query("SELECT COUNT(*) as count FROM memberships WHERE status = 'active' AND plan_type = 'premium'");
            if ($result) $stats['premium_users'] = $result->fetch_assoc()['count'];
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("Error obteniendo estadísticas: " . $e->getMessage());
            return [
                'active_users' => 0,
                'threats_today' => 0,
                'ai_detections_today' => 0,
                'total_conversations' => 0,
                'premium_users' => 0
            ];
        }
    }
    
    public function __destruct() {
        foreach (self::$connections as $conn) {
            if ($conn) {
                $conn->close();
            }
        }
    }
}
?>

