/**
 * GuardianIA v3.0 FINAL - JavaScript Principal
 * Anderson Mamian Chicangana - Membresía Premium
 * Sistema Completamente Sincronizado
 */

class GuardianIA {
    constructor() {
        this.particleCount = 60;
        this.statsUpdateInterval = 5000;
        this.init();
    }
    
    init() {
        this.createQuantumParticles();
        this.setupEventListeners();
        this.startStatsUpdater();
        this.setupScrollEffects();
        this.setupFormValidation();
        this.setupSmoothScrolling();
        
        console.log('🛡️ GuardianIA v3.0 FINAL initialized');
        console.log('👤 Developer: Anderson Mamian Chicangana');
        console.log('💎 Premium features enabled');
    }
    
    // Crear partículas cuánticas
    createQuantumParticles() {
        const container = document.getElementById('particles');
        if (!container) return;
        
        // Limpiar partículas existentes
        container.innerHTML = '';
        
        for (let i = 0; i < this.particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            // Posición aleatoria
            particle.style.left = Math.random() * 100 + '%';
            
            // Delay aleatorio
            particle.style.animationDelay = Math.random() * 8 + 's';
            
            // Duración aleatoria
            particle.style.animationDuration = (Math.random() * 4 + 4) + 's';
            
            // Color aleatorio entre verde y azul
            const colors = ['#00ff88', '#00ccff', '#00ffcc', '#88ff00'];
            particle.style.background = colors[Math.floor(Math.random() * colors.length)];
            
            // Tamaño aleatorio
            const size = Math.random() * 3 + 1;
            particle.style.width = size + 'px';
            particle.style.height = size + 'px';
            
            container.appendChild(particle);
        }
    }
    
    // Configurar event listeners
    setupEventListeners() {
        // Resize window
        window.addEventListener('resize', () => {
            this.createQuantumParticles();
        });
        
        // Hover effects para tarjetas
        document.querySelectorAll('.feature-card, .stat-item').forEach(card => {
            card.addEventListener('mouseenter', this.handleCardHover.bind(this));
            card.addEventListener('mouseleave', this.handleCardLeave.bind(this));
        });
        
        // Click effects para botones
        document.querySelectorAll('.nav-link, .btn-primary, .btn-premium').forEach(btn => {
            btn.addEventListener('click', this.handleButtonClick.bind(this));
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', this.handleKeyboard.bind(this));
    }
    
    // Efectos de hover para tarjetas
    handleCardHover(e) {
        const card = e.currentTarget;
        card.style.transform = 'translateY(-15px) scale(1.02)';
        card.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
        
        // Efecto de brillo
        card.style.boxShadow = '0 25px 50px rgba(0, 255, 136, 0.4)';
        
        // Si es premium, usar color dorado
        if (card.classList.contains('premium-feature')) {
            card.style.boxShadow = '0 25px 50px rgba(255, 215, 0, 0.4)';
        }
    }
    
    handleCardLeave(e) {
        const card = e.currentTarget;
        card.style.transform = 'translateY(0) scale(1)';
        card.style.boxShadow = '';
    }
    
    // Efectos de click para botones
    handleButtonClick(e) {
        const btn = e.currentTarget;
        
        // Crear efecto de onda
        const ripple = document.createElement('span');
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.background = 'rgba(255, 255, 255, 0.6)';
        ripple.style.transform = 'scale(0)';
        ripple.style.animation = 'ripple 0.6s linear';
        ripple.style.left = '50%';
        ripple.style.top = '50%';
        ripple.style.width = '20px';
        ripple.style.height = '20px';
        ripple.style.marginLeft = '-10px';
        ripple.style.marginTop = '-10px';
        
        btn.style.position = 'relative';
        btn.style.overflow = 'hidden';
        btn.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }
    
    // Atajos de teclado
    handleKeyboard(e) {
        // Ctrl + Shift + A = Admin
        if (e.ctrlKey && e.shiftKey && e.key === 'A') {
            window.location.href = 'admin/';
        }
        
        // Ctrl + Shift + C = ChatBot
        if (e.ctrlKey && e.shiftKey && e.key === 'C') {
            window.location.href = 'modules/chat/chatbot.php';
        }
        
        // Escape = Scroll to top
        if (e.key === 'Escape') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }
    
    // Actualizar estadísticas en tiempo real
    startStatsUpdater() {
        setInterval(() => {
            this.updateStats();
        }, this.statsUpdateInterval);
    }
    
    updateStats() {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        statNumbers.forEach(stat => {
            const currentValue = parseInt(stat.textContent.replace(/,/g, ''));
            
            // 20% de probabilidad de cambio
            if (Math.random() > 0.8) {
                const change = Math.floor(Math.random() * 5) - 2; // -2 a +2
                const newValue = Math.max(0, currentValue + change);
                
                // Animar el cambio
                this.animateNumber(stat, currentValue, newValue);
            }
        });
    }
    
    // Animar cambio de números
    animateNumber(element, from, to) {
        const duration = 1000;
        const start = Date.now();
        
        const animate = () => {
            const now = Date.now();
            const progress = Math.min((now - start) / duration, 1);
            
            const current = Math.floor(from + (to - from) * progress);
            element.textContent = current.toLocaleString();
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };
        
        animate();
    }
    
    // Efectos de scroll
    setupScrollEffects() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, observerOptions);
        
        // Observar elementos
        document.querySelectorAll('.feature-card, .stat-item, .auth-card').forEach(el => {
            observer.observe(el);
        });
    }
    
    // Validación de formularios
    setupFormValidation() {
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', (e) => {
                if (!this.validateForm(form)) {
                    e.preventDefault();
                    this.showNotification('Por favor, completa todos los campos correctamente', 'error');
                }
            });
            
            // Validación en tiempo real
            form.querySelectorAll('input').forEach(input => {
                input.addEventListener('blur', () => {
                    this.validateField(input);
                });
                
                input.addEventListener('input', () => {
                    this.clearFieldError(input);
                });
            });
        });
    }
    
    validateForm(form) {
        let isValid = true;
        const inputs = form.querySelectorAll('input[required]');
        
        inputs.forEach(input => {
            if (!this.validateField(input)) {
                isValid = false;
            }
        });
        
        // Validar contraseñas coincidentes
        const password = form.querySelector('input[name="password"]');
        const confirmPassword = form.querySelector('input[name="confirm_password"]');
        
        if (password && confirmPassword && password.value !== confirmPassword.value) {
            this.setFieldError(confirmPassword, 'Las contraseñas no coinciden');
            isValid = false;
        }
        
        return isValid;
    }
    
    validateField(input) {
        const value = input.value.trim();
        let isValid = true;
        
        // Campo requerido
        if (input.hasAttribute('required') && !value) {
            this.setFieldError(input, 'Este campo es requerido');
            return false;
        }
        
        // Validación por tipo
        switch (input.type) {
            case 'email':
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (value && !emailRegex.test(value)) {
                    this.setFieldError(input, 'Email inválido');
                    isValid = false;
                }
                break;
                
            case 'password':
                if (value && value.length < 6) {
                    this.setFieldError(input, 'La contraseña debe tener al menos 6 caracteres');
                    isValid = false;
                }
                break;
        }
        
        // Validación por nombre
        if (input.name === 'username' && value) {
            const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
            if (!usernameRegex.test(value)) {
                this.setFieldError(input, 'Usuario debe tener 3-20 caracteres (letras, números, _)');
                isValid = false;
            }
        }
        
        if (isValid) {
            this.clearFieldError(input);
        }
        
        return isValid;
    }
    
    setFieldError(input, message) {
        input.style.borderColor = '#ff4444';
        
        // Remover mensaje anterior
        const existingError = input.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
        
        // Agregar nuevo mensaje
        const errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.style.color = '#ff4444';
        errorDiv.style.fontSize = '0.8rem';
        errorDiv.style.marginTop = '5px';
        errorDiv.textContent = message;
        
        input.parentNode.appendChild(errorDiv);
    }
    
    clearFieldError(input) {
        input.style.borderColor = '#00ff88';
        
        const errorDiv = input.parentNode.querySelector('.field-error');
        if (errorDiv) {
            errorDiv.remove();
        }
    }
    
    // Smooth scrolling
    setupSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }
    
    // Mostrar notificaciones
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: ${type === 'error' ? '#ff4444' : '#00ff88'};
            color: ${type === 'error' ? '#fff' : '#000'};
            padding: 15px 25px;
            border-radius: 25px;
            font-weight: bold;
            z-index: 10000;
            animation: slideDown 0.3s ease;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideUp 0.3s ease';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
    
    // Método para actualizar estado premium
    updatePremiumStatus(isPremium) {
        const indicator = document.querySelector('.premium-indicator');
        const premiumFeatures = document.querySelectorAll('.premium-feature');
        
        if (indicator) {
            if (isPremium) {
                indicator.className = 'premium-indicator active';
                indicator.textContent = '💎 PREMIUM ACTIVO';
            } else {
                indicator.className = 'premium-indicator inactive';
                indicator.textContent = '🔒 MODO BÁSICO';
            }
        }
        
        premiumFeatures.forEach(feature => {
            const status = feature.querySelector('.feature-status');
            if (status) {
                if (isPremium) {
                    status.className = 'feature-status active';
                    status.textContent = '✅ ACTIVO';
                } else {
                    status.className = 'feature-status inactive';
                    status.textContent = '🔒 PREMIUM';
                }
            }
        });
    }
}

// Agregar estilos de animación
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    @keyframes slideDown {
        from {
            transform: translateX(-50%) translateY(-100%);
            opacity: 0;
        }
        to {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }
    }
    
    @keyframes slideUp {
        from {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }
        to {
            transform: translateX(-50%) translateY(-100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.guardianIA = new GuardianIA();
});

// Funciones globales para uso externo
window.GuardianUtils = {
    showNotification: (message, type) => {
        if (window.guardianIA) {
            window.guardianIA.showNotification(message, type);
        }
    },
    
    updatePremiumStatus: (isPremium) => {
        if (window.guardianIA) {
            window.guardianIA.updatePremiumStatus(isPremium);
        }
    },
    
    refreshParticles: () => {
        if (window.guardianIA) {
            window.guardianIA.createQuantumParticles();
        }
    }
};

