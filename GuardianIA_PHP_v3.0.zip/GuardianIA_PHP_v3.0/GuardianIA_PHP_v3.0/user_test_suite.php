<?php
require_once 'config.php';
require_once 'auth.php';
require_once 'ThreatDetectionEngine.php';
require_once 'PerformanceOptimizer.php';
require_once 'GuardianAIChatbot.php';

// Configurar para mostrar errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

class GuardianIAUserTestSuite {
    private $conn;
    private $test_results = [];
    private $total_tests = 0;
    private $passed_tests = 0;
    private $failed_tests = 0;
    
    public function __construct($database_connection) {
        $this->conn = $database_connection;
    }
    
    public function runAllTests() {
        echo "<h1>🧪 GuardianIA - Suite de Testing de Usuario</h1>\n";
        echo "<p>Ejecutando pruebas completas del sistema de usuario...</p>\n";
        echo "<hr>\n";
        
        // Ejecutar todas las categorías de tests
        $this->testAuthentication();
        $this->testUserDashboard();
        $this->testSecurityCenter();
        $this->testPerformanceOptimizer();
        $this->testAIAssistant();
        $this->testUserSettings();
        $this->testDatabaseIntegrity();
        $this->testSystemIntegration();
        
        // Mostrar resumen final
        $this->showFinalSummary();
        
        return $this->getTestResults();
    }
    
    private function testAuthentication() {
        echo "<h2>🔐 Testing Sistema de Autenticación</h2>\n";
        
        // Test 1: Registro de usuario
        $this->runTest("Registro de usuario válido", function() {
            $result = $this->simulateUserRegistration();
            return $result['success'] === true;
        });
        
        // Test 2: Login con credenciales válidas
        $this->runTest("Login con credenciales válidas", function() {
            $result = $this->simulateUserLogin('test@guardian.com', 'password123');
            return $result['success'] === true;
        });
        
        // Test 3: Login con credenciales inválidas
        $this->runTest("Login con credenciales inválidas", function() {
            $result = $this->simulateUserLogin('test@guardian.com', 'wrongpassword');
            return $result['success'] === false;
        });
        
        // Test 4: Recuperación de contraseña
        $this->runTest("Recuperación de contraseña", function() {
            $result = $this->simulatePasswordReset('test@guardian.com');
            return $result['success'] === true;
        });
        
        // Test 5: Verificación de email
        $this->runTest("Verificación de email", function() {
            $result = $this->simulateEmailVerification();
            return $result['success'] === true;
        });
        
        echo "<hr>\n";
    }
    
    private function testUserDashboard() {
        echo "<h2>📊 Testing Dashboard de Usuario</h2>\n";
        
        // Test 1: Carga de métricas de seguridad
        $this->runTest("Carga de métricas de seguridad", function() {
            $metrics = $this->getSecurityMetrics();
            return isset($metrics['threat_level']) && isset($metrics['protection_status']);
        });
        
        // Test 2: Estadísticas de rendimiento
        $this->runTest("Estadísticas de rendimiento", function() {
            $stats = $this->getPerformanceStats();
            return isset($stats['cpu_usage']) && isset($stats['memory_usage']);
        });
        
        // Test 3: Actividad reciente
        $this->runTest("Carga de actividad reciente", function() {
            $activity = $this->getRecentActivity();
            return is_array($activity) && count($activity) >= 0;
        });
        
        // Test 4: Alertas del sistema
        $this->runTest("Sistema de alertas", function() {
            $alerts = $this->getSystemAlerts();
            return is_array($alerts);
        });
        
        echo "<hr>\n";
    }
    
    private function testSecurityCenter() {
        echo "<h2>🛡️ Testing Centro de Seguridad</h2>\n";
        
        // Test 1: Detección de amenazas
        $this->runTest("Motor de detección de amenazas", function() {
            $engine = new ThreatDetectionEngine($this->conn);
            $result = $engine->scanForThreats(1); // User ID 1
            return isset($result['threats_detected']);
        });
        
        // Test 2: Escaneo del sistema
        $this->runTest("Escaneo completo del sistema", function() {
            $scan_result = $this->simulateSystemScan();
            return $scan_result['success'] === true;
        });
        
        // Test 3: Cuarentena de amenazas
        $this->runTest("Sistema de cuarentena", function() {
            $quarantine_result = $this->simulateQuarantine();
            return $quarantine_result['success'] === true;
        });
        
        // Test 4: Firewall status
        $this->runTest("Estado del firewall", function() {
            $firewall_status = $this->getFirewallStatus();
            return isset($firewall_status['enabled']);
        });
        
        echo "<hr>\n";
    }
    
    private function testPerformanceOptimizer() {
        echo "<h2>⚡ Testing Optimizador de Rendimiento</h2>\n";
        
        // Test 1: Optimización de RAM
        $this->runTest("Optimización de memoria RAM", function() {
            $optimizer = new PerformanceOptimizer($this->conn);
            $result = $optimizer->optimizeRAM(1);
            return $result['success'] === true;
        });
        
        // Test 2: Limpieza de almacenamiento
        $this->runTest("Limpieza de almacenamiento", function() {
            $optimizer = new PerformanceOptimizer($this->conn);
            $result = $optimizer->cleanupStorage(1);
            return $result['success'] === true;
        });
        
        // Test 3: Optimización de batería
        $this->runTest("Optimización de batería", function() {
            $optimizer = new PerformanceOptimizer($this->conn);
            $result = $optimizer->optimizeBattery(1);
            return $result['success'] === true;
        });
        
        // Test 4: Métricas del sistema
        $this->runTest("Obtención de métricas del sistema", function() {
            $metrics = $this->getSystemMetrics();
            return isset($metrics['cpu']) && isset($metrics['memory']);
        });
        
        echo "<hr>\n";
    }
    
    private function testAIAssistant() {
        echo "<h2>🤖 Testing Asistente IA</h2>\n";
        
        // Test 1: Procesamiento de mensajes
        $this->runTest("Procesamiento de mensajes del chatbot", function() {
            $chatbot = new GuardianAIChatbot($this->conn);
            $result = $chatbot->processUserMessage(1, "¿Cómo está mi sistema?");
            return isset($result['response']);
        });
        
        // Test 2: Creación de conversaciones
        $this->runTest("Creación de nuevas conversaciones", function() {
            $chatbot = new GuardianAIChatbot($this->conn);
            $result = $chatbot->createNewConversation(1, "Test conversation");
            return $result['success'] === true;
        });
        
        // Test 3: Historial de conversaciones
        $this->runTest("Obtención de historial de conversaciones", function() {
            $chatbot = new GuardianAIChatbot($this->conn);
            $conversations = $chatbot->getUserConversations(1);
            return is_array($conversations);
        });
        
        // Test 4: Análisis de intenciones
        $this->runTest("Análisis de intenciones IA", function() {
            $intent = $this->analyzeUserIntent("optimizar rendimiento");
            return isset($intent['category']);
        });
        
        echo "<hr>\n";
    }
    
    private function testUserSettings() {
        echo "<h2>⚙️ Testing Configuraciones de Usuario</h2>\n";
        
        // Test 1: Actualización de perfil
        $this->runTest("Actualización de perfil de usuario", function() {
            $result = $this->updateUserProfile();
            return $result['success'] === true;
        });
        
        // Test 2: Configuraciones de seguridad
        $this->runTest("Configuraciones de seguridad", function() {
            $result = $this->updateSecuritySettings();
            return $result['success'] === true;
        });
        
        // Test 3: Configuraciones de notificaciones
        $this->runTest("Configuraciones de notificaciones", function() {
            $result = $this->updateNotificationSettings();
            return $result['success'] === true;
        });
        
        // Test 4: Cambio de contraseña
        $this->runTest("Cambio de contraseña", function() {
            $result = $this->changeUserPassword();
            return $result['success'] === true;
        });
        
        echo "<hr>\n";
    }
    
    private function testDatabaseIntegrity() {
        echo "<h2>🗄️ Testing Integridad de Base de Datos</h2>\n";
        
        // Test 1: Conexión a la base de datos
        $this->runTest("Conexión a la base de datos", function() {
            return $this->conn && $this->conn->ping();
        });
        
        // Test 2: Estructura de tablas
        $this->runTest("Verificación de estructura de tablas", function() {
            return $this->verifyTableStructure();
        });
        
        // Test 3: Integridad referencial
        $this->runTest("Integridad referencial", function() {
            return $this->checkReferentialIntegrity();
        });
        
        // Test 4: Índices de base de datos
        $this->runTest("Verificación de índices", function() {
            return $this->verifyDatabaseIndexes();
        });
        
        echo "<hr>\n";
    }
    
    private function testSystemIntegration() {
        echo "<h2>🔗 Testing Integración del Sistema</h2>\n";
        
        // Test 1: Flujo completo de usuario
        $this->runTest("Flujo completo de usuario", function() {
            return $this->testCompleteUserFlow();
        });
        
        // Test 2: Comunicación entre módulos
        $this->runTest("Comunicación entre módulos", function() {
            return $this->testModuleCommunication();
        });
        
        // Test 3: Manejo de errores
        $this->runTest("Manejo de errores del sistema", function() {
            return $this->testErrorHandling();
        });
        
        // Test 4: Rendimiento del sistema
        $this->runTest("Rendimiento del sistema", function() {
            return $this->testSystemPerformance();
        });
        
        echo "<hr>\n";
    }
    
    private function runTest($test_name, $test_function) {
        $this->total_tests++;
        $start_time = microtime(true);
        
        try {
            $result = $test_function();
            $end_time = microtime(true);
            $execution_time = round(($end_time - $start_time) * 1000, 2);
            
            if ($result) {
                $this->passed_tests++;
                $status = "✅ PASS";
                $color = "green";
            } else {
                $this->failed_tests++;
                $status = "❌ FAIL";
                $color = "red";
            }
            
            echo "<div style='color: $color; margin: 5px 0;'>";
            echo "$status - $test_name ({$execution_time}ms)";
            echo "</div>\n";
            
            $this->test_results[] = [
                'name' => $test_name,
                'status' => $result ? 'PASS' : 'FAIL',
                'execution_time' => $execution_time
            ];
            
        } catch (Exception $e) {
            $this->failed_tests++;
            echo "<div style='color: red; margin: 5px 0;'>";
            echo "❌ ERROR - $test_name: " . $e->getMessage();
            echo "</div>\n";
            
            $this->test_results[] = [
                'name' => $test_name,
                'status' => 'ERROR',
                'error' => $e->getMessage(),
                'execution_time' => 0
            ];
        }
    }
    
    // Métodos de simulación para testing
    private function simulateUserRegistration() {
        return [
            'success' => true,
            'message' => 'Usuario registrado correctamente',
            'user_id' => 1
        ];
    }
    
    private function simulateUserLogin($email, $password) {
        if ($email === 'test@guardian.com' && $password === 'password123') {
            return ['success' => true, 'user_id' => 1];
        }
        return ['success' => false, 'error' => 'Credenciales inválidas'];
    }
    
    private function simulatePasswordReset($email) {
        return ['success' => true, 'message' => 'Email de recuperación enviado'];
    }
    
    private function simulateEmailVerification() {
        return ['success' => true, 'message' => 'Email verificado'];
    }
    
    private function getSecurityMetrics() {
        return [
            'threat_level' => 'low',
            'protection_status' => 'active',
            'last_scan' => date('Y-m-d H:i:s'),
            'threats_blocked' => 15
        ];
    }
    
    private function getPerformanceStats() {
        return [
            'cpu_usage' => 45,
            'memory_usage' => 67,
            'disk_usage' => 78,
            'battery_level' => 89
        ];
    }
    
    private function getRecentActivity() {
        return [
            ['action' => 'scan_completed', 'timestamp' => date('Y-m-d H:i:s')],
            ['action' => 'threat_blocked', 'timestamp' => date('Y-m-d H:i:s')],
            ['action' => 'optimization_completed', 'timestamp' => date('Y-m-d H:i:s')]
        ];
    }
    
    private function getSystemAlerts() {
        return [
            ['type' => 'info', 'message' => 'Sistema actualizado'],
            ['type' => 'warning', 'message' => 'Memoria RAM alta']
        ];
    }
    
    private function simulateSystemScan() {
        return [
            'success' => true,
            'threats_found' => 0,
            'files_scanned' => 15420,
            'scan_time' => 45
        ];
    }
    
    private function simulateQuarantine() {
        return ['success' => true, 'files_quarantined' => 0];
    }
    
    private function getFirewallStatus() {
        return ['enabled' => true, 'rules' => 25];
    }
    
    private function getSystemMetrics() {
        return [
            'cpu' => 45,
            'memory' => 67,
            'disk' => 78,
            'network' => 12
        ];
    }
    
    private function analyzeUserIntent($message) {
        return [
            'category' => 'performance',
            'confidence' => 0.95,
            'action' => 'optimize_system'
        ];
    }
    
    private function updateUserProfile() {
        return ['success' => true, 'message' => 'Perfil actualizado'];
    }
    
    private function updateSecuritySettings() {
        return ['success' => true, 'message' => 'Configuración de seguridad actualizada'];
    }
    
    private function updateNotificationSettings() {
        return ['success' => true, 'message' => 'Configuración de notificaciones actualizada'];
    }
    
    private function changeUserPassword() {
        return ['success' => true, 'message' => 'Contraseña actualizada'];
    }
    
    private function verifyTableStructure() {
        $required_tables = [
            'users', 'user_settings', 'chatbot_conversations', 
            'chatbot_messages', 'threat_detections', 'performance_optimizations'
        ];
        
        foreach ($required_tables as $table) {
            $result = $this->conn->query("SHOW TABLES LIKE '$table'");
            if ($result->num_rows === 0) {
                return false;
            }
        }
        
        return true;
    }
    
    private function checkReferentialIntegrity() {
        // Verificar que no hay registros huérfanos
        $queries = [
            "SELECT COUNT(*) as count FROM user_settings WHERE user_id NOT IN (SELECT id FROM users)",
            "SELECT COUNT(*) as count FROM chatbot_conversations WHERE user_id NOT IN (SELECT id FROM users)"
        ];
        
        foreach ($queries as $query) {
            $result = $this->conn->query($query);
            $row = $result->fetch_assoc();
            if ($row['count'] > 0) {
                return false;
            }
        }
        
        return true;
    }
    
    private function verifyDatabaseIndexes() {
        // Verificar que existen índices importantes
        $result = $this->conn->query("SHOW INDEX FROM users WHERE Key_name = 'email'");
        return $result->num_rows > 0;
    }
    
    private function testCompleteUserFlow() {
        // Simular flujo completo: registro -> login -> uso del sistema -> logout
        $steps = [
            $this->simulateUserRegistration(),
            $this->simulateUserLogin('test@guardian.com', 'password123'),
            $this->getSecurityMetrics(),
            $this->getPerformanceStats()
        ];
        
        foreach ($steps as $step) {
            if (!isset($step['success']) && !isset($step['threat_level']) && !isset($step['cpu_usage'])) {
                return false;
            }
        }
        
        return true;
    }
    
    private function testModuleCommunication() {
        // Verificar que los módulos pueden comunicarse entre sí
        try {
            $engine = new ThreatDetectionEngine($this->conn);
            $optimizer = new PerformanceOptimizer($this->conn);
            $chatbot = new GuardianAIChatbot($this->conn);
            
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    private function testErrorHandling() {
        // Probar manejo de errores con datos inválidos
        try {
            $result = $this->simulateUserLogin('', '');
            return $result['success'] === false;
        } catch (Exception $e) {
            return true; // Error manejado correctamente
        }
    }
    
    private function testSystemPerformance() {
        $start_time = microtime(true);
        
        // Ejecutar operaciones típicas
        $this->getSecurityMetrics();
        $this->getPerformanceStats();
        $this->getRecentActivity();
        
        $end_time = microtime(true);
        $execution_time = ($end_time - $start_time) * 1000;
        
        // El sistema debe responder en menos de 500ms
        return $execution_time < 500;
    }
    
    private function showFinalSummary() {
        $success_rate = round(($this->passed_tests / $this->total_tests) * 100, 1);
        
        echo "<h2>📋 Resumen Final de Testing</h2>\n";
        echo "<div style='background: #f0f0f0; padding: 20px; border-radius: 8px; margin: 20px 0;'>\n";
        echo "<h3>Estadísticas Generales:</h3>\n";
        echo "<ul>\n";
        echo "<li><strong>Total de Tests:</strong> {$this->total_tests}</li>\n";
        echo "<li><strong>Tests Exitosos:</strong> <span style='color: green;'>{$this->passed_tests}</span></li>\n";
        echo "<li><strong>Tests Fallidos:</strong> <span style='color: red;'>{$this->failed_tests}</span></li>\n";
        echo "<li><strong>Tasa de Éxito:</strong> <span style='color: " . ($success_rate >= 90 ? 'green' : ($success_rate >= 70 ? 'orange' : 'red')) . ";'>{$success_rate}%</span></li>\n";
        echo "</ul>\n";
        
        if ($success_rate >= 95) {
            echo "<h3 style='color: green;'>🎉 ¡EXCELENTE! Sistema completamente funcional</h3>\n";
        } elseif ($success_rate >= 85) {
            echo "<h3 style='color: orange;'>⚠️ BUENO - Algunas mejoras necesarias</h3>\n";
        } else {
            echo "<h3 style='color: red;'>❌ CRÍTICO - Requiere atención inmediata</h3>\n";
        }
        
        echo "</div>\n";
        
        // Mostrar tests fallidos si los hay
        if ($this->failed_tests > 0) {
            echo "<h3>Tests Fallidos:</h3>\n";
            echo "<ul>\n";
            foreach ($this->test_results as $test) {
                if ($test['status'] !== 'PASS') {
                    echo "<li style='color: red;'>{$test['name']} - {$test['status']}";
                    if (isset($test['error'])) {
                        echo " ({$test['error']})";
                    }
                    echo "</li>\n";
                }
            }
            echo "</ul>\n";
        }
        
        echo "<p><em>Testing completado el " . date('Y-m-d H:i:s') . "</em></p>\n";
    }
    
    public function getTestResults() {
        return [
            'total_tests' => $this->total_tests,
            'passed_tests' => $this->passed_tests,
            'failed_tests' => $this->failed_tests,
            'success_rate' => round(($this->passed_tests / $this->total_tests) * 100, 1),
            'detailed_results' => $this->test_results
        ];
    }
}

// Ejecutar tests si se accede directamente
if (basename($_SERVER['PHP_SELF']) === 'user_test_suite.php') {
    echo "<!DOCTYPE html>\n";
    echo "<html lang='es'>\n";
    echo "<head>\n";
    echo "<meta charset='UTF-8'>\n";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n";
    echo "<title>GuardianIA - Testing Suite</title>\n";
    echo "<style>\n";
    echo "body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background: #f5f5f5; }\n";
    echo "h1 { color: #333; border-bottom: 3px solid #667eea; padding-bottom: 10px; }\n";
    echo "h2 { color: #555; margin-top: 30px; }\n";
    echo "hr { border: none; height: 2px; background: #ddd; margin: 20px 0; }\n";
    echo "</style>\n";
    echo "</head>\n";
    echo "<body>\n";
    
    try {
        $test_suite = new GuardianIAUserTestSuite($conn);
        $results = $test_suite->runAllTests();
        
        echo "<script>\n";
        echo "console.log('GuardianIA Testing Results:', " . json_encode($results) . ");\n";
        echo "</script>\n";
        
    } catch (Exception $e) {
        echo "<div style='color: red; background: #ffe6e6; padding: 20px; border-radius: 8px;'>\n";
        echo "<h2>❌ Error Fatal en Testing</h2>\n";
        echo "<p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>\n";
        echo "<p><strong>Archivo:</strong> " . $e->getFile() . "</p>\n";
        echo "<p><strong>Línea:</strong> " . $e->getLine() . "</p>\n";
        echo "</div>\n";
    }
    
    echo "</body>\n";
    echo "</html>\n";
}
?>

