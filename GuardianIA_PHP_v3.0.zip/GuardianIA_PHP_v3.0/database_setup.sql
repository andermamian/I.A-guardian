-- =====================================================
-- GuardianIA - Base de Datos Completa
-- Sistema de Protección Inteligente Avanzada
-- Versión 2.0.0
-- =====================================================

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS guardianai_db 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE guardianai_db;

-- =====================================================
-- TABLAS DE USUARIOS Y AUTENTICACIÓN
-- =====================================================

-- Tabla de usuarios
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role ENUM('admin', 'user', 'premium') DEFAULT 'user',
    status ENUM('active', 'inactive', 'suspended', 'banned') DEFAULT 'active',
    last_login DATETIME NULL,
    login_attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- Tabla de sesiones de usuario
CREATE TABLE user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(128) UNIQUE NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (session_token),
    INDEX idx_user_id (user_id),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB;

-- Tabla de configuraciones de usuario
CREATE TABLE user_preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    notification_level ENUM('low', 'medium', 'high') DEFAULT 'medium',
    scan_frequency ENUM('real_time', 'hourly', 'daily', 'weekly') DEFAULT 'real_time',
    auto_optimization BOOLEAN DEFAULT TRUE,
    ai_learning_enabled BOOLEAN DEFAULT TRUE,
    theme ENUM('light', 'dark', 'auto') DEFAULT 'auto',
    language VARCHAR(5) DEFAULT 'es',
    timezone VARCHAR(50) DEFAULT 'America/Mexico_City',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_prefs (user_id)
) ENGINE=InnoDB;

-- =====================================================
-- TABLAS DE DETECCIÓN DE AMENAZAS
-- =====================================================

-- Tabla de tipos de amenazas
CREATE TABLE threat_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    severity_level ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    color_code VARCHAR(7) DEFAULT '#FF0000',
    icon VARCHAR(50) DEFAULT 'warning',
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla de eventos de amenazas
CREATE TABLE threat_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    threat_type_id INT NOT NULL,
    source_ip VARCHAR(45),
    target_resource VARCHAR(255),
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    confidence_score DECIMAL(5,2) NOT NULL CHECK (confidence_score >= 0 AND confidence_score <= 100),
    status ENUM('detected', 'analyzing', 'blocked', 'resolved', 'false_positive') DEFAULT 'detected',
    mitigation_action VARCHAR(100),
    details JSON,
    ai_analysis JSON,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (threat_type_id) REFERENCES threat_types(id),
    INDEX idx_user_id (user_id),
    INDEX idx_threat_type (threat_type_id),
    INDEX idx_severity (severity),
    INDEX idx_status (status),
    INDEX idx_detected_at (detected_at),
    INDEX idx_confidence (confidence_score)
) ENGINE=InnoDB;

-- Tabla de patrones de amenazas (para IA)
CREATE TABLE threat_patterns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pattern_name VARCHAR(100) NOT NULL,
    pattern_type ENUM('signature', 'behavioral', 'anomaly', 'heuristic') NOT NULL,
    pattern_data JSON NOT NULL,
    threat_type_id INT NOT NULL,
    accuracy_rate DECIMAL(5,2) DEFAULT 0.00,
    false_positive_rate DECIMAL(5,2) DEFAULT 0.00,
    usage_count INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    active BOOLEAN DEFAULT TRUE,
    
    FOREIGN KEY (threat_type_id) REFERENCES threat_types(id),
    INDEX idx_pattern_type (pattern_type),
    INDEX idx_threat_type (threat_type_id),
    INDEX idx_accuracy (accuracy_rate),
    INDEX idx_active (active)
) ENGINE=InnoDB;

-- Tabla de respuestas automáticas
CREATE TABLE automated_responses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    threat_type_id INT NOT NULL,
    response_name VARCHAR(100) NOT NULL,
    response_type ENUM('block', 'quarantine', 'alert', 'log', 'custom') NOT NULL,
    response_config JSON,
    trigger_conditions JSON,
    priority INT DEFAULT 1,
    active BOOLEAN DEFAULT TRUE,
    success_rate DECIMAL(5,2) DEFAULT 0.00,
    execution_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (threat_type_id) REFERENCES threat_types(id),
    INDEX idx_threat_type (threat_type_id),
    INDEX idx_response_type (response_type),
    INDEX idx_priority (priority),
    INDEX idx_active (active)
) ENGINE=InnoDB;

-- =====================================================
-- TABLAS DE OPTIMIZACIÓN DE RENDIMIENTO
-- =====================================================

-- Tabla de métricas del sistema
CREATE TABLE system_metrics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    cpu_usage DECIMAL(5,2) NOT NULL,
    ram_usage DECIMAL(5,2) NOT NULL,
    ram_total BIGINT NOT NULL,
    ram_available BIGINT NOT NULL,
    storage_usage DECIMAL(5,2) NOT NULL,
    storage_total BIGINT NOT NULL,
    storage_available BIGINT NOT NULL,
    battery_level DECIMAL(5,2),
    battery_health DECIMAL(5,2),
    temperature DECIMAL(5,2),
    network_speed DECIMAL(10,2),
    active_processes INT,
    system_load DECIMAL(5,2),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_recorded_at (recorded_at),
    INDEX idx_cpu_usage (cpu_usage),
    INDEX idx_ram_usage (ram_usage),
    INDEX idx_battery_level (battery_level)
) ENGINE=InnoDB;

-- Tabla de tareas de optimización
CREATE TABLE optimization_tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    task_type ENUM('ram_cleanup', 'storage_cleanup', 'battery_optimization', 'process_optimization', 'cache_cleanup') NOT NULL,
    task_name VARCHAR(100) NOT NULL,
    description TEXT,
    status ENUM('pending', 'running', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    progress DECIMAL(5,2) DEFAULT 0.00,
    estimated_benefit JSON,
    actual_benefit JSON,
    execution_time DECIMAL(8,3),
    error_message TEXT,
    scheduled_at TIMESTAMP NULL,
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_task_type (task_type),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_scheduled_at (scheduled_at)
) ENGINE=InnoDB;

-- Tabla de resultados de optimización
CREATE TABLE optimization_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    optimization_task_id INT NOT NULL,
    metric_before JSON NOT NULL,
    metric_after JSON NOT NULL,
    improvement_percentage DECIMAL(5,2),
    resources_freed BIGINT,
    performance_gain DECIMAL(5,2),
    user_satisfaction ENUM('very_poor', 'poor', 'average', 'good', 'excellent') NULL,
    feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (optimization_task_id) REFERENCES optimization_tasks(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_task_id (optimization_task_id),
    INDEX idx_improvement (improvement_percentage)
) ENGINE=InnoDB;

-- =====================================================
-- TABLAS DE INTELIGENCIA ARTIFICIAL
-- =====================================================

-- Tabla de modelos de IA
CREATE TABLE ai_models (
    id INT AUTO_INCREMENT PRIMARY KEY,
    model_name VARCHAR(100) UNIQUE NOT NULL,
    model_type ENUM('threat_detection', 'performance_optimization', 'behavioral_analysis', 'chatbot', 'predictive') NOT NULL,
    version VARCHAR(20) NOT NULL,
    description TEXT,
    accuracy DECIMAL(5,2) DEFAULT 0.00,
    precision_score DECIMAL(5,2) DEFAULT 0.00,
    recall_score DECIMAL(5,2) DEFAULT 0.00,
    f1_score DECIMAL(5,2) DEFAULT 0.00,
    training_data_size INT DEFAULT 0,
    last_trained TIMESTAMP NULL,
    model_config JSON,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_model_type (model_type),
    INDEX idx_accuracy (accuracy),
    INDEX idx_active (active)
) ENGINE=InnoDB;

-- Tabla de sesiones de aprendizaje
CREATE TABLE learning_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_name VARCHAR(100) NOT NULL,
    ai_model_id INT NOT NULL,
    learning_type ENUM('supervised', 'unsupervised', 'reinforcement', 'transfer') NOT NULL,
    status ENUM('initializing', 'collecting_data', 'training', 'validating', 'completed', 'failed') DEFAULT 'initializing',
    data_points_collected INT DEFAULT 0,
    patterns_discovered INT DEFAULT 0,
    accuracy_improvement DECIMAL(5,2) DEFAULT 0.00,
    confidence_level DECIMAL(5,2) DEFAULT 0.00,
    training_progress DECIMAL(5,2) DEFAULT 0.00,
    insights_generated JSON,
    error_log TEXT,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    
    FOREIGN KEY (ai_model_id) REFERENCES ai_models(id) ON DELETE CASCADE,
    INDEX idx_model_id (ai_model_id),
    INDEX idx_learning_type (learning_type),
    INDEX idx_status (status),
    INDEX idx_started_at (started_at)
) ENGINE=InnoDB;

-- Tabla de patrones de comportamiento del usuario
CREATE TABLE user_behavior_patterns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    pattern_type ENUM('app_usage', 'security_response', 'optimization_preference', 'time_pattern', 'device_interaction') NOT NULL,
    pattern_data JSON NOT NULL,
    frequency DECIMAL(5,2) NOT NULL,
    confidence DECIMAL(5,2) NOT NULL,
    description TEXT,
    last_observed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    prediction_accuracy DECIMAL(5,2) DEFAULT 0.00,
    usage_count INT DEFAULT 0,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_pattern_type (pattern_type),
    INDEX idx_confidence (confidence),
    INDEX idx_last_observed (last_observed)
) ENGINE=InnoDB;

-- =====================================================
-- TABLAS DE CHATBOT IA
-- =====================================================

-- Tabla de conversaciones del chatbot
CREATE TABLE chatbot_conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_id VARCHAR(128) NOT NULL,
    conversation_title VARCHAR(200),
    status ENUM('active', 'completed', 'abandoned') DEFAULT 'active',
    total_messages INT DEFAULT 0,
    satisfaction_rating ENUM('very_poor', 'poor', 'average', 'good', 'excellent') NULL,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_session_id (session_id),
    INDEX idx_status (status),
    INDEX idx_started_at (started_at)
) ENGINE=InnoDB;

-- Tabla de mensajes del chatbot
CREATE TABLE chatbot_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT NOT NULL,
    sender ENUM('user', 'bot') NOT NULL,
    message_text TEXT NOT NULL,
    message_type ENUM('text', 'command', 'file', 'image', 'system') DEFAULT 'text',
    intent_detected VARCHAR(100),
    confidence_score DECIMAL(5,2),
    response_time DECIMAL(8,3),
    context_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (conversation_id) REFERENCES chatbot_conversations(id) ON DELETE CASCADE,
    INDEX idx_conversation_id (conversation_id),
    INDEX idx_sender (sender),
    INDEX idx_intent (intent_detected),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Tabla de conocimientos del chatbot
CREATE TABLE chatbot_knowledge (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50) NOT NULL,
    subcategory VARCHAR(50),
    question_pattern VARCHAR(500) NOT NULL,
    answer_template TEXT NOT NULL,
    keywords JSON,
    confidence_threshold DECIMAL(5,2) DEFAULT 70.00,
    usage_count INT DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0.00,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    active BOOLEAN DEFAULT TRUE,
    
    INDEX idx_category (category),
    INDEX idx_subcategory (subcategory),
    INDEX idx_confidence (confidence_threshold),
    INDEX idx_active (active),
    FULLTEXT idx_question_pattern (question_pattern)
) ENGINE=InnoDB;

-- =====================================================
-- TABLAS DE SISTEMA Y LOGS
-- =====================================================

-- Tabla de logs del sistema
CREATE TABLE system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    log_level ENUM('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL') NOT NULL,
    component VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    context_data JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_log_level (log_level),
    INDEX idx_component (component),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Tabla de configuraciones del sistema
CREATE TABLE system_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    config_type ENUM('string', 'integer', 'float', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    category VARCHAR(50) DEFAULT 'general',
    is_sensitive BOOLEAN DEFAULT FALSE,
    last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    modified_by INT NULL,
    
    FOREIGN KEY (modified_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_config_key (config_key),
    INDEX idx_category (category)
) ENGINE=InnoDB;

-- Tabla de estadísticas del sistema
CREATE TABLE system_statistics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stat_date DATE NOT NULL,
    total_users INT DEFAULT 0,
    active_users INT DEFAULT 0,
    threats_detected INT DEFAULT 0,
    threats_blocked INT DEFAULT 0,
    optimizations_performed INT DEFAULT 0,
    chatbot_interactions INT DEFAULT 0,
    system_uptime DECIMAL(10,2) DEFAULT 0.00,
    average_response_time DECIMAL(8,3) DEFAULT 0.000,
    ai_accuracy DECIMAL(5,2) DEFAULT 0.00,
    user_satisfaction DECIMAL(5,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_stat_date (stat_date),
    INDEX idx_stat_date (stat_date)
) ENGINE=InnoDB;

-- =====================================================
-- INSERTAR DATOS INICIALES
-- =====================================================

-- Insertar tipos de amenazas básicos
INSERT INTO threat_types (name, description, severity_level, color_code, icon) VALUES
('malware', 'Software malicioso que puede dañar el sistema', 'critical', '#FF0000', 'virus'),
('phishing', 'Intento de obtener información confidencial mediante engaño', 'high', '#FF6600', 'fishing'),
('network_intrusion', 'Intento de acceso no autorizado a la red', 'high', '#FF3300', 'network'),
('suspicious_app', 'Aplicación con comportamiento sospechoso', 'medium', '#FFAA00', 'app'),
('data_breach', 'Posible filtración de datos sensibles', 'critical', '#CC0000', 'leak'),
('ransomware', 'Software que cifra archivos y exige rescate', 'critical', '#990000', 'lock'),
('spyware', 'Software que recopila información sin consentimiento', 'high', '#FF4400', 'eye'),
('adware', 'Software que muestra publicidad no deseada', 'low', '#FFCC00', 'ads');

-- Insertar modelos de IA básicos
INSERT INTO ai_models (model_name, model_type, version, description, accuracy) VALUES
('ThreatDetector_v2', 'threat_detection', '2.0.0', 'Modelo principal de detección de amenazas', 94.20),
('PerformanceOptimizer_v2', 'performance_optimization', '2.0.0', 'Modelo de optimización de rendimiento', 87.30),
('BehaviorAnalyzer_v2', 'behavioral_analysis', '2.0.0', 'Analizador de patrones de comportamiento', 89.40),
('GuardianChatbot_v2', 'chatbot', '2.0.0', 'Chatbot inteligente de GuardianIA', 91.20),
('PredictiveMaintenance_v2', 'predictive', '2.0.0', 'Modelo de mantenimiento predictivo', 85.60);

-- Insertar conocimientos básicos del chatbot
INSERT INTO chatbot_knowledge (category, subcategory, question_pattern, answer_template, keywords) VALUES
('security', 'general', '¿mi sistema está seguro?', 'Estoy analizando el estado de seguridad de tu sistema. Permíteme revisar las métricas actuales...', '["seguro", "sistema", "estado", "protección"]'),
('security', 'threats', 'tengo un virus', 'He detectado tu preocupación sobre posible malware. Voy a ejecutar un escaneo completo inmediatamente...', '["virus", "malware", "infectado", "amenaza"]'),
('performance', 'speed', 'el ordenador va lento', 'Entiendo que experimentas lentitud en el sistema. Déjame analizar el uso de recursos y optimizar el rendimiento...', '["lento", "velocidad", "rendimiento", "optimizar"]'),
('performance', 'battery', 'optimizar batería', 'Excelente consulta sobre optimización de batería. Voy a revisar el consumo actual y aplicar mejoras...', '["batería", "optimizar", "duración", "energía"]'),
('help', 'general', 'ayuda', 'Estoy aquí para ayudarte con cualquier consulta sobre seguridad y optimización. ¿En qué puedo asistirte?', '["ayuda", "soporte", "asistencia"]');

-- Insertar configuraciones del sistema
INSERT INTO system_config (config_key, config_value, config_type, description, category) VALUES
('ai_threat_threshold', '0.75', 'float', 'Umbral de confianza para detección de amenazas', 'ai'),
('ai_learning_rate', '0.01', 'float', 'Tasa de aprendizaje de los modelos de IA', 'ai'),
('performance_check_interval', '300', 'integer', 'Intervalo de verificación de rendimiento en segundos', 'performance'),
('max_log_retention_days', '30', 'integer', 'Días de retención de logs del sistema', 'system'),
('chatbot_response_timeout', '30', 'integer', 'Timeout para respuestas del chatbot en segundos', 'chatbot'),
('auto_optimization_enabled', 'true', 'boolean', 'Habilitar optimización automática', 'performance'),
('real_time_protection', 'true', 'boolean', 'Protección en tiempo real habilitada', 'security');

-- Crear usuario administrador por defecto
INSERT INTO users (username, email, password_hash, first_name, last_name, role, status) VALUES
('admin', 'admin@guardianai.com', '$argon2id$v=19$m=65536,t=4,p=3$example_hash', 'Guardian', 'Admin', 'admin', 'active');

-- =====================================================
-- ÍNDICES ADICIONALES PARA OPTIMIZACIÓN
-- =====================================================

-- Índices compuestos para consultas frecuentes
CREATE INDEX idx_threat_events_user_date ON threat_events(user_id, detected_at);
CREATE INDEX idx_system_metrics_user_date ON system_metrics(user_id, recorded_at);
CREATE INDEX idx_optimization_tasks_user_status ON optimization_tasks(user_id, status);
CREATE INDEX idx_chatbot_messages_conv_date ON chatbot_messages(conversation_id, created_at);

-- =====================================================
-- TRIGGERS PARA AUTOMATIZACIÓN
-- =====================================================

-- Trigger para actualizar estadísticas cuando se detecta una amenaza
DELIMITER //
CREATE TRIGGER update_threat_stats 
AFTER INSERT ON threat_events
FOR EACH ROW
BEGIN
    INSERT INTO system_statistics (stat_date, threats_detected) 
    VALUES (CURDATE(), 1)
    ON DUPLICATE KEY UPDATE 
    threats_detected = threats_detected + 1;
END//
DELIMITER ;

-- Trigger para actualizar contadores de uso de patrones
DELIMITER //
CREATE TRIGGER update_pattern_usage 
AFTER INSERT ON threat_events
FOR EACH ROW
BEGIN
    UPDATE threat_patterns 
    SET usage_count = usage_count + 1 
    WHERE threat_type_id = NEW.threat_type_id;
END//
DELIMITER ;

-- =====================================================
-- VISTAS PARA CONSULTAS FRECUENTES
-- =====================================================

-- Vista de resumen de amenazas por usuario
CREATE VIEW user_threat_summary AS
SELECT 
    u.id as user_id,
    u.username,
    COUNT(te.id) as total_threats,
    COUNT(CASE WHEN te.severity = 'critical' THEN 1 END) as critical_threats,
    COUNT(CASE WHEN te.severity = 'high' THEN 1 END) as high_threats,
    COUNT(CASE WHEN te.status = 'blocked' THEN 1 END) as blocked_threats,
    MAX(te.detected_at) as last_threat_detected
FROM users u
LEFT JOIN threat_events te ON u.id = te.user_id
GROUP BY u.id, u.username;

-- Vista de métricas de rendimiento recientes
CREATE VIEW recent_performance_metrics AS
SELECT 
    sm.*,
    u.username,
    LAG(sm.cpu_usage) OVER (PARTITION BY sm.user_id ORDER BY sm.recorded_at) as prev_cpu_usage,
    LAG(sm.ram_usage) OVER (PARTITION BY sm.user_id ORDER BY sm.recorded_at) as prev_ram_usage
FROM system_metrics sm
JOIN users u ON sm.user_id = u.id
WHERE sm.recorded_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR);

-- Vista de estadísticas de IA
CREATE VIEW ai_model_performance AS
SELECT 
    am.model_name,
    am.model_type,
    am.accuracy,
    COUNT(ls.id) as training_sessions,
    AVG(ls.accuracy_improvement) as avg_improvement,
    MAX(ls.completed_at) as last_training
FROM ai_models am
LEFT JOIN learning_sessions ls ON am.id = ls.ai_model_id
WHERE am.active = TRUE
GROUP BY am.id, am.model_name, am.model_type, am.accuracy;

-- =====================================================
-- PROCEDIMIENTOS ALMACENADOS
-- =====================================================

-- Procedimiento para limpiar logs antiguos
DELIMITER //
CREATE PROCEDURE CleanOldLogs()
BEGIN
    DECLARE retention_days INT DEFAULT 30;
    
    SELECT config_value INTO retention_days 
    FROM system_config 
    WHERE config_key = 'max_log_retention_days';
    
    DELETE FROM system_logs 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL retention_days DAY);
    
    DELETE FROM chatbot_messages 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL retention_days DAY);
    
    DELETE FROM system_metrics 
    WHERE recorded_at < DATE_SUB(NOW(), INTERVAL retention_days DAY);
END//
DELIMITER ;

-- Procedimiento para generar estadísticas diarias
DELIMITER //
CREATE PROCEDURE GenerateDailyStats(IN target_date DATE)
BEGIN
    INSERT INTO system_statistics (
        stat_date, 
        total_users, 
        active_users, 
        threats_detected, 
        threats_blocked, 
        optimizations_performed, 
        chatbot_interactions
    )
    SELECT 
        target_date,
        (SELECT COUNT(*) FROM users WHERE status = 'active'),
        (SELECT COUNT(DISTINCT user_id) FROM user_sessions WHERE DATE(created_at) = target_date),
        (SELECT COUNT(*) FROM threat_events WHERE DATE(detected_at) = target_date),
        (SELECT COUNT(*) FROM threat_events WHERE DATE(detected_at) = target_date AND status = 'blocked'),
        (SELECT COUNT(*) FROM optimization_tasks WHERE DATE(completed_at) = target_date AND status = 'completed'),
        (SELECT COUNT(*) FROM chatbot_messages WHERE DATE(created_at) = target_date AND sender = 'user')
    ON DUPLICATE KEY UPDATE
        total_users = VALUES(total_users),
        active_users = VALUES(active_users),
        threats_detected = VALUES(threats_detected),
        threats_blocked = VALUES(threats_blocked),
        optimizations_performed = VALUES(optimizations_performed),
        chatbot_interactions = VALUES(chatbot_interactions);
END//
DELIMITER ;

-- =====================================================
-- EVENTOS PROGRAMADOS
-- =====================================================

-- Evento para limpiar logs antiguos diariamente
CREATE EVENT IF NOT EXISTS daily_log_cleanup
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
  CALL CleanOldLogs();

-- Evento para generar estadísticas diarias
CREATE EVENT IF NOT EXISTS daily_stats_generation
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
  CALL GenerateDailyStats(CURDATE());

-- Habilitar el programador de eventos
SET GLOBAL event_scheduler = ON;

-- =====================================================
-- FINALIZACIÓN
-- =====================================================

-- Mensaje de confirmación
SELECT 'GuardianIA Database Setup Completed Successfully!' as Status;
SELECT COUNT(*) as 'Total Tables Created' FROM information_schema.tables WHERE table_schema = 'guardianai_db';
SELECT COUNT(*) as 'Total Views Created' FROM information_schema.views WHERE table_schema = 'guardianai_db';
SELECT COUNT(*) as 'Total Procedures Created' FROM information_schema.routines WHERE routine_schema = 'guardianai_db' AND routine_type = 'PROCEDURE';
SELECT COUNT(*) as 'Total Events Created' FROM information_schema.events WHERE event_schema = 'guardianai_db';

