<?php
/**
 * GuardianIA v3.0 FINAL - Configuración Principal
 * Anderson Mamian Chicangana - Membresía Premium Activada
 * Sistema Completamente Sincronizado
 */

// Configuración de errores
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// Zona horaria
date_default_timezone_set('America/Bogota');

// Configuración de la aplicación
define('APP_NAME', 'GuardianIA v3.0 FINAL');
define('APP_VERSION', '3.0.0');
define('APP_URL', 'http://localhost');
define('DEVELOPER', 'Anderson Mamian Chicangana');
define('DEVELOPER_EMAIL', 'anderson@guardianai.com');

// Configuración de seguridad
define('ENCRYPTION_KEY', 'GuardianIA_v3.0_Anderson_Premium_SecretKey_2024');
define('SESSION_LIFETIME', 3600 * 24 * 30);
define('CSRF_TOKEN_LIFETIME', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900);

// Configuración Premium (ACTIVADA)
define('PREMIUM_ENABLED', true);
define('PREMIUM_USER', 'anderson');
define('MONTHLY_PRICE', 60000);
define('ANNUAL_DISCOUNT', 0.15);
define('PREMIUM_FEATURES', [
    'ai_antivirus' => true,
    'quantum_encryption' => true,
    'predictive_analysis' => true,
    'ai_vpn' => true,
    'advanced_chatbot' => true,
    'real_time_monitoring' => true,
    'unlimited_conversations' => true,
    'priority_support' => true
]);

// Configuración de IA
define('AI_DETECTION_THRESHOLD', 0.85);
define('CONSCIOUSNESS_THRESHOLD', 0.7);
define('THREAT_LEVEL_HIGH', 8);
define('AI_LEARNING_ENABLED', true);
define('NEURAL_NETWORK_DEPTH', 7);

// Configuración de VPN
define('VPN_ENABLED', true);
define('VPN_SERVERS', [
    'colombia-bogota' => 'Bogotá, Colombia',
    'usa-miami' => 'Miami, USA',
    'spain-madrid' => 'Madrid, España',
    'japan-tokyo' => 'Tokio, Japón'
]);

// Configuración de logs
define('LOG_LEVEL', 'INFO');
define('LOG_ROTATION_SIZE', 10485760);
define('LOG_RETENTION_DAYS', 30);

// Rutas del sistema
define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('MODULES_PATH', ROOT_PATH . '/modules');
define('TEMPLATES_PATH', ROOT_PATH . '/templates');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('LOGS_PATH', ROOT_PATH . '/logs');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('CACHE_PATH', ROOT_PATH . '/cache');

// Crear directorios necesarios
$directories = [LOGS_PATH, UPLOADS_PATH, CACHE_PATH];
foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Autoloader simple
spl_autoload_register(function ($class) {
    $paths = [
        CONFIG_PATH . '/',
        MODULES_PATH . '/',
        MODULES_PATH . '/ai/',
        MODULES_PATH . '/security/',
        MODULES_PATH . '/vpn/',
        MODULES_PATH . '/chat/',
        MODULES_PATH . '/analytics/'
    ];
    
    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Funciones globales
function logEvent($level, $message, $context = []) {
    $timestamp = date('Y-m-d H:i:s');
    $user_id = $_SESSION['user_id'] ?? 'anonymous';
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    $log_entry = [
        'timestamp' => $timestamp,
        'level' => $level,
        'user_id' => $user_id,
        'ip' => $ip,
        'message' => $message,
        'context' => $context
    ];
    
    $log_line = json_encode($log_entry, JSON_UNESCAPED_UNICODE) . PHP_EOL;
    file_put_contents(LOGS_PATH . '/guardian.log', $log_line, FILE_APPEND | LOCK_EX);
}

function encryptData($data) {
    $key = hash('sha256', ENCRYPTION_KEY);
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

function decryptData($data) {
    $key = hash('sha256', ENCRYPTION_KEY);
    list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encrypted_data, 'AES-256-CBC', $key, 0, $iv);
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function isPremiumUser($user_id = null) {
    if (!PREMIUM_ENABLED) return false;
    
    $user_id = $user_id ?? ($_SESSION['user_id'] ?? null);
    if (!$user_id) return false;
    
    try {
        $db = DatabaseConfig::getInstance();
        $result = $db->executeQuery(
            "SELECT COUNT(*) as count FROM memberships WHERE user_id = ? AND status = 'active' AND plan_type = 'premium'",
            [$user_id]
        );
        
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['count'] > 0;
        }
    } catch (Exception $e) {
        logEvent('ERROR', 'Error verificando membresía premium: ' . $e->getMessage());
    }
    
    return false;
}

function hasFeature($feature) {
    return PREMIUM_FEATURES[$feature] ?? false;
}

// Configuración de sesión segura
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

session_set_cookie_params([
    'lifetime' => SESSION_LIFETIME,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Strict'
]);

// Headers de seguridad
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Inicializar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Log de inicialización
logEvent('INFO', 'GuardianIA v3.0 FINAL initialized', [
    'version' => APP_VERSION,
    'developer' => DEVELOPER,
    'premium_enabled' => PREMIUM_ENABLED,
    'php_version' => PHP_VERSION
]);

define('GUARDIAN_CONFIG_LOADED', true);
?>

