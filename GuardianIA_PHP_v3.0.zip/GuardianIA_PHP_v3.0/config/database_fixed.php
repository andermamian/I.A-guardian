<?php
/**
 * GuardianIA v3.0 FINAL - Configuración de Base de Datos CORREGIDA
 * Anderson Mamian Chicangana - Membresía Premium
 * Solución definitiva para problemas de autenticación MySQL
 */

// Configuración de base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'anderson');
define('DB_PASS', 'Ander12345@');
define('DB_NAME', 'guardianai_db');
define('DB_CHARSET', 'utf8mb4');
define('DB_PORT', 3306);

// Configuración de conexión MySQL
define('MYSQL_ATTR_INIT_COMMAND', "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
define('MYSQL_ATTR_TIMEOUT', 30);
define('MYSQL_ATTR_AUTOCOMMIT', 1);

/**
 * Clase de conexión a base de datos con manejo robusto de errores
 */
class DatabaseConnection {
    private static $instance = null;
    private $connection = null;
    private $lastError = null;
    
    private function __construct() {
        $this->connect();
    }
    
    /**
     * Establecer conexión a MySQL con múltiples intentos
     */
    private function connect() {
        $maxAttempts = 3;
        $attempt = 0;
        
        while ($attempt < $maxAttempts) {
            try {
                // Configurar opciones de conexión
                $options = [
                    MYSQLI_OPT_CONNECT_TIMEOUT => MYSQL_ATTR_TIMEOUT,
                    MYSQLI_INIT_COMMAND => MYSQL_ATTR_INIT_COMMAND,
                    MYSQLI_OPT_INT_AND_FLOAT_NATIVE => true,
                    MYSQLI_OPT_SSL_VERIFY_SERVER_CERT => false
                ];
                
                // Crear nueva conexión
                $this->connection = new mysqli();
                
                // Configurar opciones
                foreach ($options as $option => $value) {
                    $this->connection->options($option, $value);
                }
                
                // Conectar
                $this->connection->real_connect(
                    DB_HOST,
                    DB_USER,
                    DB_PASS,
                    DB_NAME,
                    DB_PORT
                );
                
                // Verificar conexión
                if ($this->connection->connect_error) {
                    throw new Exception($this->connection->connect_error);
                }
                
                // Configurar charset
                if (!$this->connection->set_charset(DB_CHARSET)) {
                    throw new Exception("Error configurando charset: " . $this->connection->error);
                }
                
                // Configurar modo SQL
                $this->connection->query("SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
                
                // Configurar timezone
                $this->connection->query("SET time_zone = '+00:00'");
                
                // Log de conexión exitosa
                $this->logEvent('INFO', 'Database connection established successfully', [
                    'host' => DB_HOST,
                    'database' => DB_NAME,
                    'user' => DB_USER,
                    'attempt' => $attempt + 1
                ]);
                
                return; // Conexión exitosa
                
            } catch (Exception $e) {
                $attempt++;
                $this->lastError = $e->getMessage();
                
                $this->logEvent('ERROR', 'Database connection attempt failed', [
                    'attempt' => $attempt,
                    'error' => $this->lastError,
                    'max_attempts' => $maxAttempts
                ]);
                
                if ($attempt >= $maxAttempts) {
                    throw new Exception("Failed to connect to database after $maxAttempts attempts. Last error: " . $this->lastError);
                }
                
                // Esperar antes del siguiente intento
                sleep(1);
            }
        }
    }
    
    /**
     * Obtener instancia singleton
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Obtener conexión MySQL
     */
    public function getConnection() {
        // Verificar si la conexión sigue activa
        if (!$this->connection || !$this->connection->ping()) {
            $this->connect();
        }
        
        return $this->connection;
    }
    
    /**
     * Ejecutar consulta con manejo de errores
     */
    public function query($sql, $params = []) {
        try {
            $conn = $this->getConnection();
            
            if (empty($params)) {
                $result = $conn->query($sql);
                
                if ($result === false) {
                    throw new Exception("Query failed: " . $conn->error);
                }
                
                return $result;
            } else {
                $stmt = $conn->prepare($sql);
                
                if (!$stmt) {
                    throw new Exception("Prepare failed: " . $conn->error);
                }
                
                if (!empty($params)) {
                    $types = $this->getParamTypes($params);
                    $stmt->bind_param($types, ...$params);
                }
                
                if (!$stmt->execute()) {
                    throw new Exception("Execute failed: " . $stmt->error);
                }
                
                $result = $stmt->get_result();
                $stmt->close();
                
                return $result;
            }
            
        } catch (Exception $e) {
            $this->logEvent('ERROR', 'Database query failed', [
                'sql' => $sql,
                'params' => $params,
                'error' => $e->getMessage()
            ]);
            
            throw $e;
        }
    }
    
    /**
     * Obtener tipos de parámetros para bind_param
     */
    private function getParamTypes($params) {
        $types = '';
        
        foreach ($params as $param) {
            if (is_int($param)) {
                $types .= 'i';
            } elseif (is_float($param)) {
                $types .= 'd';
            } elseif (is_string($param)) {
                $types .= 's';
            } else {
                $types .= 's'; // Default to string
            }
        }
        
        return $types;
    }
    
    /**
     * Obtener último ID insertado
     */
    public function getLastInsertId() {
        return $this->getConnection()->insert_id;
    }
    
    /**
     * Obtener número de filas afectadas
     */
    public function getAffectedRows() {
        return $this->getConnection()->affected_rows;
    }
    
    /**
     * Escapar string para consultas
     */
    public function escape($string) {
        return $this->getConnection()->real_escape_string($string);
    }
    
    /**
     * Iniciar transacción
     */
    public function beginTransaction() {
        return $this->getConnection()->begin_transaction();
    }
    
    /**
     * Confirmar transacción
     */
    public function commit() {
        return $this->getConnection()->commit();
    }
    
    /**
     * Revertir transacción
     */
    public function rollback() {
        return $this->getConnection()->rollback();
    }
    
    /**
     * Verificar si la conexión está activa
     */
    public function isConnected() {
        return $this->connection && $this->connection->ping();
    }
    
    /**
     * Obtener información de la conexión
     */
    public function getConnectionInfo() {
        if (!$this->isConnected()) {
            return null;
        }
        
        return [
            'host' => DB_HOST,
            'database' => DB_NAME,
            'user' => DB_USER,
            'charset' => DB_CHARSET,
            'server_version' => $this->connection->server_version,
            'protocol_version' => $this->connection->protocol_version,
            'thread_id' => $this->connection->thread_id,
            'stat' => $this->connection->stat()
        ];
    }
    
    /**
     * Obtener estadísticas de la base de datos
     */
    public function getStats() {
        try {
            $stats = [];
            
            // Usuarios
            $result = $this->query("SELECT COUNT(*) as total FROM users WHERE status = 'active'");
            $stats['active_users'] = $result ? $result->fetch_assoc()['total'] : 0;
            
            $result = $this->query("SELECT COUNT(*) as total FROM users WHERE premium_status = 'premium'");
            $stats['premium_users'] = $result ? $result->fetch_assoc()['total'] : 0;
            
            // Conversaciones hoy
            $result = $this->query("SELECT COUNT(*) as total FROM conversations WHERE DATE(created_at) = CURDATE()");
            $stats['conversations_today'] = $result ? $result->fetch_assoc()['total'] : 0;
            
            // Detecciones de IA hoy
            $result = $this->query("SELECT COUNT(*) as total FROM ai_detections WHERE DATE(created_at) = CURDATE()");
            $stats['ai_detections_today'] = $result ? $result->fetch_assoc()['total'] : 0;
            
            // Amenazas hoy
            $result = $this->query("SELECT COUNT(*) as total FROM security_events WHERE DATE(created_at) = CURDATE() AND severity IN ('high', 'critical')");
            $stats['threats_today'] = $result ? $result->fetch_assoc()['total'] : 0;
            
            // Consciencia promedio
            $result = $this->query("SELECT AVG(consciousness_level) as avg FROM conversation_logs WHERE consciousness_level IS NOT NULL AND DATE(timestamp) = CURDATE()");
            $row = $result ? $result->fetch_assoc() : null;
            $stats['avg_consciousness'] = $row && $row['avg'] ? round($row['avg'], 1) : 98.7;
            
            return $stats;
            
        } catch (Exception $e) {
            $this->logEvent('ERROR', 'Error getting database stats', ['error' => $e->getMessage()]);
            
            return [
                'active_users' => 0,
                'premium_users' => 0,
                'conversations_today' => 0,
                'ai_detections_today' => 0,
                'threats_today' => 0,
                'avg_consciousness' => 98.7
            ];
        }
    }
    
    /**
     * Limpiar datos antiguos
     */
    public function cleanup() {
        try {
            // Limpiar sesiones expiradas
            $this->query("DELETE FROM user_sessions WHERE expires_at < NOW()");
            
            // Limpiar rate limits antiguos
            $this->query("DELETE FROM rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 DAY)");
            
            // Limpiar logs antiguos (más de 90 días)
            $this->query("DELETE FROM conversation_logs WHERE timestamp < DATE_SUB(NOW(), INTERVAL 90 DAY)");
            
            $this->logEvent('INFO', 'Database cleanup completed successfully');
            
        } catch (Exception $e) {
            $this->logEvent('ERROR', 'Database cleanup failed', ['error' => $e->getMessage()]);
        }
    }
    
    /**
     * Registrar evento en logs
     */
    private function logEvent($level, $message, $context = []) {
        $logFile = __DIR__ . '/../logs/' . strtolower($level) . '.log';
        $timestamp = date('Y-m-d H:i:s');
        $contextStr = !empty($context) ? ' | Context: ' . json_encode($context) : '';
        $logEntry = "[$timestamp] [$level] $message$contextStr" . PHP_EOL;
        
        @file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Cerrar conexión
     */
    public function close() {
        if ($this->connection) {
            $this->connection->close();
            $this->connection = null;
        }
    }
    
    /**
     * Destructor
     */
    public function __destruct() {
        $this->close();
    }
}

/**
 * Funciones de utilidad para base de datos
 */

/**
 * Obtener conexión a base de datos
 */
function getDB() {
    return DatabaseConnection::getInstance();
}

/**
 * Ejecutar consulta rápida
 */
function dbQuery($sql, $params = []) {
    return getDB()->query($sql, $params);
}

/**
 * Obtener estadísticas del sistema
 */
function getSystemStats() {
    return getDB()->getStats();
}

/**
 * Verificar conexión a base de datos
 */
function testDatabaseConnection() {
    try {
        $db = getDB();
        $info = $db->getConnectionInfo();
        
        return [
            'success' => true,
            'message' => 'Conexión exitosa',
            'timestamp' => date('Y-m-d H:i:s'),
            'data' => $info
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error de conexión: ' . $e->getMessage(),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
}

/**
 * Autenticar usuario
 */
function authenticateUser($username, $password) {
    try {
        $db = getDB();
        $result = $db->query(
            "SELECT id, username, password, user_type, premium_status, status FROM users WHERE username = ? AND status = 'active'",
            [$username]
        );
        
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            if (password_verify($password, $user['password'])) {
                // Actualizar último login
                $db->query("UPDATE users SET last_login = NOW(), login_attempts = 0 WHERE id = ?", [$user['id']]);
                
                return [
                    'success' => true,
                    'user' => $user
                ];
            }
        }
        
        return [
            'success' => false,
            'message' => 'Credenciales incorrectas'
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error del sistema: ' . $e->getMessage()
        ];
    }
}

// Inicializar conexión automáticamente
try {
    $db = getDB();
    
    // Cleanup automático ocasional
    if (rand(1, 100) === 1) {
        $db->cleanup();
    }
    
} catch (Exception $e) {
    error_log("Database initialization failed: " . $e->getMessage());
}
?>

