<?php
session_start();
require_once 'config.php';
require_once 'auth.php';

// Limpiar sesión
session_destroy();

// Redirigir al index
header('Location: index.php?message=logout_success');
exit;
?>

