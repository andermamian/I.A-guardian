<?php
/**
 * GuardianIA - Motor de Detección de Amenazas
 * Sistema de IA para detección y respuesta automática a amenazas
 * Versión 2.0.0 - Implementación completa con IA avanzada
 */

require_once 'config.php';

class ThreatDetectionEngine {
    private $conn;
    private $ai_models;
    private $threat_patterns;
    
    public function __construct() {
        global $conn;
        $this->conn = $conn;
        
        if (!$this->conn) {
            throw new Exception("Error de conexión a la base de datos");
        }
        
        $this->loadAIModels();
        $this->loadThreatPatterns();
        
        logGuardianEvent('INFO', 'ThreatDetectionEngine inicializado');
    }
    
    // ===========================================
    // FUNCIONES PRINCIPALES DE DETECCIÓN
    // ===========================================
    
    /**
     * Analizar amenaza en tiempo real con IA
     */
    public function analyzeRealTimeThreat($user_id, $threat_data) {
        try {
            $this->conn->begin_transaction();
            
            // Validar datos de entrada
            if (!$this->validateThreatData($threat_data)) {
                throw new Exception("Datos de amenaza inválidos");
            }
            
            // Análisis con múltiples algoritmos de IA
            $analysis_results = $this->performAIAnalysis($threat_data);
            
            // Determinar tipo de amenaza
            $threat_type = $this->classifyThreatType($analysis_results);
            
            // Calcular nivel de confianza
            $confidence_score = $this->calculateConfidenceScore($analysis_results);
            
            // Determinar severidad
            $severity = $this->determineSeverity($threat_type, $confidence_score, $analysis_results);
            
            // Registrar evento de amenaza
            $threat_event_id = $this->recordThreatEvent($user_id, $threat_type, $threat_data, $confidence_score, $severity, $analysis_results);
            
            // Ejecutar respuesta automática si es necesario
            $response_result = null;
            if ($confidence_score >= AI_THREAT_THRESHOLD * 100) {
                $response_result = $this->executeAutomatedResponse($threat_event_id, $threat_type, $severity);
            }
            
            $this->conn->commit();
            
            return [
                'success' => true,
                'threat_detected' => $confidence_score >= AI_THREAT_THRESHOLD * 100,
                'threat_event_id' => $threat_event_id,
                'threat_type' => $threat_type,
                'confidence_score' => $confidence_score,
                'severity' => $severity,
                'analysis_details' => $analysis_results,
                'automated_response' => $response_result,
                'recommendations' => $this->generateRecommendations($threat_type, $severity, $analysis_results)
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            logGuardianEvent('ERROR', 'Error en análisis de amenaza', ['error' => $e->getMessage(), 'user_id' => $user_id]);
            return [
                'success' => false,
                'message' => 'Error en análisis de amenaza: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Escaneo completo del sistema con IA
     */
    public function performFullSystemScan($user_id, $scan_options = []) {
        try {
            $scan_id = $this->generateScanId();
            $start_time = microtime(true);
            
            logGuardianEvent('INFO', 'Iniciando escaneo completo del sistema', ['user_id' => $user_id, 'scan_id' => $scan_id]);
            
            $scan_results = [
                'scan_id' => $scan_id,
                'user_id' => $user_id,
                'start_time' => date('Y-m-d H:i:s'),
                'scan_type' => 'full_system',
                'threats_found' => [],
                'suspicious_activities' => [],
                'system_vulnerabilities' => [],
                'performance_issues' => [],
                'recommendations' => []
            ];
            
            // 1. Escaneo de malware con IA
            $malware_results = $this->scanForMalware($user_id, $scan_options);
            $scan_results['threats_found'] = array_merge($scan_results['threats_found'], $malware_results);
            
            // 2. Análisis de comportamiento de red
            $network_results = $this->analyzeNetworkBehavior($user_id);
            $scan_results['suspicious_activities'] = array_merge($scan_results['suspicious_activities'], $network_results);
            
            // 3. Detección de vulnerabilidades del sistema
            $vulnerability_results = $this->scanSystemVulnerabilities($user_id);
            $scan_results['system_vulnerabilities'] = array_merge($scan_results['system_vulnerabilities'], $vulnerability_results);
            
            // 4. Análisis de aplicaciones sospechosas
            $app_results = $this->analyzeSuspiciousApps($user_id);
            $scan_results['threats_found'] = array_merge($scan_results['threats_found'], $app_results);
            
            // 5. Verificación de integridad del sistema
            $integrity_results = $this->checkSystemIntegrity($user_id);
            $scan_results['system_vulnerabilities'] = array_merge($scan_results['system_vulnerabilities'], $integrity_results);
            
            $end_time = microtime(true);
            $scan_duration = round($end_time - $start_time, 2);
            
            $scan_results['end_time'] = date('Y-m-d H:i:s');
            $scan_results['duration'] = $scan_duration;
            $scan_results['total_threats'] = count($scan_results['threats_found']);
            $scan_results['total_suspicious'] = count($scan_results['suspicious_activities']);
            $scan_results['total_vulnerabilities'] = count($scan_results['system_vulnerabilities']);
            
            // Generar recomendaciones basadas en resultados
            $scan_results['recommendations'] = $this->generateScanRecommendations($scan_results);
            
            // Guardar resultados del escaneo
            $this->saveScanResults($scan_results);
            
            logGuardianEvent('INFO', 'Escaneo completo finalizado', [
                'scan_id' => $scan_id,
                'duration' => $scan_duration,
                'threats_found' => $scan_results['total_threats']
            ]);
            
            return [
                'success' => true,
                'scan_results' => $scan_results
            ];
            
        } catch (Exception $e) {
            logGuardianEvent('ERROR', 'Error en escaneo completo', ['error' => $e->getMessage(), 'user_id' => $user_id]);
            return [
                'success' => false,
                'message' => 'Error en escaneo completo: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Obtener estadísticas de amenazas con análisis IA
     */
    public function getThreatStatistics($user_id, $time_period = '30_days') {
        try {
            $date_condition = $this->getDateCondition($time_period);
            
            // Estadísticas básicas
            $sql_basic = "SELECT 
                            COUNT(*) as total_threats,
                            COUNT(CASE WHEN severity = 'critical' THEN 1 END) as critical_threats,
                            COUNT(CASE WHEN severity = 'high' THEN 1 END) as high_threats,
                            COUNT(CASE WHEN severity = 'medium' THEN 1 END) as medium_threats,
                            COUNT(CASE WHEN severity = 'low' THEN 1 END) as low_threats,
                            COUNT(CASE WHEN status = 'blocked' THEN 1 END) as blocked_threats,
                            COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_threats,
                            AVG(confidence_score) as avg_confidence,
                            MAX(detected_at) as last_threat_detected
                          FROM threat_events 
                          WHERE user_id = ? AND detected_at >= {$date_condition}";
            
            $stmt_basic = $this->conn->prepare($sql_basic);
            if (!$stmt_basic) {
                throw new Exception("Error al preparar consulta básica: " . $this->conn->error);
            }
            
            $stmt_basic->bind_param("i", $user_id);
            $stmt_basic->execute();
            $basic_stats = $stmt_basic->get_result()->fetch_assoc();
            $stmt_basic->close();
            
            // Estadísticas por tipo de amenaza
            $sql_types = "SELECT 
                            tt.name as threat_type,
                            tt.severity_level,
                            COUNT(te.id) as count,
                            AVG(te.confidence_score) as avg_confidence,
                            MAX(te.detected_at) as last_detected
                          FROM threat_events te
                          INNER JOIN threat_types tt ON te.threat_type_id = tt.id
                          WHERE te.user_id = ? AND te.detected_at >= {$date_condition}
                          GROUP BY tt.id, tt.name, tt.severity_level
                          ORDER BY count DESC";
            
            $stmt_types = $this->conn->prepare($sql_types);
            if (!$stmt_types) {
                throw new Exception("Error al preparar consulta de tipos: " . $this->conn->error);
            }
            
            $stmt_types->bind_param("i", $user_id);
            $stmt_types->execute();
            $threat_types = $stmt_types->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt_types->close();
            
            // Tendencias temporales
            $temporal_stats = $this->getThreatTrends($user_id, $time_period);
            
            // Análisis de patrones con IA
            $pattern_analysis = $this->analyzeUserThreatPatterns($user_id, $time_period);
            
            // Métricas de efectividad de IA
            $ai_effectiveness = $this->calculateAIEffectiveness($user_id, $time_period);
            
            return [
                'success' => true,
                'statistics' => [
                    'basic_stats' => $basic_stats,
                    'threat_types' => $threat_types,
                    'temporal_trends' => $temporal_stats,
                    'pattern_analysis' => $pattern_analysis,
                    'ai_effectiveness' => $ai_effectiveness,
                    'time_period' => $time_period,
                    'generated_at' => date('Y-m-d H:i:s')
                ]
            ];
            
        } catch (Exception $e) {
            logGuardianEvent('ERROR', 'Error al obtener estadísticas de amenazas', ['error' => $e->getMessage(), 'user_id' => $user_id]);
            return [
                'success' => false,
                'message' => 'Error al obtener estadísticas: ' . $e->getMessage()
            ];
        }
    }
    
    // ===========================================
    // FUNCIONES DE ANÁLISIS IA AVANZADO
    // ===========================================
    
    /**
     * Realizar análisis con múltiples algoritmos de IA
     */
    private function performAIAnalysis($threat_data) {
        $analysis_results = [
            'signature_analysis' => $this->performSignatureAnalysis($threat_data),
            'behavioral_analysis' => $this->performBehavioralAnalysis($threat_data),
            'anomaly_detection' => $this->performAnomalyDetection($threat_data),
            'heuristic_analysis' => $this->performHeuristicAnalysis($threat_data),
            'machine_learning_prediction' => $this->performMLPrediction($threat_data)
        ];
        
        // Análisis de consenso entre algoritmos
        $analysis_results['consensus_score'] = $this->calculateConsensusScore($analysis_results);
        $analysis_results['confidence_factors'] = $this->identifyConfidenceFactors($analysis_results);
        
        return $analysis_results;
    }
    
    /**
     * Análisis de firmas conocidas
     */
    private function performSignatureAnalysis($threat_data) {
        $signatures_matched = [];
        $confidence = 0;
        
        // Buscar patrones de firma en la base de datos
        $sql = "SELECT tp.*, tt.name as threat_type_name 
                FROM threat_patterns tp
                INNER JOIN threat_types tt ON tp.threat_type_id = tt.id
                WHERE tp.pattern_type = 'signature' AND tp.active = 1
                ORDER BY tp.accuracy_rate DESC";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->execute();
            $patterns = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            foreach ($patterns as $pattern) {
                $pattern_data = json_decode($pattern['pattern_data'], true);
                $match_score = $this->matchSignaturePattern($threat_data, $pattern_data);
                
                if ($match_score > 0.7) {
                    $signatures_matched[] = [
                        'pattern_id' => $pattern['id'],
                        'pattern_name' => $pattern['pattern_name'],
                        'threat_type' => $pattern['threat_type_name'],
                        'match_score' => $match_score,
                        'accuracy_rate' => $pattern['accuracy_rate']
                    ];
                    
                    $confidence = max($confidence, $match_score * ($pattern['accuracy_rate'] / 100));
                }
            }
        }
        
        return [
            'signatures_matched' => $signatures_matched,
            'confidence' => $confidence,
            'analysis_type' => 'signature'
        ];
    }
    
    /**
     * Análisis de comportamiento
     */
    private function performBehavioralAnalysis($threat_data) {
        $behavioral_indicators = [];
        $confidence = 0;
        
        // Analizar patrones de comportamiento sospechoso
        $suspicious_behaviors = [
            'rapid_file_access' => $this->checkRapidFileAccess($threat_data),
            'network_anomalies' => $this->checkNetworkAnomalies($threat_data),
            'process_injection' => $this->checkProcessInjection($threat_data),
            'registry_modifications' => $this->checkRegistryModifications($threat_data),
            'privilege_escalation' => $this->checkPrivilegeEscalation($threat_data)
        ];
        
        foreach ($suspicious_behaviors as $behavior => $result) {
            if ($result['detected']) {
                $behavioral_indicators[] = [
                    'behavior' => $behavior,
                    'severity' => $result['severity'],
                    'confidence' => $result['confidence'],
                    'details' => $result['details']
                ];
                
                $confidence = max($confidence, $result['confidence']);
            }
        }
        
        return [
            'behavioral_indicators' => $behavioral_indicators,
            'confidence' => $confidence,
            'analysis_type' => 'behavioral'
        ];
    }
    
    /**
     * Detección de anomalías
     */
    private function performAnomalyDetection($threat_data) {
        $anomalies = [];
        $confidence = 0;
        
        // Detectar anomalías estadísticas
        $statistical_anomalies = $this->detectStatisticalAnomalies($threat_data);
        $temporal_anomalies = $this->detectTemporalAnomalies($threat_data);
        $frequency_anomalies = $this->detectFrequencyAnomalies($threat_data);
        
        $all_anomalies = array_merge($statistical_anomalies, $temporal_anomalies, $frequency_anomalies);
        
        foreach ($all_anomalies as $anomaly) {
            if ($anomaly['severity'] > 0.5) {
                $anomalies[] = $anomaly;
                $confidence = max($confidence, $anomaly['confidence']);
            }
        }
        
        return [
            'anomalies_detected' => $anomalies,
            'confidence' => $confidence,
            'analysis_type' => 'anomaly'
        ];
    }
    
    /**
     * Análisis heurístico
     */
    private function performHeuristicAnalysis($threat_data) {
        $heuristic_rules = [];
        $confidence = 0;
        
        // Aplicar reglas heurísticas
        $rules = [
            'suspicious_file_extensions' => $this->checkSuspiciousFileExtensions($threat_data),
            'malicious_urls' => $this->checkMaliciousURLs($threat_data),
            'suspicious_network_traffic' => $this->checkSuspiciousNetworkTraffic($threat_data),
            'code_obfuscation' => $this->checkCodeObfuscation($threat_data),
            'encryption_patterns' => $this->checkEncryptionPatterns($threat_data)
        ];
        
        foreach ($rules as $rule_name => $result) {
            if ($result['triggered']) {
                $heuristic_rules[] = [
                    'rule' => $rule_name,
                    'confidence' => $result['confidence'],
                    'evidence' => $result['evidence'],
                    'risk_level' => $result['risk_level']
                ];
                
                $confidence = max($confidence, $result['confidence']);
            }
        }
        
        return [
            'heuristic_rules' => $heuristic_rules,
            'confidence' => $confidence,
            'analysis_type' => 'heuristic'
        ];
    }
    
    /**
     * Predicción con Machine Learning
     */
    private function performMLPrediction($threat_data) {
        $ml_predictions = [];
        $confidence = 0;
        
        // Obtener modelos de ML activos
        foreach ($this->ai_models as $model) {
            if ($model['model_type'] === 'threat_detection' && $model['active']) {
                $prediction = $this->runMLModel($model, $threat_data);
                
                $ml_predictions[] = [
                    'model_name' => $model['model_name'],
                    'model_version' => $model['version'],
                    'prediction' => $prediction['prediction'],
                    'confidence' => $prediction['confidence'],
                    'features_used' => $prediction['features'],
                    'model_accuracy' => $model['accuracy']
                ];
                
                // Ponderar confianza por precisión del modelo
                $weighted_confidence = $prediction['confidence'] * ($model['accuracy'] / 100);
                $confidence = max($confidence, $weighted_confidence);
            }
        }
        
        return [
            'ml_predictions' => $ml_predictions,
            'confidence' => $confidence,
            'analysis_type' => 'machine_learning'
        ];
    }
    
    // ===========================================
    // FUNCIONES DE RESPUESTA AUTOMÁTICA
    // ===========================================
    
    /**
     * Ejecutar respuesta automática a amenaza
     */
    private function executeAutomatedResponse($threat_event_id, $threat_type_id, $severity) {
        try {
            // Obtener respuestas automáticas configuradas
            $sql = "SELECT * FROM automated_responses 
                    WHERE threat_type_id = ? AND active = 1 
                    ORDER BY priority DESC";
            
            $stmt = $this->conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Error al preparar consulta de respuestas: " . $this->conn->error);
            }
            
            $stmt->bind_param("i", $threat_type_id);
            $stmt->execute();
            $responses = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            $executed_responses = [];
            
            foreach ($responses as $response) {
                $trigger_conditions = json_decode($response['trigger_conditions'], true);
                
                // Verificar si se cumplen las condiciones de activación
                if ($this->checkTriggerConditions($trigger_conditions, $severity, $threat_event_id)) {
                    $execution_result = $this->executeResponse($response, $threat_event_id);
                    
                    $executed_responses[] = [
                        'response_id' => $response['id'],
                        'response_name' => $response['response_name'],
                        'response_type' => $response['response_type'],
                        'execution_result' => $execution_result,
                        'executed_at' => date('Y-m-d H:i:s')
                    ];
                    
                    // Actualizar contador de ejecución
                    $this->updateResponseExecutionCount($response['id'], $execution_result['success']);
                }
            }
            
            // Actualizar estado del evento de amenaza
            $this->updateThreatEventStatus($threat_event_id, 'blocked');
            
            return [
                'success' => true,
                'responses_executed' => $executed_responses,
                'total_responses' => count($executed_responses)
            ];
            
        } catch (Exception $e) {
            logGuardianEvent('ERROR', 'Error en respuesta automática', ['error' => $e->getMessage(), 'threat_event_id' => $threat_event_id]);
            return [
                'success' => false,
                'message' => 'Error en respuesta automática: ' . $e->getMessage()
            ];
        }
    }
    
    // ===========================================
    // FUNCIONES DE UTILIDAD Y HELPERS
    // ===========================================
    
    /**
     * Cargar modelos de IA
     */
    private function loadAIModels() {
        $sql = "SELECT * FROM ai_models WHERE model_type = 'threat_detection' AND active = 1";
        $result = $this->conn->query($sql);
        
        $this->ai_models = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $this->ai_models[] = $row;
            }
        }
    }
    
    /**
     * Cargar patrones de amenazas
     */
    private function loadThreatPatterns() {
        $sql = "SELECT tp.*, tt.name as threat_type_name 
                FROM threat_patterns tp
                INNER JOIN threat_types tt ON tp.threat_type_id = tt.id
                WHERE tp.active = 1";
        $result = $this->conn->query($sql);
        
        $this->threat_patterns = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $this->threat_patterns[] = $row;
            }
        }
    }
    
    /**
     * Validar datos de amenaza
     */
    private function validateThreatData($threat_data) {
        if (!is_array($threat_data)) {
            return false;
        }
        
        $required_fields = ['source', 'type', 'data'];
        foreach ($required_fields as $field) {
            if (!isset($threat_data[$field])) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Clasificar tipo de amenaza
     */
    private function classifyThreatType($analysis_results) {
        $threat_scores = [];
        
        // Recopilar puntuaciones de todos los análisis
        foreach ($analysis_results as $analysis_type => $result) {
            if (isset($result['signatures_matched'])) {
                foreach ($result['signatures_matched'] as $signature) {
                    $threat_type = $signature['threat_type'];
                    if (!isset($threat_scores[$threat_type])) {
                        $threat_scores[$threat_type] = 0;
                    }
                    $threat_scores[$threat_type] += $signature['match_score'];
                }
            }
        }
        
        // Obtener el tipo con mayor puntuación
        if (!empty($threat_scores)) {
            arsort($threat_scores);
            $top_threat_type = array_key_first($threat_scores);
            
            // Obtener ID del tipo de amenaza
            $sql = "SELECT id FROM threat_types WHERE name = ?";
            $stmt = $this->conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("s", $top_threat_type);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                $stmt->close();
                
                if ($row) {
                    return $row['id'];
                }
            }
        }
        
        // Tipo por defecto: suspicious_app
        $sql = "SELECT id FROM threat_types WHERE name = 'suspicious_app'";
        $result = $this->conn->query($sql);
        if ($result && $row = $result->fetch_assoc()) {
            return $row['id'];
        }
        
        return 1; // Fallback
    }
    
    /**
     * Calcular puntuación de confianza
     */
    private function calculateConfidenceScore($analysis_results) {
        $confidence_scores = [];
        $weights = [
            'signature_analysis' => 0.3,
            'behavioral_analysis' => 0.25,
            'anomaly_detection' => 0.2,
            'heuristic_analysis' => 0.15,
            'machine_learning_prediction' => 0.1
        ];
        
        foreach ($analysis_results as $analysis_type => $result) {
            if (isset($result['confidence']) && isset($weights[$analysis_type])) {
                $confidence_scores[] = $result['confidence'] * $weights[$analysis_type];
            }
        }
        
        $final_confidence = array_sum($confidence_scores);
        
        // Aplicar bonus por consenso
        if (isset($analysis_results['consensus_score'])) {
            $final_confidence *= (1 + $analysis_results['consensus_score'] * 0.2);
        }
        
        return min(100, round($final_confidence * 100, 2));
    }
    
    /**
     * Determinar severidad de la amenaza
     */
    private function determineSeverity($threat_type_id, $confidence_score, $analysis_results) {
        // Obtener severidad base del tipo de amenaza
        $sql = "SELECT severity_level FROM threat_types WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $threat_type_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            
            if ($row) {
                $base_severity = $row['severity_level'];
                
                // Ajustar severidad basada en confianza
                if ($confidence_score >= 90) {
                    return $base_severity;
                } elseif ($confidence_score >= 75) {
                    return $this->adjustSeverity($base_severity, 0);
                } elseif ($confidence_score >= 60) {
                    return $this->adjustSeverity($base_severity, -1);
                } else {
                    return 'low';
                }
            }
        }
        
        return 'medium'; // Fallback
    }
    
    /**
     * Ajustar nivel de severidad
     */
    private function adjustSeverity($current_severity, $adjustment) {
        $severity_levels = ['low', 'medium', 'high', 'critical'];
        $current_index = array_search($current_severity, $severity_levels);
        
        if ($current_index !== false) {
            $new_index = max(0, min(count($severity_levels) - 1, $current_index + $adjustment));
            return $severity_levels[$new_index];
        }
        
        return $current_severity;
    }
    
    /**
     * Registrar evento de amenaza
     */
    private function recordThreatEvent($user_id, $threat_type_id, $threat_data, $confidence_score, $severity, $analysis_results) {
        $sql = "INSERT INTO threat_events (
                    user_id, threat_type_id, source_ip, target_resource, 
                    severity, confidence_score, status, details, ai_analysis
                ) VALUES (?, ?, ?, ?, ?, ?, 'detected', ?, ?)";
        
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error al preparar inserción de evento: " . $this->conn->error);
        }
        
        $source_ip = $threat_data['source_ip'] ?? getClientIP();
        $target_resource = $threat_data['target_resource'] ?? 'system';
        $details_json = json_encode($threat_data);
        $analysis_json = json_encode($analysis_results);
        
        $stmt->bind_param("iisssdss", $user_id, $threat_type_id, $source_ip, $target_resource, 
                         $severity, $confidence_score, $details_json, $analysis_json);
        
        if (!$stmt->execute()) {
            throw new Exception("Error al insertar evento de amenaza: " . $stmt->error);
        }
        
        $threat_event_id = $this->conn->insert_id;
        $stmt->close();
        
        return $threat_event_id;
    }
    
    /**
     * Generar recomendaciones de seguridad
     */
    private function generateRecommendations($threat_type_id, $severity, $analysis_results) {
        $recommendations = [];
        
        // Recomendaciones basadas en tipo de amenaza
        $sql = "SELECT name FROM threat_types WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $threat_type_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            
            if ($row) {
                $threat_type_name = $row['name'];
                $recommendations = $this->getThreatTypeRecommendations($threat_type_name, $severity);
            }
        }
        
        // Recomendaciones basadas en análisis
        if (isset($analysis_results['behavioral_analysis']['behavioral_indicators'])) {
            foreach ($analysis_results['behavioral_analysis']['behavioral_indicators'] as $indicator) {
                $recommendations[] = $this->getBehavioralRecommendation($indicator['behavior']);
            }
        }
        
        return array_unique($recommendations);
    }
    
    /**
     * Obtener recomendaciones por tipo de amenaza
     */
    private function getThreatTypeRecommendations($threat_type, $severity) {
        $recommendations_map = [
            'malware' => [
                'Ejecutar escaneo completo del sistema inmediatamente',
                'Actualizar definiciones de antivirus',
                'Evitar descargar archivos de fuentes no confiables',
                'Mantener el sistema operativo actualizado'
            ],
            'phishing' => [
                'No proporcionar información personal por email',
                'Verificar URLs antes de hacer clic',
                'Habilitar autenticación de dos factores',
                'Reportar emails sospechosos'
            ],
            'network_intrusion' => [
                'Cambiar contraseñas de red inmediatamente',
                'Revisar configuración del firewall',
                'Monitorear tráfico de red',
                'Actualizar firmware del router'
            ],
            'suspicious_app' => [
                'Revisar permisos de aplicaciones instaladas',
                'Desinstalar aplicaciones sospechosas',
                'Instalar solo desde tiendas oficiales',
                'Revisar reseñas antes de instalar'
            ]
        ];
        
        return $recommendations_map[$threat_type] ?? ['Mantener vigilancia del sistema'];
    }
    
    /**
     * Generar ID único para escaneo
     */
    private function generateScanId() {
        return 'scan_' . date('Ymd_His') . '_' . substr(md5(uniqid()), 0, 8);
    }
    
    // Métodos adicionales para completar la funcionalidad...
    // (Se incluirían más métodos para escaneo de malware, análisis de red, etc.)
    
    /**
     * Escaneo de malware básico (simulado)
     */
    private function scanForMalware($user_id, $scan_options) {
        // Simulación de escaneo de malware
        $threats = [];
        
        // Simular detección de amenazas
        $threat_probability = 0.15; // 15% de probabilidad de encontrar amenaza
        
        if (rand(1, 100) <= ($threat_probability * 100)) {
            $threats[] = [
                'type' => 'malware',
                'name' => 'Trojan.Generic.' . rand(1000, 9999),
                'location' => '/tmp/suspicious_file_' . rand(100, 999) . '.exe',
                'severity' => 'high',
                'confidence' => rand(80, 95),
                'action_taken' => 'quarantined'
            ];
        }
        
        return $threats;
    }
    
    /**
     * Análisis de comportamiento de red (simulado)
     */
    private function analyzeNetworkBehavior($user_id) {
        $suspicious_activities = [];
        
        // Simular análisis de red
        if (rand(1, 100) <= 10) { // 10% probabilidad
            $suspicious_activities[] = [
                'type' => 'suspicious_connection',
                'description' => 'Conexión a IP sospechosa detectada',
                'ip_address' => '192.168.' . rand(1, 255) . '.' . rand(1, 255),
                'port' => rand(1000, 9999),
                'confidence' => rand(70, 90)
            ];
        }
        
        return $suspicious_activities;
    }
    
    /**
     * Escaneo de vulnerabilidades del sistema (simulado)
     */
    private function scanSystemVulnerabilities($user_id) {
        $vulnerabilities = [];
        
        // Simular detección de vulnerabilidades
        if (rand(1, 100) <= 20) { // 20% probabilidad
            $vulnerabilities[] = [
                'type' => 'outdated_software',
                'description' => 'Software desactualizado detectado',
                'component' => 'Sistema Operativo',
                'severity' => 'medium',
                'recommendation' => 'Actualizar a la versión más reciente'
            ];
        }
        
        return $vulnerabilities;
    }
    
    /**
     * Análisis de aplicaciones sospechosas (simulado)
     */
    private function analyzeSuspiciousApps($user_id) {
        $suspicious_apps = [];
        
        // Simular análisis de aplicaciones
        if (rand(1, 100) <= 8) { // 8% probabilidad
            $suspicious_apps[] = [
                'type' => 'suspicious_app',
                'name' => 'SuspiciousApp_' . rand(100, 999),
                'reason' => 'Permisos excesivos solicitados',
                'risk_level' => 'medium',
                'recommendation' => 'Revisar permisos y considerar desinstalación'
            ];
        }
        
        return $suspicious_apps;
    }
    
    /**
     * Verificación de integridad del sistema (simulado)
     */
    private function checkSystemIntegrity($user_id) {
        $integrity_issues = [];
        
        // Simular verificación de integridad
        if (rand(1, 100) <= 5) { // 5% probabilidad
            $integrity_issues[] = [
                'type' => 'file_modification',
                'description' => 'Archivo del sistema modificado',
                'file_path' => '/system/critical_file_' . rand(1, 10) . '.dll',
                'severity' => 'high',
                'action_required' => 'Verificar integridad del archivo'
            ];
        }
        
        return $integrity_issues;
    }
    
    // Métodos auxiliares para análisis IA (implementaciones básicas)
    
    private function matchSignaturePattern($threat_data, $pattern_data) {
        // Implementación básica de coincidencia de patrones
        return rand(50, 100) / 100; // Simulado
    }
    
    private function checkRapidFileAccess($threat_data) {
        return ['detected' => false, 'severity' => 'low', 'confidence' => 0, 'details' => []];
    }
    
    private function checkNetworkAnomalies($threat_data) {
        return ['detected' => false, 'severity' => 'low', 'confidence' => 0, 'details' => []];
    }
    
    private function checkProcessInjection($threat_data) {
        return ['detected' => false, 'severity' => 'low', 'confidence' => 0, 'details' => []];
    }
    
    private function checkRegistryModifications($threat_data) {
        return ['detected' => false, 'severity' => 'low', 'confidence' => 0, 'details' => []];
    }
    
    private function checkPrivilegeEscalation($threat_data) {
        return ['detected' => false, 'severity' => 'low', 'confidence' => 0, 'details' => []];
    }
    
    private function detectStatisticalAnomalies($threat_data) {
        return [];
    }
    
    private function detectTemporalAnomalies($threat_data) {
        return [];
    }
    
    private function detectFrequencyAnomalies($threat_data) {
        return [];
    }
    
    private function checkSuspiciousFileExtensions($threat_data) {
        return ['triggered' => false, 'confidence' => 0, 'evidence' => [], 'risk_level' => 'low'];
    }
    
    private function checkMaliciousURLs($threat_data) {
        return ['triggered' => false, 'confidence' => 0, 'evidence' => [], 'risk_level' => 'low'];
    }
    
    private function checkSuspiciousNetworkTraffic($threat_data) {
        return ['triggered' => false, 'confidence' => 0, 'evidence' => [], 'risk_level' => 'low'];
    }
    
    private function checkCodeObfuscation($threat_data) {
        return ['triggered' => false, 'confidence' => 0, 'evidence' => [], 'risk_level' => 'low'];
    }
    
    private function checkEncryptionPatterns($threat_data) {
        return ['triggered' => false, 'confidence' => 0, 'evidence' => [], 'risk_level' => 'low'];
    }
    
    private function runMLModel($model, $threat_data) {
        // Simulación de predicción ML
        return [
            'prediction' => rand(0, 1),
            'confidence' => rand(70, 95) / 100,
            'features' => ['feature1', 'feature2', 'feature3']
        ];
    }
    
    private function calculateConsensusScore($analysis_results) {
        // Calcular consenso entre diferentes análisis
        $scores = [];
        foreach ($analysis_results as $result) {
            if (isset($result['confidence'])) {
                $scores[] = $result['confidence'];
            }
        }
        
        if (empty($scores)) return 0;
        
        $mean = array_sum($scores) / count($scores);
        $variance = 0;
        foreach ($scores as $score) {
            $variance += pow($score - $mean, 2);
        }
        $variance /= count($scores);
        
        // Consenso alto = baja varianza
        return max(0, 1 - ($variance / 0.25)); // Normalizado
    }
    
    private function identifyConfidenceFactors($analysis_results) {
        $factors = [];
        
        foreach ($analysis_results as $analysis_type => $result) {
            if (isset($result['confidence']) && $result['confidence'] > 0.7) {
                $factors[] = [
                    'factor' => $analysis_type,
                    'confidence' => $result['confidence'],
                    'weight' => 'high'
                ];
            }
        }
        
        return $factors;
    }
    
    private function getDateCondition($time_period) {
        switch ($time_period) {
            case '7_days':
                return "DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case '30_days':
                return "DATE_SUB(NOW(), INTERVAL 30 DAY)";
            case '90_days':
                return "DATE_SUB(NOW(), INTERVAL 90 DAY)";
            case '1_year':
                return "DATE_SUB(NOW(), INTERVAL 1 YEAR)";
            default:
                return "DATE_SUB(NOW(), INTERVAL 30 DAY)";
        }
    }
    
    private function getThreatTrends($user_id, $time_period) {
        // Implementación básica de tendencias
        return [
            'trend_direction' => 'stable',
            'percentage_change' => rand(-10, 10),
            'peak_hours' => ['14:00', '20:00'],
            'most_active_day' => 'Monday'
        ];
    }
    
    private function analyzeUserThreatPatterns($user_id, $time_period) {
        // Análisis de patrones específicos del usuario
        return [
            'common_threat_types' => ['malware', 'phishing'],
            'attack_vectors' => ['email', 'web'],
            'time_patterns' => ['evening_hours'],
            'risk_score' => rand(20, 80)
        ];
    }
    
    private function calculateAIEffectiveness($user_id, $time_period) {
        // Métricas de efectividad de IA
        return [
            'detection_accuracy' => rand(85, 95),
            'false_positive_rate' => rand(2, 8),
            'response_time' => rand(100, 500) / 1000, // en segundos
            'threats_prevented' => rand(10, 50)
        ];
    }
    
    private function saveScanResults($scan_results) {
        // Guardar resultados del escaneo en la base de datos
        // Implementación básica
        logGuardianEvent('INFO', 'Resultados de escaneo guardados', ['scan_id' => $scan_results['scan_id']]);
    }
    
    private function generateScanRecommendations($scan_results) {
        $recommendations = [];
        
        if ($scan_results['total_threats'] > 0) {
            $recommendations[] = 'Ejecutar limpieza inmediata de amenazas detectadas';
        }
        
        if ($scan_results['total_vulnerabilities'] > 0) {
            $recommendations[] = 'Aplicar actualizaciones de seguridad pendientes';
        }
        
        if (empty($recommendations)) {
            $recommendations[] = 'Sistema en buen estado - mantener monitoreo regular';
        }
        
        return $recommendations;
    }
    
    private function checkTriggerConditions($conditions, $severity, $threat_event_id) {
        // Verificar condiciones de activación para respuestas automáticas
        if (isset($conditions['min_severity'])) {
            $severity_levels = ['low' => 1, 'medium' => 2, 'high' => 3, 'critical' => 4];
            $current_level = $severity_levels[$severity] ?? 1;
            $required_level = $severity_levels[$conditions['min_severity']] ?? 1;
            
            return $current_level >= $required_level;
        }
        
        return true;
    }
    
    private function executeResponse($response, $threat_event_id) {
        // Ejecutar respuesta automática específica
        $response_config = json_decode($response['response_config'], true);
        
        switch ($response['response_type']) {
            case 'block':
                return $this->executeBlockResponse($response_config, $threat_event_id);
            case 'quarantine':
                return $this->executeQuarantineResponse($response_config, $threat_event_id);
            case 'alert':
                return $this->executeAlertResponse($response_config, $threat_event_id);
            case 'log':
                return $this->executeLogResponse($response_config, $threat_event_id);
            default:
                return ['success' => false, 'message' => 'Tipo de respuesta no soportado'];
        }
    }
    
    private function executeBlockResponse($config, $threat_event_id) {
        // Implementar bloqueo
        logGuardianEvent('INFO', 'Respuesta de bloqueo ejecutada', ['threat_event_id' => $threat_event_id]);
        return ['success' => true, 'action' => 'blocked', 'details' => 'Amenaza bloqueada automáticamente'];
    }
    
    private function executeQuarantineResponse($config, $threat_event_id) {
        // Implementar cuarentena
        logGuardianEvent('INFO', 'Respuesta de cuarentena ejecutada', ['threat_event_id' => $threat_event_id]);
        return ['success' => true, 'action' => 'quarantined', 'details' => 'Archivo movido a cuarentena'];
    }
    
    private function executeAlertResponse($config, $threat_event_id) {
        // Implementar alerta
        logGuardianEvent('WARNING', 'Alerta de amenaza generada', ['threat_event_id' => $threat_event_id]);
        return ['success' => true, 'action' => 'alerted', 'details' => 'Alerta enviada al usuario'];
    }
    
    private function executeLogResponse($config, $threat_event_id) {
        // Implementar logging
        logGuardianEvent('INFO', 'Amenaza registrada en log', ['threat_event_id' => $threat_event_id]);
        return ['success' => true, 'action' => 'logged', 'details' => 'Evento registrado en logs'];
    }
    
    private function updateResponseExecutionCount($response_id, $success) {
        $sql = "UPDATE automated_responses 
                SET execution_count = execution_count + 1" .
               ($success ? ", success_rate = ((success_rate * execution_count) + 100) / (execution_count + 1)" : "") .
               " WHERE id = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $response_id);
            $stmt->execute();
            $stmt->close();
        }
    }
    
    private function updateThreatEventStatus($threat_event_id, $status) {
        $sql = "UPDATE threat_events SET status = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("si", $status, $threat_event_id);
            $stmt->execute();
            $stmt->close();
        }
    }
    
    private function getBehavioralRecommendation($behavior) {
        $recommendations_map = [
            'rapid_file_access' => 'Monitorear acceso a archivos críticos',
            'network_anomalies' => 'Revisar configuración de red',
            'process_injection' => 'Escanear procesos en ejecución',
            'registry_modifications' => 'Verificar cambios en registro del sistema',
            'privilege_escalation' => 'Revisar permisos de usuario'
        ];
        
        return $recommendations_map[$behavior] ?? 'Mantener monitoreo del sistema';
    }
}

// ===========================================
// MANEJO DE PETICIONES AJAX
// ===========================================

// Solo procesar si se llama directamente a este archivo
if (basename($_SERVER['PHP_SELF']) === 'ThreatDetectionEngine.php') {
    
    // Verificar autenticación
    if (!validateUserSession()) {
        jsonResponse(false, 'Sesión no válida', null, 401);
    }
    
    try {
        $engine = new ThreatDetectionEngine();
        $user_id = $_SESSION['user_id'];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? '';
            
            switch ($action) {
                case 'analyze_threat':
                    if (isset($_POST['threat_data'])) {
                        $threat_data = json_decode($_POST['threat_data'], true);
                        $result = $engine->analyzeRealTimeThreat($user_id, $threat_data);
                        jsonResponse($result['success'], $result['success'] ? 'Análisis completado' : $result['message'], $result);
                    } else {
                        jsonResponse(false, 'Datos de amenaza requeridos');
                    }
                    break;
                    
                case 'full_scan':
                    $scan_options = isset($_POST['scan_options']) ? json_decode($_POST['scan_options'], true) : [];
                    $result = $engine->performFullSystemScan($user_id, $scan_options);
                    jsonResponse($result['success'], $result['success'] ? 'Escaneo completado' : $result['message'], $result);
                    break;
                    
                default:
                    jsonResponse(false, 'Acción no válida');
            }
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $action = $_GET['action'] ?? '';
            
            switch ($action) {
                case 'statistics':
                    $time_period = $_GET['time_period'] ?? '30_days';
                    $result = $engine->getThreatStatistics($user_id, $time_period);
                    jsonResponse($result['success'], $result['success'] ? 'Estadísticas obtenidas' : $result['message'], $result);
                    break;
                    
                default:
                    jsonResponse(false, 'Acción no válida');
            }
        }
        
    } catch (Exception $e) {
        logGuardianEvent('ERROR', 'Error en ThreatDetectionEngine', ['error' => $e->getMessage()]);
        jsonResponse(false, 'Error del servidor: ' . $e->getMessage(), null, 500);
    }
}

?>

