<?php
require_once 'config.php';
require_once 'GuardianAIChatbot.php';

// Inicializar chatbot
$chatbot = new GuardianAIChatbot($conn);

// Procesar solicitudes AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'send_message':
            $user_id = $_POST['user_id'] ?? 1;
            $message = $_POST['message'] ?? '';
            $conversation_id = $_POST['conversation_id'] ?? null;
            
            if (!empty($message)) {
                $response = $chatbot->processUserMessage($user_id, $message, $conversation_id);
                echo json_encode($response);
            } else {
                echo json_encode(['success' => false, 'error' => 'Mensaje vacío']);
            }
            exit;
            
        case 'get_conversations':
            $user_id = $_POST['user_id'] ?? 1;
            $conversations = $chatbot->getUserConversations($user_id);
            echo json_encode(['success' => true, 'conversations' => $conversations]);
            exit;
            
        case 'get_conversation_messages':
            $conversation_id = $_POST['conversation_id'] ?? 0;
            $messages = $chatbot->getConversationMessages($conversation_id);
            echo json_encode(['success' => true, 'messages' => $messages]);
            exit;
            
        case 'rate_conversation':
            $conversation_id = $_POST['conversation_id'] ?? 0;
            $rating = $_POST['rating'] ?? '';
            $feedback = $_POST['feedback'] ?? '';
            
            $result = $chatbot->rateConversation($conversation_id, $rating, $feedback);
            echo json_encode($result);
            exit;
            
        case 'new_conversation':
            $user_id = $_POST['user_id'] ?? 1;
            $title = $_POST['title'] ?? 'Nueva conversación';
            
            $conversation = $chatbot->createNewConversation($user_id, $title);
            echo json_encode($conversation);
            exit;
    }
}

// Obtener conversaciones del usuario
$user_id = 1; // En un sistema real, esto vendría de la sesión
$conversations = $chatbot->getUserConversations($user_id);
$chatbot_stats = $chatbot->getChatbotStatistics($user_id);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Asistente IA - GuardianIA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --warning-gradient: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(102, 126, 234, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(118, 75, 162, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(67, 233, 123, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        /* Navigation */
        .navbar {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .nav-link:hover {
            color: var(--text-primary);
            background: rgba(255, 255, 255, 0.1);
        }

        .nav-link.active {
            background: var(--primary-gradient);
            color: white;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        /* Main Container */
        .main-container {
            margin-top: 80px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 2rem;
            height: calc(100vh - 80px);
        }

        /* Sidebar */
        .sidebar {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            height: fit-content;
            max-height: calc(100vh - 120px);
            overflow-y: auto;
        }

        .sidebar-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .sidebar-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .new-chat-btn {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            width: 100%;
            margin-bottom: 1rem;
        }

        .new-chat-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .conversation-list {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .conversation-item {
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            border-left: 3px solid transparent;
        }

        .conversation-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .conversation-item.active {
            background: rgba(102, 126, 234, 0.1);
            border-left-color: var(--primary-gradient);
        }

        .conversation-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
            font-size: 0.9rem;
        }

        .conversation-preview {
            color: var(--text-secondary);
            font-size: 0.8rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .conversation-time {
            color: var(--text-secondary);
            font-size: 0.7rem;
            margin-top: 0.25rem;
        }

        /* Chat Area */
        .chat-area {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            display: flex;
            flex-direction: column;
            height: calc(100vh - 120px);
        }

        .chat-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-title {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .ai-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }

        .ai-info h3 {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .ai-status {
            color: var(--text-secondary);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #2ed573;
            animation: statusPulse 2s infinite;
        }

        @keyframes statusPulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .chat-actions {
            display: flex;
            gap: 0.5rem;
        }

        .action-btn {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
            border: none;
            padding: 0.5rem;
            border-radius: 6px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
        }

        .action-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: var(--text-primary);
        }

        /* Messages */
        .messages-container {
            flex: 1;
            padding: 1rem;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .message {
            display: flex;
            gap: 1rem;
            max-width: 80%;
            animation: messageSlide 0.3s ease;
        }

        @keyframes messageSlide {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .message.user {
            align-self: flex-end;
            flex-direction: row-reverse;
        }

        .message.bot {
            align-self: flex-start;
        }

        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            color: white;
            flex-shrink: 0;
        }

        .message.user .message-avatar {
            background: var(--info-gradient);
        }

        .message.bot .message-avatar {
            background: var(--primary-gradient);
        }

        .message-content {
            background: rgba(255, 255, 255, 0.05);
            padding: 1rem;
            border-radius: 12px;
            position: relative;
        }

        .message.user .message-content {
            background: var(--primary-gradient);
        }

        .message-text {
            margin-bottom: 0.5rem;
        }

        .message-time {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.8rem;
        }

        .message.bot .message-time {
            color: var(--text-secondary);
        }

        .typing-indicator {
            display: flex;
            align-items: center;
            gap: 1rem;
            max-width: 80%;
            align-self: flex-start;
        }

        .typing-dots {
            background: rgba(255, 255, 255, 0.05);
            padding: 1rem;
            border-radius: 12px;
            display: flex;
            gap: 0.25rem;
        }

        .typing-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--text-secondary);
            animation: typingDot 1.4s infinite;
        }

        .typing-dot:nth-child(2) {
            animation-delay: 0.2s;
        }

        .typing-dot:nth-child(3) {
            animation-delay: 0.4s;
        }

        @keyframes typingDot {
            0%, 60%, 100% { opacity: 0.3; }
            30% { opacity: 1; }
        }

        /* Input Area */
        .input-area {
            padding: 1.5rem;
            border-top: 1px solid var(--border-color);
        }

        .input-container {
            display: flex;
            gap: 1rem;
            align-items: flex-end;
        }

        .message-input {
            flex: 1;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1rem;
            color: var(--text-primary);
            font-family: inherit;
            resize: none;
            min-height: 50px;
            max-height: 120px;
            transition: all var(--animation-speed) ease;
        }

        .message-input:focus {
            outline: none;
            border-color: var(--primary-gradient);
            background: rgba(255, 255, 255, 0.1);
        }

        .message-input::placeholder {
            color: var(--text-secondary);
        }

        .send-btn {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 1rem;
            border-radius: 12px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 50px;
        }

        .send-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .send-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* Quick Actions */
        .quick-actions {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }

        .quick-action {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            font-size: 0.85rem;
        }

        .quick-action:hover {
            background: var(--primary-gradient);
            color: white;
        }

        /* Welcome Screen */
        .welcome-screen {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            text-align: center;
            padding: 2rem;
        }

        .welcome-icon {
            font-size: 4rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 1rem;
        }

        .welcome-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .welcome-description {
            color: var(--text-secondary);
            margin-bottom: 2rem;
            max-width: 500px;
        }

        .welcome-suggestions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            width: 100%;
            max-width: 600px;
        }

        .suggestion-card {
            background: rgba(255, 255, 255, 0.05);
            padding: 1.5rem;
            border-radius: 12px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            text-align: left;
        }

        .suggestion-card:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }

        .suggestion-icon {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            color: var(--primary-gradient);
        }

        .suggestion-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .suggestion-description {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .main-container {
                grid-template-columns: 1fr;
                padding: 1rem;
                height: calc(100vh - 80px);
            }

            .sidebar {
                display: none;
            }

            .chat-area {
                height: calc(100vh - 100px);
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            top: 100px;
            right: 2rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem 1.5rem;
            color: var(--text-primary);
            box-shadow: 0 8px 25px var(--shadow-color);
            transform: translateX(400px);
            transition: transform var(--animation-speed) ease;
            z-index: 1001;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #2ed573;
        }

        .toast.error {
            border-left: 4px solid #ff4757;
        }

        .toast.warning {
            border-left: 4px solid #ffa502;
        }

        .toast.info {
            border-left: 4px solid #4facfe;
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <span>GuardianIA</span>
            </div>
            <ul class="nav-menu">
                <li><a href="user_dashboard.php" class="nav-link">Mi Seguridad</a></li>
                <li><a href="user_security.php" class="nav-link">Protección</a></li>
                <li><a href="user_performance.php" class="nav-link">Optimización</a></li>
                <li><a href="#" class="nav-link active">Asistente IA</a></li>
                <li><a href="user_settings.php" class="nav-link">Configuración</a></li>
            </ul>
            <div class="user-profile">
                <div class="user-avatar">JD</div>
                <span>Juan Pérez</span>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">Conversaciones</h2>
            </div>
            
            <button class="new-chat-btn" onclick="createNewConversation()">
                <i class="fas fa-plus"></i>
                Nueva Conversación
            </button>
            
            <div class="conversation-list" id="conversationList">
                <?php if (!empty($conversations)): ?>
                    <?php foreach ($conversations as $conversation): ?>
                        <div class="conversation-item" onclick="loadConversation(<?php echo $conversation['id']; ?>)">
                            <div class="conversation-title"><?php echo htmlspecialchars($conversation['conversation_title']); ?></div>
                            <div class="conversation-preview"><?php echo htmlspecialchars($conversation['last_message'] ?? 'Sin mensajes'); ?></div>
                            <div class="conversation-time"><?php echo date('d/m/Y H:i', strtotime($conversation['updated_at'])); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="conversation-item">
                        <div class="conversation-title">No hay conversaciones</div>
                        <div class="conversation-preview">Inicia una nueva conversación</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="chat-area">
            <div class="chat-header">
                <div class="chat-title">
                    <div class="ai-avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="ai-info">
                        <h3>GuardianIA Assistant</h3>
                        <div class="ai-status">
                            <div class="status-dot"></div>
                            <span>En línea - Especialista en Seguridad</span>
                        </div>
                    </div>
                </div>
                <div class="chat-actions">
                    <button class="action-btn" onclick="clearChat()" title="Limpiar chat">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="action-btn" onclick="exportChat()" title="Exportar conversación">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="action-btn" onclick="showChatSettings()" title="Configuración">
                        <i class="fas fa-cog"></i>
                    </button>
                </div>
            </div>

            <div class="messages-container" id="messagesContainer">
                <div class="welcome-screen" id="welcomeScreen">
                    <div class="welcome-icon">
                        <i class="fas fa-robot"></i>
                    </div>
                    <h2 class="welcome-title">¡Hola! Soy tu Asistente IA</h2>
                    <p class="welcome-description">
                        Estoy aquí para ayudarte con cualquier pregunta sobre seguridad, optimización de rendimiento, 
                        configuración del sistema y mucho más. ¿En qué puedo asistirte hoy?
                    </p>
                    
                    <div class="welcome-suggestions">
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Cómo está mi sistema?')">
                            <div class="suggestion-icon">🛡️</div>
                            <div class="suggestion-title">Estado del Sistema</div>
                            <div class="suggestion-description">Verificar el estado actual de seguridad</div>
                        </div>
                        
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Cómo optimizar mi rendimiento?')">
                            <div class="suggestion-icon">⚡</div>
                            <div class="suggestion-title">Optimización</div>
                            <div class="suggestion-description">Mejorar el rendimiento del sistema</div>
                        </div>
                        
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Qué amenazas has detectado?')">
                            <div class="suggestion-icon">🔍</div>
                            <div class="suggestion-title">Amenazas</div>
                            <div class="suggestion-description">Revisar amenazas detectadas</div>
                        </div>
                        
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Cómo configurar la protección?')">
                            <div class="suggestion-icon">⚙️</div>
                            <div class="suggestion-title">Configuración</div>
                            <div class="suggestion-description">Ajustar configuraciones de seguridad</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="input-area">
                <div class="quick-actions">
                    <button class="quick-action" onclick="sendQuickMessage('Escanear sistema')">🔍 Escanear</button>
                    <button class="quick-action" onclick="sendQuickMessage('Optimizar rendimiento')">⚡ Optimizar</button>
                    <button class="quick-action" onclick="sendQuickMessage('Estado de seguridad')">🛡️ Estado</button>
                    <button class="quick-action" onclick="sendQuickMessage('Ayuda')">❓ Ayuda</button>
                </div>
                
                <div class="input-container">
                    <textarea 
                        class="message-input" 
                        id="messageInput" 
                        placeholder="Escribe tu mensaje aquí... (Presiona Enter para enviar)"
                        rows="1"
                    ></textarea>
                    <button class="send-btn" id="sendButton" onclick="sendMessage()">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <span id="toast-message"></span>
    </div>

    <script>
        // Variables globales
        let currentConversationId = null;
        let isTyping = false;
        let userId = <?php echo $user_id; ?>;

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            initializeChat();
            setupEventListeners();
        });

        // Inicializar chat
        function initializeChat() {
            console.log('Inicializando asistente IA...');
            adjustTextareaHeight();
        }

        // Configurar event listeners
        function setupEventListeners() {
            const messageInput = document.getElementById('messageInput');
            const sendButton = document.getElementById('sendButton');

            // Auto-resize textarea
            messageInput.addEventListener('input', adjustTextareaHeight);

            // Enviar mensaje con Enter
            messageInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });

            // Prevenir envío de mensajes vacíos
            messageInput.addEventListener('input', function() {
                const hasText = this.value.trim().length > 0;
                sendButton.disabled = !hasText;
            });
        }

        // Ajustar altura del textarea
        function adjustTextareaHeight() {
            const textarea = document.getElementById('messageInput');
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
        }

        // Enviar mensaje
        function sendMessage() {
            const messageInput = document.getElementById('messageInput');
            const message = messageInput.value.trim();

            if (!message || isTyping) return;

            // Limpiar input
            messageInput.value = '';
            adjustTextareaHeight();
            document.getElementById('sendButton').disabled = true;

            // Ocultar pantalla de bienvenida
            hideWelcomeScreen();

            // Mostrar mensaje del usuario
            addMessage('user', message);

            // Mostrar indicador de escritura
            showTypingIndicator();

            // Enviar mensaje al servidor
            fetch('user_assistant.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'send_message',
                    user_id: userId,
                    message: message,
                    conversation_id: currentConversationId
                })
            })
            .then(response => response.json())
            .then(data => {
                hideTypingIndicator();
                
                if (data.success) {
                    // Actualizar ID de conversación si es nueva
                    if (data.conversation_id && !currentConversationId) {
                        currentConversationId = data.conversation_id;
                        updateConversationsList();
                    }
                    
                    // Mostrar respuesta del bot
                    addMessage('bot', data.response);
                    
                    // Mostrar estadísticas si están disponibles
                    if (data.intent) {
                        console.log('Intención detectada:', data.intent);
                    }
                } else {
                    addMessage('bot', 'Lo siento, hubo un error al procesar tu mensaje. Por favor, inténtalo de nuevo.');
                    showToast('Error al enviar mensaje', 'error');
                }
            })
            .catch(error => {
                hideTypingIndicator();
                console.error('Error:', error);
                addMessage('bot', 'Lo siento, no pude procesar tu mensaje en este momento. Por favor, verifica tu conexión e inténtalo de nuevo.');
                showToast('Error de conexión', 'error');
            });
        }

        // Enviar mensaje rápido
        function sendQuickMessage(message) {
            const messageInput = document.getElementById('messageInput');
            messageInput.value = message;
            sendMessage();
        }

        // Agregar mensaje al chat
        function addMessage(sender, text) {
            const messagesContainer = document.getElementById('messagesContainer');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${sender}`;

            const now = new Date();
            const timeString = now.toLocaleTimeString('es-ES', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });

            messageDiv.innerHTML = `
                <div class="message-avatar">
                    <i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i>
                </div>
                <div class="message-content">
                    <div class="message-text">${formatMessage(text)}</div>
                    <div class="message-time">${timeString}</div>
                </div>
            `;

            messagesContainer.appendChild(messageDiv);
            scrollToBottom();
        }

        // Formatear mensaje (convertir enlaces, etc.)
        function formatMessage(text) {
            // Convertir URLs a enlaces
            const urlRegex = /(https?:\/\/[^\s]+)/g;
            text = text.replace(urlRegex, '<a href="$1" target="_blank" style="color: #4facfe;">$1</a>');
            
            // Convertir saltos de línea
            text = text.replace(/\n/g, '<br>');
            
            return text;
        }

        // Mostrar indicador de escritura
        function showTypingIndicator() {
            isTyping = true;
            const messagesContainer = document.getElementById('messagesContainer');
            
            const typingDiv = document.createElement('div');
            typingDiv.className = 'typing-indicator';
            typingDiv.id = 'typingIndicator';
            
            typingDiv.innerHTML = `
                <div class="message-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="typing-dots">
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                </div>
            `;
            
            messagesContainer.appendChild(typingDiv);
            scrollToBottom();
        }

        // Ocultar indicador de escritura
        function hideTypingIndicator() {
            isTyping = false;
            const typingIndicator = document.getElementById('typingIndicator');
            if (typingIndicator) {
                typingIndicator.remove();
            }
        }

        // Ocultar pantalla de bienvenida
        function hideWelcomeScreen() {
            const welcomeScreen = document.getElementById('welcomeScreen');
            if (welcomeScreen) {
                welcomeScreen.style.display = 'none';
            }
        }

        // Scroll al final del chat
        function scrollToBottom() {
            const messagesContainer = document.getElementById('messagesContainer');
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }

        // Crear nueva conversación
        function createNewConversation() {
            fetch('user_assistant.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'new_conversation',
                    user_id: userId,
                    title: 'Nueva conversación'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentConversationId = data.conversation_id;
                    clearChatMessages();
                    showWelcomeScreen();
                    updateConversationsList();
                    showToast('Nueva conversación iniciada', 'success');
                } else {
                    showToast('Error al crear conversación', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error de conexión', 'error');
            });
        }

        // Cargar conversación
        function loadConversation(conversationId) {
            currentConversationId = conversationId;
            
            // Actualizar UI
            document.querySelectorAll('.conversation-item').forEach(item => {
                item.classList.remove('active');
            });
            event.target.closest('.conversation-item').classList.add('active');
            
            // Cargar mensajes
            fetch('user_assistant.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'get_conversation_messages',
                    conversation_id: conversationId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    clearChatMessages();
                    hideWelcomeScreen();
                    
                    data.messages.forEach(message => {
                        addMessage(message.sender, message.message);
                    });
                    
                    if (data.messages.length === 0) {
                        showWelcomeScreen();
                    }
                } else {
                    showToast('Error al cargar conversación', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error de conexión', 'error');
            });
        }

        // Limpiar mensajes del chat
        function clearChatMessages() {
            const messagesContainer = document.getElementById('messagesContainer');
            messagesContainer.innerHTML = '';
        }

        // Mostrar pantalla de bienvenida
        function showWelcomeScreen() {
            const messagesContainer = document.getElementById('messagesContainer');
            messagesContainer.innerHTML = `
                <div class="welcome-screen" id="welcomeScreen">
                    <div class="welcome-icon">
                        <i class="fas fa-robot"></i>
                    </div>
                    <h2 class="welcome-title">¡Hola! Soy tu Asistente IA</h2>
                    <p class="welcome-description">
                        Estoy aquí para ayudarte con cualquier pregunta sobre seguridad, optimización de rendimiento, 
                        configuración del sistema y mucho más. ¿En qué puedo asistirte hoy?
                    </p>
                    
                    <div class="welcome-suggestions">
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Cómo está mi sistema?')">
                            <div class="suggestion-icon">🛡️</div>
                            <div class="suggestion-title">Estado del Sistema</div>
                            <div class="suggestion-description">Verificar el estado actual de seguridad</div>
                        </div>
                        
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Cómo optimizar mi rendimiento?')">
                            <div class="suggestion-icon">⚡</div>
                            <div class="suggestion-title">Optimización</div>
                            <div class="suggestion-description">Mejorar el rendimiento del sistema</div>
                        </div>
                        
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Qué amenazas has detectado?')">
                            <div class="suggestion-icon">🔍</div>
                            <div class="suggestion-title">Amenazas</div>
                            <div class="suggestion-description">Revisar amenazas detectadas</div>
                        </div>
                        
                        <div class="suggestion-card" onclick="sendQuickMessage('¿Cómo configurar la protección?')">
                            <div class="suggestion-icon">⚙️</div>
                            <div class="suggestion-title">Configuración</div>
                            <div class="suggestion-description">Ajustar configuraciones de seguridad</div>
                        </div>
                    </div>
                </div>
            `;
        }

        // Actualizar lista de conversaciones
        function updateConversationsList() {
            fetch('user_assistant.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'get_conversations',
                    user_id: userId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const conversationList = document.getElementById('conversationList');
                    conversationList.innerHTML = '';
                    
                    data.conversations.forEach(conversation => {
                        const conversationDiv = document.createElement('div');
                        conversationDiv.className = 'conversation-item';
                        if (conversation.id == currentConversationId) {
                            conversationDiv.classList.add('active');
                        }
                        
                        conversationDiv.onclick = () => loadConversation(conversation.id);
                        
                        conversationDiv.innerHTML = `
                            <div class="conversation-title">${conversation.conversation_title}</div>
                            <div class="conversation-preview">${conversation.last_message || 'Sin mensajes'}</div>
                            <div class="conversation-time">${new Date(conversation.updated_at).toLocaleString('es-ES')}</div>
                        `;
                        
                        conversationList.appendChild(conversationDiv);
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        // Limpiar chat
        function clearChat() {
            if (confirm('¿Estás seguro de que quieres limpiar esta conversación?')) {
                clearChatMessages();
                showWelcomeScreen();
                currentConversationId = null;
                showToast('Conversación limpiada', 'info');
            }
        }

        // Exportar chat
        function exportChat() {
            if (!currentConversationId) {
                showToast('No hay conversación para exportar', 'warning');
                return;
            }
            
            showToast('Función de exportación en desarrollo', 'info');
        }

        // Mostrar configuración del chat
        function showChatSettings() {
            showToast('Configuración del chat en desarrollo', 'info');
        }

        // Mostrar notificación toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type}`;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 4000);
        }

        // Manejo de errores
        window.addEventListener('error', function(e) {
            console.log('Error capturado:', e.message);
            showToast('Se produjo un error en el asistente IA. Reintentando...', 'error');
        });

        // Inicializar con primera conversación si existe
        <?php if (!empty($conversations)): ?>
            setTimeout(() => {
                loadConversation(<?php echo $conversations[0]['id']; ?>);
            }, 500);
        <?php endif; ?>
    </script>
</body>
</html>

