<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Optimización - GuardianIA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --warning-gradient: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(102, 126, 234, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(118, 75, 162, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(67, 233, 123, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        /* Navigation */
        .navbar {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .nav-link:hover {
            color: var(--text-primary);
            background: rgba(255, 255, 255, 0.1);
        }

        .nav-link.active {
            background: var(--info-gradient);
            color: white;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        /* Main Container */
        .main-container {
            margin-top: 80px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Performance Header */
        .performance-header {
            background: var(--info-gradient);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .performance-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            animation: performanceShine 4s infinite;
        }

        @keyframes performanceShine {
            0% { left: -100%; }
            100% { left: 100%; }
        }

        .performance-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .performance-subtitle {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 1.5rem;
        }

        .performance-score {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            font-weight: 600;
            color: white;
        }

        .score-number {
            font-size: 1.5rem;
            font-weight: 800;
            animation: scoreCounter 2s ease-out;
        }

        @keyframes scoreCounter {
            from { opacity: 0; transform: scale(0.5); }
            to { opacity: 1; transform: scale(1); }
        }

        /* System Metrics */
        .system-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .metric-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            position: relative;
            overflow: hidden;
            transition: all var(--animation-speed) ease;
        }

        .metric-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px var(--shadow-color);
        }

        .metric-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
        }

        .metric-card.cpu::before {
            background: var(--info-gradient);
        }

        .metric-card.ram::before {
            background: var(--warning-gradient);
        }

        .metric-card.storage::before {
            background: var(--danger-gradient);
        }

        .metric-card.battery::before {
            background: var(--success-gradient);
        }

        .metric-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .metric-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
        }

        .metric-value {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        .metric-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .metric-bar {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 0.5rem;
        }

        .metric-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 1s ease;
        }

        .metric-fill.good {
            background: var(--success-gradient);
        }

        .metric-fill.warning {
            background: var(--warning-gradient);
        }

        .metric-fill.danger {
            background: var(--danger-gradient);
        }

        .metric-status {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        /* Optimization Tools */
        .optimization-tools {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .tool-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            transition: all var(--animation-speed) ease;
        }

        .tool-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px var(--shadow-color);
        }

        .tool-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .tool-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }

        .tool-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .tool-description {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .tool-stats {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
        }

        .stat {
            text-align: center;
        }

        .stat-value {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .stat-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        .tool-button {
            width: 100%;
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .tool-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .tool-button.success {
            background: var(--success-gradient);
        }

        .tool-button.warning {
            background: var(--warning-gradient);
        }

        .tool-button.info {
            background: var(--info-gradient);
        }

        .tool-button.danger {
            background: var(--danger-gradient);
        }

        /* Auto Optimization */
        .auto-optimization {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            margin-bottom: 2rem;
        }

        .auto-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .auto-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .auto-toggle {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .toggle-switch {
            position: relative;
            width: 60px;
            height: 30px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
        }

        .toggle-switch.active {
            background: var(--success-gradient);
        }

        .toggle-slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 24px;
            height: 24px;
            background: white;
            border-radius: 50%;
            transition: all var(--animation-speed) ease;
        }

        .toggle-switch.active .toggle-slider {
            transform: translateX(30px);
        }

        .auto-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .auto-option {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
        }

        .auto-option:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .auto-option.active {
            background: rgba(67, 233, 123, 0.1);
            border: 1px solid rgba(67, 233, 123, 0.3);
        }

        .option-checkbox {
            width: 20px;
            height: 20px;
            border: 2px solid var(--border-color);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all var(--animation-speed) ease;
        }

        .auto-option.active .option-checkbox {
            background: var(--success-gradient);
            border-color: transparent;
        }

        .option-checkbox i {
            color: white;
            font-size: 0.8rem;
            opacity: 0;
            transition: opacity var(--animation-speed) ease;
        }

        .auto-option.active .option-checkbox i {
            opacity: 1;
        }

        .option-content {
            flex: 1;
        }

        .option-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .option-description {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        /* Progress Section */
        .optimization-progress {
            margin: 2rem 0;
            display: none;
        }

        .optimization-progress.active {
            display: block;
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .progress-title {
            font-size: 1.2rem;
            font-weight: 600;
        }

        .progress-percentage {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--success-gradient);
        }

        .progress-bar {
            width: 100%;
            height: 12px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 1rem;
        }

        .progress-fill {
            height: 100%;
            background: var(--success-gradient);
            border-radius: 6px;
            transition: width 0.3s ease;
            width: 0%;
        }

        .progress-text {
            text-align: center;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .progress-steps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .progress-step {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem;
            border-radius: 6px;
            transition: all var(--animation-speed) ease;
        }

        .progress-step.active {
            background: rgba(67, 233, 123, 0.1);
        }

        .progress-step.completed {
            background: rgba(67, 233, 123, 0.2);
        }

        .step-icon {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            background: rgba(255, 255, 255, 0.2);
            color: var(--text-secondary);
        }

        .progress-step.active .step-icon {
            background: var(--warning-gradient);
            color: white;
        }

        .progress-step.completed .step-icon {
            background: var(--success-gradient);
            color: white;
        }

        .step-text {
            font-size: 0.9rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .system-metrics {
                grid-template-columns: 1fr;
            }

            .optimization-tools {
                grid-template-columns: 1fr;
            }

            .auto-options {
                grid-template-columns: 1fr;
            }

            .performance-title {
                font-size: 2rem;
            }

            .main-container {
                padding: 1rem;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            top: 100px;
            right: 2rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem 1.5rem;
            color: var(--text-primary);
            box-shadow: 0 8px 25px var(--shadow-color);
            transform: translateX(400px);
            transition: transform var(--animation-speed) ease;
            z-index: 1001;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #2ed573;
        }

        .toast.error {
            border-left: 4px solid #ff4757;
        }

        .toast.warning {
            border-left: 4px solid #ffa502;
        }

        .toast.info {
            border-left: 4px solid #4facfe;
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <span>GuardianIA</span>
            </div>
            <ul class="nav-menu">
                <li><a href="user_dashboard.php" class="nav-link">Mi Seguridad</a></li>
                <li><a href="user_security.php" class="nav-link">Protección</a></li>
                <li><a href="#" class="nav-link active">Optimización</a></li>
                <li><a href="user_assistant.php" class="nav-link">Asistente IA</a></li>
                <li><a href="user_settings.php" class="nav-link">Configuración</a></li>
            </ul>
            <div class="user-profile">
                <div class="user-avatar">JD</div>
                <span>Juan Pérez</span>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Performance Header -->
        <div class="performance-header">
            <h1 class="performance-title">⚡ Optimizador Inteligente</h1>
            <p class="performance-subtitle">
                Maximiza el rendimiento de tu sistema con IA avanzada
            </p>
            <div class="performance-score">
                <i class="fas fa-tachometer-alt"></i>
                <span>Score de Rendimiento: </span>
                <span class="score-number">94</span>
                <span>/100</span>
            </div>
        </div>

        <!-- System Metrics -->
        <div class="system-metrics">
            <div class="metric-card cpu">
                <div class="metric-header">
                    <div>
                        <div class="metric-value" style="color: #4facfe;">45%</div>
                        <div class="metric-label">Uso de CPU</div>
                    </div>
                    <div class="metric-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-microchip"></i>
                    </div>
                </div>
                <div class="metric-bar">
                    <div class="metric-fill good" style="width: 45%"></div>
                </div>
                <div class="metric-status">Rendimiento óptimo</div>
            </div>

            <div class="metric-card ram">
                <div class="metric-header">
                    <div>
                        <div class="metric-value" style="color: #ffa726;">67%</div>
                        <div class="metric-label">Memoria RAM</div>
                    </div>
                    <div class="metric-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-memory"></i>
                    </div>
                </div>
                <div class="metric-bar">
                    <div class="metric-fill warning" style="width: 67%"></div>
                </div>
                <div class="metric-status">Se puede optimizar</div>
            </div>

            <div class="metric-card storage">
                <div class="metric-header">
                    <div>
                        <div class="metric-value" style="color: #fa709a;">78%</div>
                        <div class="metric-label">Almacenamiento</div>
                    </div>
                    <div class="metric-icon" style="background: var(--danger-gradient);">
                        <i class="fas fa-hdd"></i>
                    </div>
                </div>
                <div class="metric-bar">
                    <div class="metric-fill warning" style="width: 78%"></div>
                </div>
                <div class="metric-status">Limpieza recomendada</div>
            </div>

            <div class="metric-card battery">
                <div class="metric-header">
                    <div>
                        <div class="metric-value" style="color: #43e97b;">89%</div>
                        <div class="metric-label">Batería</div>
                    </div>
                    <div class="metric-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-battery-three-quarters"></i>
                    </div>
                </div>
                <div class="metric-bar">
                    <div class="metric-fill good" style="width: 89%"></div>
                </div>
                <div class="metric-status">Excelente duración</div>
            </div>
        </div>

        <!-- Optimization Tools -->
        <div class="optimization-tools">
            <div class="tool-card">
                <div class="tool-header">
                    <div class="tool-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-memory"></i>
                    </div>
                    <div>
                        <div class="tool-title">Optimizador de RAM</div>
                        <div class="tool-description">
                            Libera memoria no utilizada y optimiza procesos
                        </div>
                    </div>
                </div>
                <div class="tool-stats">
                    <div class="stat">
                        <div class="stat-value" style="color: #ffa726;">2.4 GB</div>
                        <div class="stat-label">Disponible</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #ffa726;">87.3%</div>
                        <div class="stat-label">Eficiencia</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #ffa726;">+18%</div>
                        <div class="stat-label">Mejora</div>
                    </div>
                </div>
                <button class="tool-button warning" onclick="optimizeRAM()">
                    <i class="fas fa-magic"></i>
                    Optimizar RAM
                </button>
            </div>

            <div class="tool-card">
                <div class="tool-header">
                    <div class="tool-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-broom"></i>
                    </div>
                    <div>
                        <div class="tool-title">Limpieza Inteligente</div>
                        <div class="tool-description">
                            Elimina archivos basura y duplicados automáticamente
                        </div>
                    </div>
                </div>
                <div class="tool-stats">
                    <div class="stat">
                        <div class="stat-value" style="color: #4facfe;">3.7 GB</div>
                        <div class="stat-label">Detectados</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #4facfe;">94.1%</div>
                        <div class="stat-label">Precisión</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #4facfe;">1,247</div>
                        <div class="stat-label">Archivos</div>
                    </div>
                </div>
                <button class="tool-button info" onclick="cleanupStorage()">
                    <i class="fas fa-trash-alt"></i>
                    Limpiar Ahora
                </button>
            </div>

            <div class="tool-card">
                <div class="tool-header">
                    <div class="tool-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-battery-full"></i>
                    </div>
                    <div>
                        <div class="tool-title">Optimizador de Batería</div>
                        <div class="tool-description">
                            Extiende la duración de la batería con IA
                        </div>
                    </div>
                </div>
                <div class="tool-stats">
                    <div class="stat">
                        <div class="stat-value" style="color: #43e97b;">+2.8h</div>
                        <div class="stat-label">Ganancia</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #43e97b;">92%</div>
                        <div class="stat-label">Eficiencia</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #43e97b;">Auto</div>
                        <div class="stat-label">Modo</div>
                    </div>
                </div>
                <button class="tool-button success" onclick="optimizeBattery()">
                    <i class="fas fa-bolt"></i>
                    Optimizar Batería
                </button>
            </div>

            <div class="tool-card">
                <div class="tool-header">
                    <div class="tool-icon" style="background: var(--primary-gradient);">
                        <i class="fas fa-compress-alt"></i>
                    </div>
                    <div>
                        <div class="tool-title">Compresión Inteligente</div>
                        <div class="tool-description">
                            Reduce el tamaño de archivos sin perder calidad
                        </div>
                    </div>
                </div>
                <div class="tool-stats">
                    <div class="stat">
                        <div class="stat-value" style="color: #667eea;">45%</div>
                        <div class="stat-label">Reducción</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #667eea;">1.2 GB</div>
                        <div class="stat-label">Ahorrado</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #667eea;">847</div>
                        <div class="stat-label">Archivos</div>
                    </div>
                </div>
                <button class="tool-button" onclick="compressFiles()">
                    <i class="fas fa-compress"></i>
                    Comprimir Archivos
                </button>
            </div>
        </div>

        <!-- Auto Optimization -->
        <div class="auto-optimization">
            <div class="auto-header">
                <h2 class="auto-title">🤖 Optimización Automática</h2>
                <div class="auto-toggle">
                    <span>Activar optimización automática</span>
                    <div class="toggle-switch active" onclick="toggleAutoOptimization()">
                        <div class="toggle-slider"></div>
                    </div>
                </div>
            </div>

            <div class="auto-options">
                <div class="auto-option active" onclick="toggleOption(this)">
                    <div class="option-checkbox">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="option-content">
                        <div class="option-title">Limpieza Diaria</div>
                        <div class="option-description">Elimina archivos temporales automáticamente</div>
                    </div>
                </div>

                <div class="auto-option active" onclick="toggleOption(this)">
                    <div class="option-checkbox">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="option-content">
                        <div class="option-title">Optimización de RAM</div>
                        <div class="option-description">Libera memoria cuando sea necesario</div>
                    </div>
                </div>

                <div class="auto-option" onclick="toggleOption(this)">
                    <div class="option-checkbox">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="option-content">
                        <div class="option-title">Modo Ahorro de Energía</div>
                        <div class="option-description">Activa automáticamente cuando la batería esté baja</div>
                    </div>
                </div>

                <div class="auto-option active" onclick="toggleOption(this)">
                    <div class="option-checkbox">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="option-content">
                        <div class="option-title">Compresión Inteligente</div>
                        <div class="option-description">Comprime archivos grandes automáticamente</div>
                    </div>
                </div>

                <div class="auto-option" onclick="toggleOption(this)">
                    <div class="option-checkbox">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="option-content">
                        <div class="option-title">Desfragmentación</div>
                        <div class="option-description">Optimiza el disco duro semanalmente</div>
                    </div>
                </div>

                <div class="auto-option active" onclick="toggleOption(this)">
                    <div class="option-checkbox">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="option-content">
                        <div class="option-title">Análisis Predictivo</div>
                        <div class="option-description">Predice y previene problemas de rendimiento</div>
                    </div>
                </div>
            </div>

            <div class="optimization-progress" id="optimizationProgress">
                <div class="progress-header">
                    <div class="progress-title">Optimizando sistema...</div>
                    <div class="progress-percentage" id="progressPercentage">0%</div>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
                <div class="progress-text" id="progressText">Preparando optimización...</div>
                
                <div class="progress-steps">
                    <div class="progress-step" id="step1">
                        <div class="step-icon">1</div>
                        <div class="step-text">Análisis del sistema</div>
                    </div>
                    <div class="progress-step" id="step2">
                        <div class="step-icon">2</div>
                        <div class="step-text">Limpieza de archivos</div>
                    </div>
                    <div class="progress-step" id="step3">
                        <div class="step-icon">3</div>
                        <div class="step-text">Optimización de RAM</div>
                    </div>
                    <div class="progress-step" id="step4">
                        <div class="step-icon">4</div>
                        <div class="step-text">Configuración de energía</div>
                    </div>
                    <div class="progress-step" id="step5">
                        <div class="step-icon">5</div>
                        <div class="step-text">Finalización</div>
                    </div>
                </div>
            </div>

            <button class="tool-button success" onclick="startFullOptimization()" id="fullOptimizeButton">
                <i class="fas fa-rocket"></i>
                Optimización Completa
            </button>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <span id="toast-message"></span>
    </div>

    <script>
        // Variables globales
        let isOptimizing = false;
        let optimizationProgress = 0;
        let optimizationInterval;
        let autoOptimizationEnabled = true;

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            initializePerformance();
            updateSystemMetrics();
            startRealTimeMonitoring();
        });

        // Inicializar módulo de rendimiento
        function initializePerformance() {
            console.log('Inicializando módulo de rendimiento...');
            updatePerformanceScore();
            checkAutoOptimization();
        }

        // Actualizar métricas del sistema
        function updateSystemMetrics() {
            // Simular actualización de métricas en tiempo real
            const metrics = {
                cpu: Math.floor(Math.random() * 30) + 30,
                ram: Math.floor(Math.random() * 40) + 50,
                storage: Math.floor(Math.random() * 20) + 70,
                battery: Math.floor(Math.random() * 20) + 80
            };

            // Actualizar valores en la interfaz
            updateMetricCard('cpu', metrics.cpu, '%');
            updateMetricCard('ram', metrics.ram, '%');
            updateMetricCard('storage', metrics.storage, '%');
            updateMetricCard('battery', metrics.battery, '%');

            // Actualizar score de rendimiento
            const averageScore = Math.floor((100 - metrics.cpu + 100 - metrics.ram + 100 - metrics.storage + metrics.battery) / 4);
            document.querySelector('.score-number').textContent = averageScore;
        }

        // Actualizar tarjeta de métrica
        function updateMetricCard(type, value, unit) {
            const card = document.querySelector(`.metric-card.${type}`);
            const valueElement = card.querySelector('.metric-value');
            const fillElement = card.querySelector('.metric-fill');
            const statusElement = card.querySelector('.metric-status');

            valueElement.textContent = value + unit;
            fillElement.style.width = value + '%';

            // Actualizar clase de color y estado
            fillElement.className = 'metric-fill';
            if (value < 50) {
                fillElement.classList.add('good');
                statusElement.textContent = 'Rendimiento óptimo';
            } else if (value < 80) {
                fillElement.classList.add('warning');
                statusElement.textContent = 'Se puede optimizar';
            } else {
                fillElement.classList.add('danger');
                statusElement.textContent = 'Optimización recomendada';
            }
        }

        // Optimizar RAM
        function optimizeRAM() {
            if (isOptimizing) {
                showToast('Ya hay una optimización en progreso...', 'warning');
                return;
            }

            const button = event.target;
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Optimizando...';
            button.disabled = true;

            showToast('Iniciando optimización de memoria RAM...', 'info');

            setTimeout(() => {
                const memoryFreed = (Math.random() * 2 + 1).toFixed(1);
                const improvement = Math.floor(Math.random() * 20) + 15;
                
                button.innerHTML = originalText;
                button.disabled = false;
                
                showToast(`RAM optimizada: ${memoryFreed} GB liberados, mejora del ${improvement}%`, 'success');
                updateSystemMetrics();
            }, 3000);
        }

        // Limpiar almacenamiento
        function cleanupStorage() {
            if (isOptimizing) {
                showToast('Ya hay una optimización en progreso...', 'warning');
                return;
            }

            const button = event.target;
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Limpiando...';
            button.disabled = true;

            showToast('Iniciando limpieza inteligente del sistema...', 'info');

            const cleanupSteps = [
                'Analizando archivos temporales...',
                'Eliminando archivos basura...',
                'Buscando duplicados...',
                'Limpiando caché del sistema...',
                'Optimizando registro...'
            ];

            let currentStep = 0;
            const stepInterval = setInterval(() => {
                if (currentStep < cleanupSteps.length) {
                    showToast(cleanupSteps[currentStep], 'info');
                    currentStep++;
                } else {
                    clearInterval(stepInterval);
                    
                    const spaceFreed = (Math.random() * 3 + 2).toFixed(1);
                    const filesRemoved = Math.floor(Math.random() * 1000) + 500;
                    
                    button.innerHTML = originalText;
                    button.disabled = false;
                    
                    showToast(`Limpieza completada: ${spaceFreed} GB liberados, ${filesRemoved} archivos eliminados`, 'success');
                    updateSystemMetrics();
                }
            }, 1500);
        }

        // Optimizar batería
        function optimizeBattery() {
            if (isOptimizing) {
                showToast('Ya hay una optimización en progreso...', 'warning');
                return;
            }

            const button = event.target;
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Optimizando...';
            button.disabled = true;

            showToast('Optimizando configuración de energía...', 'info');

            setTimeout(() => {
                const timeGained = (Math.random() * 2 + 1.5).toFixed(1);
                const efficiency = Math.floor(Math.random() * 10) + 85;
                
                button.innerHTML = originalText;
                button.disabled = false;
                
                showToast(`Batería optimizada: +${timeGained}h de duración, ${efficiency}% eficiencia`, 'success');
                updateSystemMetrics();
            }, 2500);
        }

        // Comprimir archivos
        function compressFiles() {
            if (isOptimizing) {
                showToast('Ya hay una optimización en progreso...', 'warning');
                return;
            }

            const button = event.target;
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Comprimiendo...';
            button.disabled = true;

            showToast('Iniciando compresión inteligente de archivos...', 'info');

            setTimeout(() => {
                const spaceSaved = (Math.random() * 1.5 + 0.8).toFixed(1);
                const compressionRate = Math.floor(Math.random() * 20) + 35;
                const filesCompressed = Math.floor(Math.random() * 500) + 300;
                
                button.innerHTML = originalText;
                button.disabled = false;
                
                showToast(`Compresión completada: ${spaceSaved} GB ahorrados, ${compressionRate}% reducción, ${filesCompressed} archivos`, 'success');
                updateSystemMetrics();
            }, 4000);
        }

        // Toggle optimización automática
        function toggleAutoOptimization() {
            const toggle = event.target.closest('.toggle-switch');
            autoOptimizationEnabled = !autoOptimizationEnabled;
            
            if (autoOptimizationEnabled) {
                toggle.classList.add('active');
                showToast('Optimización automática activada', 'success');
            } else {
                toggle.classList.remove('active');
                showToast('Optimización automática desactivada', 'warning');
            }
        }

        // Toggle opción de auto optimización
        function toggleOption(option) {
            option.classList.toggle('active');
            const title = option.querySelector('.option-title').textContent;
            const isActive = option.classList.contains('active');
            
            showToast(`${title} ${isActive ? 'activado' : 'desactivado'}`, isActive ? 'success' : 'info');
        }

        // Iniciar optimización completa
        function startFullOptimization() {
            if (isOptimizing) {
                showToast('Ya hay una optimización en progreso...', 'warning');
                return;
            }

            isOptimizing = true;
            optimizationProgress = 0;
            
            const button = document.getElementById('fullOptimizeButton');
            const progressSection = document.getElementById('optimizationProgress');
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');
            const progressPercentage = document.getElementById('progressPercentage');
            
            // Mostrar barra de progreso
            progressSection.classList.add('active');
            button.innerHTML = '<div class="loading"></div> Optimizando Sistema...';
            button.disabled = true;
            
            showToast('Iniciando optimización completa del sistema...', 'info');
            
            // Pasos de optimización
            const optimizationSteps = [
                { text: 'Analizando rendimiento del sistema...', step: 1 },
                { text: 'Limpiando archivos temporales y basura...', step: 2 },
                { text: 'Optimizando memoria RAM y procesos...', step: 3 },
                { text: 'Configurando ahorro de energía...', step: 4 },
                { text: 'Aplicando configuraciones finales...', step: 5 }
            ];
            
            let currentStepIndex = 0;
            
            optimizationInterval = setInterval(() => {
                if (currentStepIndex < optimizationSteps.length) {
                    const currentStep = optimizationSteps[currentStepIndex];
                    
                    // Actualizar texto y progreso
                    progressText.textContent = currentStep.text;
                    optimizationProgress = ((currentStepIndex + 1) / optimizationSteps.length) * 100;
                    progressFill.style.width = optimizationProgress + '%';
                    progressPercentage.textContent = Math.floor(optimizationProgress) + '%';
                    
                    // Actualizar pasos visuales
                    updateProgressStep(currentStep.step);
                    
                    currentStepIndex++;
                } else {
                    completeFullOptimization();
                }
            }, 2000);
        }

        // Actualizar paso de progreso
        function updateProgressStep(stepNumber) {
            // Marcar pasos anteriores como completados
            for (let i = 1; i < stepNumber; i++) {
                const step = document.getElementById(`step${i}`);
                step.classList.remove('active');
                step.classList.add('completed');
            }
            
            // Marcar paso actual como activo
            const currentStep = document.getElementById(`step${stepNumber}`);
            currentStep.classList.add('active');
            currentStep.classList.remove('completed');
        }

        // Completar optimización completa
        function completeFullOptimization() {
            clearInterval(optimizationInterval);
            
            const button = document.getElementById('fullOptimizeButton');
            const progressSection = document.getElementById('optimizationProgress');
            const progressText = document.getElementById('progressText');
            
            // Marcar último paso como completado
            const lastStep = document.getElementById('step5');
            lastStep.classList.remove('active');
            lastStep.classList.add('completed');
            
            progressText.textContent = 'Optimización completada exitosamente';
            
            setTimeout(() => {
                progressSection.classList.remove('active');
                button.innerHTML = '<i class="fas fa-rocket"></i> Optimización Completa';
                button.disabled = false;
                isOptimizing = false;
                
                // Resetear pasos
                for (let i = 1; i <= 5; i++) {
                    const step = document.getElementById(`step${i}`);
                    step.classList.remove('active', 'completed');
                }
                
                const improvements = {
                    performance: Math.floor(Math.random() * 15) + 20,
                    memory: (Math.random() * 2 + 2).toFixed(1),
                    storage: (Math.random() * 3 + 3).toFixed(1),
                    battery: (Math.random() * 2 + 2).toFixed(1)
                };
                
                showToast(`Optimización completada: +${improvements.performance}% rendimiento, ${improvements.memory} GB RAM liberados, ${improvements.storage} GB almacenamiento limpio, +${improvements.battery}h batería`, 'success');
                updateSystemMetrics();
                updatePerformanceScore();
            }, 3000);
        }

        // Actualizar score de rendimiento
        function updatePerformanceScore() {
            const scoreElement = document.querySelector('.score-number');
            const currentScore = parseInt(scoreElement.textContent);
            const newScore = Math.min(100, currentScore + Math.floor(Math.random() * 5) + 1);
            
            // Animación de contador
            let counter = currentScore;
            const increment = (newScore - currentScore) / 20;
            
            const counterInterval = setInterval(() => {
                counter += increment;
                if (counter >= newScore) {
                    counter = newScore;
                    clearInterval(counterInterval);
                }
                scoreElement.textContent = Math.floor(counter);
            }, 50);
        }

        // Verificar optimización automática
        function checkAutoOptimization() {
            if (autoOptimizationEnabled) {
                console.log('Optimización automática habilitada');
                // Aquí se ejecutarían las optimizaciones automáticas según la configuración
            }
        }

        // Iniciar monitoreo en tiempo real
        function startRealTimeMonitoring() {
            setInterval(() => {
                updateSystemMetrics();
            }, 15000); // Actualizar cada 15 segundos
        }

        // Mostrar notificación toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type}`;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 4000);
        }

        // Simulación de optimización automática
        setInterval(() => {
            if (autoOptimizationEnabled && Math.random() < 0.1) { // 10% de probabilidad cada 2 minutos
                const autoActions = [
                    'Limpieza automática de archivos temporales completada',
                    'Memoria RAM optimizada automáticamente',
                    'Configuración de energía ajustada',
                    'Archivos comprimidos automáticamente'
                ];
                
                const randomAction = autoActions[Math.floor(Math.random() * autoActions.length)];
                showToast(randomAction, 'success');
                updateSystemMetrics();
            }
        }, 120000); // Cada 2 minutos

        // Manejo de errores
        window.addEventListener('error', function(e) {
            console.log('Error capturado:', e.message);
            showToast('Se produjo un error en el optimizador. Reintentando...', 'error');
        });

        // Cleanup al salir
        window.addEventListener('beforeunload', function() {
            if (optimizationInterval) {
                clearInterval(optimizationInterval);
            }
        });

        // Efectos de hover para las tarjetas
        document.querySelectorAll('.metric-card, .tool-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Animación de entrada para las tarjetas
        function initializeAnimations() {
            const cards = document.querySelectorAll('.metric-card, .tool-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        }

        // Inicializar animaciones después de cargar
        setTimeout(initializeAnimations, 500);
    </script>
</body>
</html>

