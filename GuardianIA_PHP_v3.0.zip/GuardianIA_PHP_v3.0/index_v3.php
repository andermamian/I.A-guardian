<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA v3.0 - Protección Inteligente Avanzada</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --warning-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --dark-gradient: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            --quantum-gradient: linear-gradient(135deg, #8B5CF6 0%, #06B6D4 50%, #10B981 100%);
            --ai-gradient: linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 50%, #45B7D1 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            --glow-color: rgba(102, 126, 234, 0.4);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Enhanced Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.2) 0%, transparent 50%),
                radial-gradient(circle at 60% 70%, rgba(139, 92, 246, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        .animated-bg::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                linear-gradient(45deg, transparent 30%, rgba(102, 126, 234, 0.1) 50%, transparent 70%);
            animation: scanLine 6s linear infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(1.05); }
        }

        @keyframes scanLine {
            0% { transform: translateX(-100%) rotate(45deg); }
            100% { transform: translateX(100vw) rotate(45deg); }
        }

        /* Floating Particles */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: var(--glow-color);
            border-radius: 50%;
            animation: float 20s infinite linear;
            opacity: 0.6;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) translateX(0px);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
            }
            90% {
                opacity: 0.6;
            }
            100% {
                transform: translateY(-100px) translateX(100px);
                opacity: 0;
            }
        }

        /* Enhanced Navigation */
        .navbar {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            transition: all var(--animation-speed) ease;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .navbar.scrolled {
            background: rgba(15, 15, 35, 0.98);
            box-shadow: 0 8px 32px rgba(102, 126, 234, 0.2);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: logoGlow 3s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { filter: drop-shadow(0 0 5px rgba(102, 126, 234, 0.5)); }
            50% { filter: drop-shadow(0 0 20px rgba(102, 126, 234, 0.8)); }
        }

        .logo i {
            font-size: 2rem;
            background: var(--quantum-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: iconSpin 10s linear infinite;
        }

        @keyframes iconSpin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .nav-links {
            display: flex;
            gap: 2rem;
            list-style: none;
        }

        .nav-links a {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            transition: all var(--animation-speed) ease;
            position: relative;
            padding: 0.5rem 1rem;
            border-radius: 8px;
        }

        .nav-links a:hover {
            color: var(--text-primary);
            background: rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: var(--primary-gradient);
            transition: all var(--animation-speed) ease;
            transform: translateX(-50%);
        }

        .nav-links a:hover::after {
            width: 80%;
        }

        /* Enhanced Main Container */
        .main-container {
            margin-top: 80px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Enhanced Header */
        .header {
            text-align: center;
            margin-bottom: 3rem;
            position: relative;
        }

        .header h1 {
            font-size: 3.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            background: var(--ai-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: titlePulse 4s ease-in-out infinite;
        }

        @keyframes titlePulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .header p {
            font-size: 1.2rem;
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto;
            animation: fadeInUp 1s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Enhanced Status Cards */
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .status-card {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            border: 1px solid var(--border-color);
            transition: all var(--animation-speed) ease;
            position: relative;
            overflow: hidden;
            animation: cardSlideIn 0.8s ease-out;
        }

        @keyframes cardSlideIn {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .status-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.8s ease;
        }

        .status-card:hover::before {
            left: 100%;
        }

        .status-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            border-color: rgba(102, 126, 234, 0.5);
        }

        .status-card.ai-antivirus {
            border-left: 4px solid #FF6B6B;
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.1) 0%, var(--bg-card) 100%);
        }

        .status-card.ai-vpn {
            border-left: 4px solid #4ECDC4;
            background: linear-gradient(135deg, rgba(78, 205, 196, 0.1) 0%, var(--bg-card) 100%);
        }

        .status-card.quantum-security {
            border-left: 4px solid #8B5CF6;
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, var(--bg-card) 100%);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            animation: iconPulse 2s ease-in-out infinite;
        }

        @keyframes iconPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .card-icon.ai-antivirus {
            background: linear-gradient(135deg, #FF6B6B, #FF8E8E);
            color: white;
        }

        .card-icon.ai-vpn {
            background: linear-gradient(135deg, #4ECDC4, #6EE7E0);
            color: white;
        }

        .card-icon.quantum {
            background: var(--quantum-gradient);
            color: white;
        }

        .card-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .card-subtitle {
            font-size: 0.9rem;
            color: var(--text-secondary);
        }

        .status-indicator {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .status-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            animation: statusBlink 2s ease-in-out infinite;
        }

        @keyframes statusBlink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .status-dot.active {
            background: #00ff88;
            box-shadow: 0 0 10px #00ff88;
        }

        .status-dot.warning {
            background: #ffaa00;
            box-shadow: 0 0 10px #ffaa00;
        }

        .status-dot.danger {
            background: #ff4444;
            box-shadow: 0 0 10px #ff4444;
        }

        .status-text {
            font-weight: 600;
            font-size: 0.9rem;
        }

        .status-text.active {
            color: #00ff88;
        }

        .status-text.warning {
            color: #ffaa00;
        }

        .status-text.danger {
            color: #ff4444;
        }

        .card-metrics {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .metric {
            text-align: center;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .metric:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: scale(1.05);
        }

        .metric-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
            display: block;
        }

        .metric-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-top: 0.25rem;
        }

        /* Enhanced Action Buttons */
        .card-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }

        .btn-primary {
            background: var(--primary-gradient);
            color: white;
        }

        .btn-success {
            background: var(--success-gradient);
            color: white;
        }

        .btn-warning {
            background: var(--warning-gradient);
            color: white;
        }

        .btn-danger {
            background: var(--danger-gradient);
            color: white;
        }

        .btn-quantum {
            background: var(--quantum-gradient);
            color: white;
        }

        /* AI Activity Monitor */
        .ai-monitor {
            background: var(--bg-card);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            border: 1px solid var(--border-color);
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }

        .ai-monitor::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: var(--ai-gradient);
            animation: progressBar 3s ease-in-out infinite;
        }

        @keyframes progressBar {
            0% { transform: translateX(-100%); }
            50% { transform: translateX(0%); }
            100% { transform: translateX(100%); }
        }

        .monitor-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }

        .monitor-title {
            font-size: 1.4rem;
            font-weight: 700;
            background: var(--ai-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .ai-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: rgba(0, 255, 136, 0.1);
            border-radius: 20px;
            border: 1px solid rgba(0, 255, 136, 0.3);
        }

        .ai-pulse {
            width: 8px;
            height: 8px;
            background: #00ff88;
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.5); opacity: 0.7; }
        }

        .activity-feed {
            max-height: 200px;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: var(--border-color) transparent;
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.75rem;
            margin-bottom: 0.5rem;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 8px;
            border-left: 3px solid transparent;
            transition: all var(--animation-speed) ease;
            animation: slideInLeft 0.5s ease-out;
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .activity-item:hover {
            background: rgba(255, 255, 255, 0.08);
            transform: translateX(5px);
        }

        .activity-item.info {
            border-left-color: #4ECDC4;
        }

        .activity-item.warning {
            border-left-color: #ffaa00;
        }

        .activity-item.success {
            border-left-color: #00ff88;
        }

        .activity-item.danger {
            border-left-color: #ff4444;
        }

        .activity-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            flex-shrink: 0;
        }

        .activity-content {
            flex: 1;
        }

        .activity-text {
            font-size: 0.9rem;
            color: var(--text-primary);
            margin-bottom: 0.25rem;
        }

        .activity-time {
            font-size: 0.75rem;
            color: var(--text-secondary);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }
            
            .header h1 {
                font-size: 2.5rem;
            }
            
            .status-grid {
                grid-template-columns: 1fr;
            }
            
            .card-metrics {
                grid-template-columns: 1fr;
            }
            
            .card-actions {
                flex-direction: column;
            }
            
            .main-container {
                padding: 1rem;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Notification Toast */
        .toast {
            position: fixed;
            top: 100px;
            right: 20px;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem 1.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            z-index: 1001;
            transform: translateX(400px);
            transition: transform 0.3s ease;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #00ff88;
        }

        .toast.warning {
            border-left: 4px solid #ffaa00;
        }

        .toast.error {
            border-left: 4px solid #ff4444;
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    <div class="particles" id="particles"></div>

    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <span>GuardianIA v3.0</span>
            </div>
            <ul class="nav-links">
                <li><a href="#dashboard">Dashboard</a></li>
                <li><a href="#ai-antivirus">AI Antivirus</a></li>
                <li><a href="#ai-vpn">AI VPN</a></li>
                <li><a href="#quantum-security">Quantum Security</a></li>
                <li><a href="#settings">Configuración</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Header -->
        <div class="header">
            <h1>GuardianIA v3.0</h1>
            <p>Sistema de Protección Inteligente con IA Antivirus, VPN AI y Seguridad Cuántica</p>
        </div>

        <!-- AI Activity Monitor -->
        <div class="ai-monitor">
            <div class="monitor-header">
                <h3 class="monitor-title">Monitor de Actividad IA</h3>
                <div class="ai-status">
                    <div class="ai-pulse"></div>
                    <span>IA Activa</span>
                </div>
            </div>
            <div class="activity-feed" id="activityFeed">
                <div class="activity-item success">
                    <div class="activity-icon" style="background: #00ff88;">
                        <i class="fas fa-shield-check"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-text">Sistema AI Antivirus inicializado correctamente</div>
                        <div class="activity-time">Hace 2 minutos</div>
                    </div>
                </div>
                <div class="activity-item info">
                    <div class="activity-icon" style="background: #4ECDC4;">
                        <i class="fas fa-network-wired"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-text">VPN AI estableciendo conexión óptima</div>
                        <div class="activity-time">Hace 3 minutos</div>
                    </div>
                </div>
                <div class="activity-item warning">
                    <div class="activity-icon" style="background: #ffaa00;">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-text">Detectada IA sospechosa - Análisis en progreso</div>
                        <div class="activity-time">Hace 5 minutos</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Status Grid -->
        <div class="status-grid">
            <!-- AI Antivirus Card -->
            <div class="status-card ai-antivirus">
                <div class="card-header">
                    <div class="card-icon ai-antivirus">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div>
                        <div class="card-title">AI Antivirus Engine</div>
                        <div class="card-subtitle">Protección contra IAs maliciosas</div>
                    </div>
                </div>
                
                <div class="status-indicator">
                    <div class="status-dot active"></div>
                    <span class="status-text active">Sistema Activo - Protegiendo</span>
                </div>
                
                <div class="card-metrics">
                    <div class="metric">
                        <span class="metric-value" id="aiThreatsBlocked">247</span>
                        <span class="metric-label">IAs Bloqueadas</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="aiScanAccuracy">98.7%</span>
                        <span class="metric-label">Precisión</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="quantumSignatures">15</span>
                        <span class="metric-label">Firmas Cuánticas</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="neuralAnomalies">3</span>
                        <span class="metric-label">Anomalías Neurales</span>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="scanForMaliciousAI()">
                        <i class="fas fa-search"></i>
                        Escanear IAs
                    </button>
                    <button class="btn btn-danger" onclick="emergencyAIShutdown()">
                        <i class="fas fa-power-off"></i>
                        Emergencia
                    </button>
                </div>
            </div>

            <!-- AI VPN Card -->
            <div class="status-card ai-vpn">
                <div class="card-header">
                    <div class="card-icon ai-vpn">
                        <i class="fas fa-globe-americas"></i>
                    </div>
                    <div>
                        <div class="card-title">AI VPN Engine</div>
                        <div class="card-subtitle">VPN inteligente y adaptativo</div>
                    </div>
                </div>
                
                <div class="status-indicator">
                    <div class="status-dot active"></div>
                    <span class="status-text active">Conectado - Tokio, JP</span>
                </div>
                
                <div class="card-metrics">
                    <div class="metric">
                        <span class="metric-value" id="vpnLatency">23ms</span>
                        <span class="metric-label">Latencia</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="vpnSpeed">156</span>
                        <span class="metric-label">Mbps</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="vpnSecurity">99.9%</span>
                        <span class="metric-label">Seguridad</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="vpnOptimizations">42</span>
                        <span class="metric-label">Optimizaciones IA</span>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button class="btn btn-success" onclick="optimizeVPNConnection()">
                        <i class="fas fa-magic"></i>
                        Optimizar IA
                    </button>
                    <button class="btn btn-warning" onclick="changeVPNServer()">
                        <i class="fas fa-exchange-alt"></i>
                        Cambiar Servidor
                    </button>
                </div>
            </div>

            <!-- Quantum Security Card -->
            <div class="status-card quantum-security">
                <div class="card-header">
                    <div class="card-icon quantum">
                        <i class="fas fa-atom"></i>
                    </div>
                    <div>
                        <div class="card-title">Quantum Security</div>
                        <div class="card-subtitle">Protección cuántica avanzada</div>
                    </div>
                </div>
                
                <div class="status-indicator">
                    <div class="status-dot active"></div>
                    <span class="status-text active">Encriptación Cuántica Activa</span>
                </div>
                
                <div class="card-metrics">
                    <div class="metric">
                        <span class="metric-value" id="quantumKeys">2048</span>
                        <span class="metric-label">Claves Cuánticas</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="quantumEntanglement">87.3%</span>
                        <span class="metric-label">Entrelazamiento</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="quantumCoherence">94.1%</span>
                        <span class="metric-label">Coherencia</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="quantumThreats">0</span>
                        <span class="metric-label">Amenazas Cuánticas</span>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button class="btn btn-quantum" onclick="generateQuantumKeys()">
                        <i class="fas fa-key"></i>
                        Generar Claves
                    </button>
                    <button class="btn btn-primary" onclick="quantumAnalysis()">
                        <i class="fas fa-microscope"></i>
                        Análisis Cuántico
                    </button>
                </div>
            </div>

            <!-- System Performance Card -->
            <div class="status-card">
                <div class="card-header">
                    <div class="card-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    <div>
                        <div class="card-title">Rendimiento del Sistema</div>
                        <div class="card-subtitle">Optimización inteligente activa</div>
                    </div>
                </div>
                
                <div class="status-indicator">
                    <div class="status-dot active"></div>
                    <span class="status-text active">Rendimiento Óptimo</span>
                </div>
                
                <div class="card-metrics">
                    <div class="metric">
                        <span class="metric-value" id="cpuUsage">34%</span>
                        <span class="metric-label">CPU</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="ramUsage">67%</span>
                        <span class="metric-label">RAM</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="diskUsage">45%</span>
                        <span class="metric-label">Disco</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="networkUsage">12%</span>
                        <span class="metric-label">Red</span>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button class="btn btn-success" onclick="optimizeSystem()">
                        <i class="fas fa-rocket"></i>
                        Optimizar
                    </button>
                    <button class="btn btn-primary" onclick="deepClean()">
                        <i class="fas fa-broom"></i>
                        Limpieza Profunda
                    </button>
                </div>
            </div>

            <!-- Threat Intelligence Card -->
            <div class="status-card">
                <div class="card-header">
                    <div class="card-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-eye"></i>
                    </div>
                    <div>
                        <div class="card-title">Inteligencia de Amenazas</div>
                        <div class="card-subtitle">Monitoreo global en tiempo real</div>
                    </div>
                </div>
                
                <div class="status-indicator">
                    <div class="status-dot warning"></div>
                    <span class="status-text warning">3 Amenazas Detectadas</span>
                </div>
                
                <div class="card-metrics">
                    <div class="metric">
                        <span class="metric-value" id="globalThreats">1,247</span>
                        <span class="metric-label">Amenazas Globales</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="blockedAttacks">89</span>
                        <span class="metric-label">Ataques Bloqueados</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="threatLevel">6.2</span>
                        <span class="metric-label">Nivel de Amenaza</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="aiPredictions">94%</span>
                        <span class="metric-label">Precisión IA</span>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button class="btn btn-warning" onclick="viewThreatMap()">
                        <i class="fas fa-map"></i>
                        Mapa de Amenazas
                    </button>
                    <button class="btn btn-danger" onclick="activateShields()">
                        <i class="fas fa-shield-alt"></i>
                        Activar Escudos
                    </button>
                </div>
            </div>

            <!-- AI Assistant Card -->
            <div class="status-card">
                <div class="card-header">
                    <div class="card-icon" style="background: var(--ai-gradient);">
                        <i class="fas fa-brain"></i>
                    </div>
                    <div>
                        <div class="card-title">Asistente IA</div>
                        <div class="card-subtitle">Inteligencia artificial conversacional</div>
                    </div>
                </div>
                
                <div class="status-indicator">
                    <div class="status-dot active"></div>
                    <span class="status-text active">IA Lista para Conversar</span>
                </div>
                
                <div class="card-metrics">
                    <div class="metric">
                        <span class="metric-value" id="aiConversations">156</span>
                        <span class="metric-label">Conversaciones</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="aiAccuracy">97.8%</span>
                        <span class="metric-label">Precisión</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="aiLearning">89%</span>
                        <span class="metric-label">Aprendizaje</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value" id="aiResponseTime">0.3s</span>
                        <span class="metric-label">Tiempo Respuesta</span>
                    </div>
                </div>
                
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="openAIChat()">
                        <i class="fas fa-comments"></i>
                        Abrir Chat
                    </button>
                    <button class="btn btn-success" onclick="trainAI()">
                        <i class="fas fa-graduation-cap"></i>
                        Entrenar IA
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast" id="toast">
        <div id="toastMessage"></div>
    </div>

    <script>
        // Initialize particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 50;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 20 + 's';
                particle.style.animationDuration = (Math.random() * 10 + 15) + 's';
                particlesContainer.appendChild(particle);
            }
        }

        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Show toast notification
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toastMessage');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type}`;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Update metrics with animation
        function updateMetric(elementId, newValue) {
            const element = document.getElementById(elementId);
            if (element) {
                element.style.transform = 'scale(1.2)';
                element.style.color = '#00ff88';
                
                setTimeout(() => {
                    element.textContent = newValue;
                    element.style.transform = 'scale(1)';
                    element.style.color = '';
                }, 200);
            }
        }

        // Add activity to feed
        function addActivity(text, type = 'info', icon = 'fas fa-info-circle') {
            const activityFeed = document.getElementById('activityFeed');
            const activityItem = document.createElement('div');
            activityItem.className = `activity-item ${type}`;
            
            const colors = {
                info: '#4ECDC4',
                success: '#00ff88',
                warning: '#ffaa00',
                danger: '#ff4444'
            };
            
            activityItem.innerHTML = `
                <div class="activity-icon" style="background: ${colors[type]};">
                    <i class="${icon}"></i>
                </div>
                <div class="activity-content">
                    <div class="activity-text">${text}</div>
                    <div class="activity-time">Ahora</div>
                </div>
            `;
            
            activityFeed.insertBefore(activityItem, activityFeed.firstChild);
            
            // Remove old activities (keep only 10)
            while (activityFeed.children.length > 10) {
                activityFeed.removeChild(activityFeed.lastChild);
            }
        }

        // AI Antivirus Functions
        function scanForMaliciousAI() {
            showToast('Iniciando escaneo de IAs maliciosas...', 'info');
            addActivity('Escaneo de IA iniciado - Analizando firmas neurales', 'info', 'fas fa-search');
            
            // Simulate scan progress
            setTimeout(() => {
                const threatsFound = Math.floor(Math.random() * 5);
                updateMetric('aiThreatsBlocked', parseInt(document.getElementById('aiThreatsBlocked').textContent) + threatsFound);
                
                if (threatsFound > 0) {
                    showToast(`${threatsFound} IAs maliciosas detectadas y neutralizadas`, 'warning');
                    addActivity(`${threatsFound} IAs maliciosas neutralizadas`, 'warning', 'fas fa-shield-alt');
                } else {
                    showToast('Escaneo completado - No se detectaron amenazas', 'success');
                    addActivity('Escaneo completado - Sistema limpio', 'success', 'fas fa-check-circle');
                }
            }, 3000);
        }

        function emergencyAIShutdown() {
            showToast('Protocolo de emergencia activado', 'danger');
            addActivity('EMERGENCIA: Desconectando todas las IAs sospechosas', 'danger', 'fas fa-power-off');
            
            setTimeout(() => {
                showToast('Todas las IAs han sido aisladas de forma segura', 'success');
                addActivity('Sistema asegurado - IAs aisladas', 'success', 'fas fa-lock');
            }, 2000);
        }

        // AI VPN Functions
        function optimizeVPNConnection() {
            showToast('Optimizando conexión VPN con IA...', 'info');
            addActivity('IA analizando rutas óptimas', 'info', 'fas fa-route');
            
            setTimeout(() => {
                const latencyImprovement = Math.floor(Math.random() * 20) + 5;
                const currentLatency = parseInt(document.getElementById('vpnLatency').textContent);
                updateMetric('vpnLatency', Math.max(5, currentLatency - latencyImprovement) + 'ms');
                updateMetric('vpnOptimizations', parseInt(document.getElementById('vpnOptimizations').textContent) + 1);
                
                showToast(`Conexión optimizada - Latencia reducida en ${latencyImprovement}ms`, 'success');
                addActivity(`Optimización completada - Mejora de ${latencyImprovement}ms`, 'success', 'fas fa-rocket');
            }, 2500);
        }

        function changeVPNServer() {
            const servers = ['Nueva York, US', 'Londres, UK', 'Tokio, JP', 'Singapur, SG', 'Frankfurt, DE'];
            const randomServer = servers[Math.floor(Math.random() * servers.length)];
            
            showToast(`Cambiando a servidor: ${randomServer}`, 'info');
            addActivity(`Conectando a ${randomServer}`, 'info', 'fas fa-globe');
            
            setTimeout(() => {
                document.querySelector('.ai-vpn .status-text').textContent = `Conectado - ${randomServer}`;
                const newLatency = Math.floor(Math.random() * 50) + 15;
                updateMetric('vpnLatency', newLatency + 'ms');
                
                showToast(`Conectado exitosamente a ${randomServer}`, 'success');
                addActivity(`Conexión establecida con ${randomServer}`, 'success', 'fas fa-check-circle');
            }, 3000);
        }

        // Quantum Security Functions
        function generateQuantumKeys() {
            showToast('Generando nuevas claves cuánticas...', 'info');
            addActivity('Generador cuántico activado', 'info', 'fas fa-atom');
            
            setTimeout(() => {
                const newKeys = Math.floor(Math.random() * 512) + 256;
                updateMetric('quantumKeys', parseInt(document.getElementById('quantumKeys').textContent) + newKeys);
                
                showToast(`${newKeys} nuevas claves cuánticas generadas`, 'success');
                addActivity(`${newKeys} claves cuánticas añadidas al pool`, 'success', 'fas fa-key');
            }, 4000);
        }

        function quantumAnalysis() {
            showToast('Iniciando análisis cuántico profundo...', 'info');
            addActivity('Analizando entrelazamiento cuántico', 'info', 'fas fa-microscope');
            
            setTimeout(() => {
                const coherence = (Math.random() * 10 + 90).toFixed(1);
                const entanglement = (Math.random() * 15 + 80).toFixed(1);
                
                updateMetric('quantumCoherence', coherence + '%');
                updateMetric('quantumEntanglement', entanglement + '%');
                
                showToast('Análisis cuántico completado - Sistema estable', 'success');
                addActivity('Análisis cuántico: Estado coherente confirmado', 'success', 'fas fa-check-double');
            }, 5000);
        }

        // System Functions
        function optimizeSystem() {
            showToast('Optimizando rendimiento del sistema...', 'info');
            addActivity('Optimización inteligente iniciada', 'info', 'fas fa-cogs');
            
            setTimeout(() => {
                updateMetric('cpuUsage', Math.max(10, Math.floor(Math.random() * 30) + 15) + '%');
                updateMetric('ramUsage', Math.max(20, Math.floor(Math.random() * 40) + 30) + '%');
                
                showToast('Sistema optimizado - Rendimiento mejorado', 'success');
                addActivity('Optimización completada - Recursos liberados', 'success', 'fas fa-rocket');
            }, 3500);
        }

        function deepClean() {
            showToast('Iniciando limpieza profunda del sistema...', 'info');
            addActivity('Limpieza profunda en progreso', 'info', 'fas fa-broom');
            
            setTimeout(() => {
                const spaceCleaned = Math.floor(Math.random() * 5000) + 1000;
                updateMetric('diskUsage', Math.max(20, parseInt(document.getElementById('diskUsage').textContent.replace('%', '')) - 10) + '%');
                
                showToast(`Limpieza completada - ${spaceCleaned}MB liberados`, 'success');
                addActivity(`${spaceCleaned}MB de espacio liberado`, 'success', 'fas fa-check-circle');
            }, 4000);
        }

        function viewThreatMap() {
            showToast('Abriendo mapa global de amenazas...', 'info');
            addActivity('Cargando inteligencia de amenazas global', 'info', 'fas fa-map');
            // Here you would typically open a threat map interface
        }

        function activateShields() {
            showToast('Activando escudos de protección avanzada...', 'warning');
            addActivity('Escudos de protección activados', 'warning', 'fas fa-shield-alt');
            
            setTimeout(() => {
                showToast('Todos los escudos están activos', 'success');
                addActivity('Protección máxima activada', 'success', 'fas fa-lock');
            }, 2000);
        }

        function openAIChat() {
            showToast('Abriendo chat con asistente IA...', 'info');
            addActivity('Asistente IA preparado para conversar', 'info', 'fas fa-comments');
            // Here you would typically open the AI chat interface
        }

        function trainAI() {
            showToast('Iniciando sesión de entrenamiento de IA...', 'info');
            addActivity('Entrenamiento de IA iniciado', 'info', 'fas fa-graduation-cap');
            
            setTimeout(() => {
                updateMetric('aiLearning', Math.min(99, parseInt(document.getElementById('aiLearning').textContent.replace('%', '')) + Math.floor(Math.random() * 5) + 1) + '%');
                
                showToast('Entrenamiento completado - IA mejorada', 'success');
                addActivity('IA entrenada - Capacidades mejoradas', 'success', 'fas fa-brain');
            }, 6000);
        }

        // Auto-update metrics
        function autoUpdateMetrics() {
            // Simulate real-time metric updates
            setInterval(() => {
                // CPU usage fluctuation
                const cpuElement = document.getElementById('cpuUsage');
                const currentCpu = parseInt(cpuElement.textContent.replace('%', ''));
                const newCpu = Math.max(10, Math.min(90, currentCpu + (Math.random() - 0.5) * 10));
                cpuElement.textContent = Math.round(newCpu) + '%';
                
                // Network usage fluctuation
                const networkElement = document.getElementById('networkUsage');
                const currentNetwork = parseInt(networkElement.textContent.replace('%', ''));
                const newNetwork = Math.max(5, Math.min(95, currentNetwork + (Math.random() - 0.5) * 20));
                networkElement.textContent = Math.round(newNetwork) + '%';
                
                // VPN latency fluctuation
                const latencyElement = document.getElementById('vpnLatency');
                const currentLatency = parseInt(latencyElement.textContent.replace('ms', ''));
                const newLatency = Math.max(15, Math.min(200, currentLatency + (Math.random() - 0.5) * 10));
                latencyElement.textContent = Math.round(newLatency) + 'ms';
                
            }, 5000);
        }

        // Random activity generation
        function generateRandomActivity() {
            const activities = [
                { text: 'Escaneo de seguridad automático completado', type: 'success', icon: 'fas fa-check-circle' },
                { text: 'Actualización de firmas de IA recibida', type: 'info', icon: 'fas fa-download' },
                { text: 'Optimización de red aplicada', type: 'success', icon: 'fas fa-network-wired' },
                { text: 'Backup cuántico programado', type: 'info', icon: 'fas fa-save' },
                { text: 'Análisis predictivo ejecutado', type: 'info', icon: 'fas fa-chart-line' }
            ];
            
            setInterval(() => {
                if (Math.random() < 0.3) { // 30% chance every interval
                    const activity = activities[Math.floor(Math.random() * activities.length)];
                    addActivity(activity.text, activity.type, activity.icon);
                }
            }, 15000);
        }

        // Initialize everything when page loads
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            autoUpdateMetrics();
            generateRandomActivity();
            
            // Initial welcome message
            setTimeout(() => {
                showToast('GuardianIA v3.0 inicializado correctamente', 'success');
                addActivity('Sistema GuardianIA v3.0 completamente operativo', 'success', 'fas fa-power-off');
            }, 1000);
        });
    </script>
</body>
</html>

