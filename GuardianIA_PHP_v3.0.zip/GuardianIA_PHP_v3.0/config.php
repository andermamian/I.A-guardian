<?php
/**
 * GuardianIA - Configuración de Base de Datos
 * Sistema de Protección Inteligente Avanzada
 * Versión 2.0.0
 */

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '0987654321');
define('DB_NAME', 'guardianai_db');
define('DB_CHARSET', 'utf8mb4');

// Configuración de la aplicación
define('APP_NAME', 'GuardianIA');
define('APP_VERSION', '2.0.0');
define('APP_DEBUG', true);
define('APP_TIMEZONE', 'America/Mexico_City');

// Configuración de seguridad
define('SESSION_TIMEOUT', 3600); // 1 hora
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900); // 15 minutos

// Configuración de IA
define('AI_THREAT_THRESHOLD', 0.75); // Umbral de detección de amenazas
define('AI_LEARNING_RATE', 0.01);
define('AI_MAX_PATTERNS', 10000);
define('AI_ANALYSIS_TIMEOUT', 30); // segundos

// Configuración de optimización
define('PERFORMANCE_CHECK_INTERVAL', 300); // 5 minutos
define('CLEANUP_RETENTION_DAYS', 30);
define('MAX_LOG_SIZE', 10485760); // 10MB

try {
    // Establecer zona horaria
    date_default_timezone_set(APP_TIMEZONE);
    
    // Configuración de errores
    if (APP_DEBUG) {
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        ini_set('log_errors', 1);
        ini_set('error_log', __DIR__ . '/logs/error.log');
    } else {
        error_reporting(0);
        ini_set('display_errors', 0);
        ini_set('log_errors', 1);
        ini_set('error_log', __DIR__ . '/logs/error.log');
    }
    
    // Crear directorio de logs si no existe
    if (!file_exists(__DIR__ . '/logs')) {
        mkdir(__DIR__ . '/logs', 0755, true);
    }
    
    // Conexión a la base de datos
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Verificar conexión
    if ($conn->connect_error) {
        throw new Exception("Error de conexión a la base de datos: " . $conn->connect_error);
    }
    
    // Configurar charset
    $conn->set_charset(DB_CHARSET);
    
    // Configurar modo SQL
    $conn->query("SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
    
    // Log de conexión exitosa
    if (APP_DEBUG) {
        error_log("GuardianIA: Conexión a base de datos establecida exitosamente");
    }
    
} catch (Exception $e) {
    error_log("GuardianIA - Error crítico: " . $e->getMessage());
    
    if (APP_DEBUG) {
        die("Error de configuración: " . $e->getMessage());
    } else {
        die("Error del sistema. Por favor contacte al administrador.");
    }
}

/**
 * Función para registrar eventos del sistema
 */
function logGuardianEvent($level, $message, $context = []) {
    $timestamp = date('Y-m-d H:i:s');
    $context_str = !empty($context) ? json_encode($context) : '';
    $log_entry = "[{$timestamp}] [{$level}] {$message} {$context_str}" . PHP_EOL;
    
    file_put_contents(__DIR__ . '/logs/guardian.log', $log_entry, FILE_APPEND | LOCK_EX);
}

/**
 * Función para validar sesión de usuario
 */
function validateUserSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Verificar si existe sesión
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
        return false;
    }
    
    // Verificar timeout de sesión
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
        session_destroy();
        return false;
    }
    
    // Actualizar última actividad
    $_SESSION['last_activity'] = time();
    
    return true;
}

/**
 * Función para verificar permisos de administrador
 */
function requireAdminAccess() {
    if (!validateUserSession() || $_SESSION['user_role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Acceso denegado']);
        exit;
    }
}

/**
 * Función para sanitizar entrada de datos
 */
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    
    return $data;
}

/**
 * Función para generar respuesta JSON estándar
 */
function jsonResponse($success, $message, $data = null, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    
    $response = [
        'success' => $success,
        'message' => $message,
        'timestamp' => date('c'),
        'version' => APP_VERSION
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Función para calcular hash de contraseña
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_ARGON2ID, [
        'memory_cost' => 65536, // 64 MB
        'time_cost' => 4,       // 4 iteraciones
        'threads' => 3          // 3 hilos
    ]);
}

/**
 * Función para verificar contraseña
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Función para generar token seguro
 */
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Función para validar email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Función para validar IP
 */
function validateIP($ip) {
    return filter_var($ip, FILTER_VALIDATE_IP) !== false;
}

/**
 * Función para obtener IP del cliente
 */
function getClientIP() {
    $ip_keys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
    
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (validateIP($ip)) {
                    return $ip;
                }
            }
        }
    }
    
    return '0.0.0.0';
}

/**
 * Función para rate limiting
 */
function checkRateLimit($identifier, $max_requests = 100, $time_window = 3600) {
    $cache_file = __DIR__ . '/cache/rate_limit_' . md5($identifier) . '.json';
    
    if (!file_exists(dirname($cache_file))) {
        mkdir(dirname($cache_file), 0755, true);
    }
    
    $current_time = time();
    $requests = [];
    
    if (file_exists($cache_file)) {
        $data = json_decode(file_get_contents($cache_file), true);
        if ($data && isset($data['requests'])) {
            $requests = $data['requests'];
        }
    }
    
    // Filtrar requests dentro de la ventana de tiempo
    $requests = array_filter($requests, function($timestamp) use ($current_time, $time_window) {
        return ($current_time - $timestamp) < $time_window;
    });
    
    // Verificar límite
    if (count($requests) >= $max_requests) {
        return false;
    }
    
    // Agregar request actual
    $requests[] = $current_time;
    
    // Guardar en cache
    file_put_contents($cache_file, json_encode(['requests' => $requests]), LOCK_EX);
    
    return true;
}

// Configuración de headers de seguridad
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    if (!APP_DEBUG) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

// Log de inicialización
logGuardianEvent('INFO', 'GuardianIA sistema inicializado', [
    'version' => APP_VERSION,
    'php_version' => PHP_VERSION,
    'memory_limit' => ini_get('memory_limit'),
    'max_execution_time' => ini_get('max_execution_time')
]);

?>

