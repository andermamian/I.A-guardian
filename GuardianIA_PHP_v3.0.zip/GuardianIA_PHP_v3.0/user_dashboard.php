<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Seguridad - GuardianIA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --warning-gradient: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(102, 126, 234, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(118, 75, 162, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(67, 233, 123, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        /* Navigation */
        .navbar {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .nav-link:hover {
            color: var(--text-primary);
            background: rgba(255, 255, 255, 0.1);
        }

        .nav-link.active {
            background: var(--primary-gradient);
            color: white;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        /* Main Container */
        .main-container {
            margin-top: 80px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Welcome Header */
        .welcome-header {
            background: var(--primary-gradient);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .welcome-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            animation: welcomeShine 4s infinite;
        }

        @keyframes welcomeShine {
            0% { left: -100%; }
            100% { left: 100%; }
        }

        .welcome-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .welcome-subtitle {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 1.5rem;
        }

        .protection-status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            font-weight: 600;
            color: white;
        }

        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #2ed573;
            animation: statusPulse 2s infinite;
        }

        @keyframes statusPulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* Quick Stats */
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            position: relative;
            overflow: hidden;
            transition: all var(--animation-speed) ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px var(--shadow-color);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
        }

        .stat-card.security::before {
            background: var(--success-gradient);
        }

        .stat-card.performance::before {
            background: var(--info-gradient);
        }

        .stat-card.threats::before {
            background: var(--danger-gradient);
        }

        .stat-card.optimization::before {
            background: var(--warning-gradient);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .stat-trend {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }

        .trend-up {
            color: #2ed573;
        }

        .trend-down {
            color: #ff4757;
        }

        /* Action Cards */
        .action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .action-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            transition: all var(--animation-speed) ease;
        }

        .action-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px var(--shadow-color);
        }

        .action-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .action-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }

        .action-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .action-description {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .action-button {
            width: 100%;
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        .action-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .action-button.success {
            background: var(--success-gradient);
        }

        .action-button.warning {
            background: var(--warning-gradient);
        }

        .action-button.info {
            background: var(--info-gradient);
        }

        /* Recent Activity */
        .recent-activity {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            margin-bottom: 2rem;
        }

        .activity-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .activity-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            margin-bottom: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .activity-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            color: white;
        }

        .activity-content {
            flex: 1;
        }

        .activity-text {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .activity-time {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        /* System Health */
        .system-health {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .health-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
        }

        .health-metric {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .health-metric:last-child {
            border-bottom: none;
        }

        .metric-name {
            font-weight: 600;
        }

        .metric-value {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .metric-bar {
            width: 100px;
            height: 6px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 3px;
            overflow: hidden;
        }

        .metric-fill {
            height: 100%;
            border-radius: 3px;
            transition: width 1s ease;
        }

        .metric-fill.good {
            background: var(--success-gradient);
        }

        .metric-fill.warning {
            background: var(--warning-gradient);
        }

        .metric-fill.danger {
            background: var(--danger-gradient);
        }

        /* Quick Actions */
        .quick-actions {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
            z-index: 1000;
        }

        .quick-action-btn {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }

        .quick-action-btn:hover {
            transform: scale(1.1);
        }

        .quick-action-btn.scan {
            background: var(--success-gradient);
        }

        .quick-action-btn.optimize {
            background: var(--info-gradient);
        }

        .quick-action-btn.chat {
            background: var(--primary-gradient);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .system-health {
                grid-template-columns: 1fr;
            }

            .action-grid {
                grid-template-columns: 1fr;
            }

            .quick-stats {
                grid-template-columns: 1fr;
            }

            .welcome-title {
                font-size: 2rem;
            }

            .main-container {
                padding: 1rem;
            }

            .quick-actions {
                bottom: 1rem;
                right: 1rem;
            }
        }

        /* Loading States */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            top: 100px;
            right: 2rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem 1.5rem;
            color: var(--text-primary);
            box-shadow: 0 8px 25px var(--shadow-color);
            transform: translateX(400px);
            transition: transform var(--animation-speed) ease;
            z-index: 1001;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #2ed573;
        }

        .toast.error {
            border-left: 4px solid #ff4757;
        }

        .toast.warning {
            border-left: 4px solid #ffa502;
        }

        .toast.info {
            border-left: 4px solid #4facfe;
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <span>GuardianIA</span>
            </div>
            <ul class="nav-menu">
                <li><a href="#" class="nav-link active">Mi Seguridad</a></li>
                <li><a href="user_security.php" class="nav-link">Protección</a></li>
                <li><a href="user_performance.php" class="nav-link">Optimización</a></li>
                <li><a href="user_assistant.php" class="nav-link">Asistente IA</a></li>
                <li><a href="user_settings.php" class="nav-link">Configuración</a></li>
            </ul>
            <div class="user-profile">
                <div class="user-avatar">JD</div>
                <span>Juan Pérez</span>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Welcome Header -->
        <div class="welcome-header">
            <h1 class="welcome-title">¡Bienvenido de vuelta, Juan!</h1>
            <p class="welcome-subtitle">
                Tu sistema está protegido y funcionando óptimamente
            </p>
            <div class="protection-status">
                <div class="status-indicator"></div>
                <span>Protección Activa</span>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="stat-card security">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" style="color: #2ed573;">100%</div>
                        <div class="stat-label">Nivel de Seguridad</div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-arrow-up"></i>
                            <span>+5% esta semana</span>
                        </div>
                    </div>
                    <div class="stat-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-shield-check"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card performance">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" style="color: #4facfe;">94</div>
                        <div class="stat-label">Score de Rendimiento</div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-arrow-up"></i>
                            <span>+12 puntos hoy</span>
                        </div>
                    </div>
                    <div class="stat-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card threats">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" style="color: #ff4757;">0</div>
                        <div class="stat-label">Amenazas Activas</div>
                        <div class="stat-trend trend-down">
                            <i class="fas fa-arrow-down"></i>
                            <span>-3 desde ayer</span>
                        </div>
                    </div>
                    <div class="stat-icon" style="background: var(--danger-gradient);">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card optimization">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" style="color: #ffa726;">2.4 GB</div>
                        <div class="stat-label">Espacio Liberado</div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-arrow-up"></i>
                            <span>Hoy</span>
                        </div>
                    </div>
                    <div class="stat-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-broom"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Cards -->
        <div class="action-grid">
            <div class="action-card">
                <div class="action-header">
                    <div class="action-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-search"></i>
                    </div>
                    <div>
                        <div class="action-title">Escaneo Rápido</div>
                        <div class="action-description">
                            Analiza tu sistema en busca de amenazas en menos de 2 minutos
                        </div>
                    </div>
                </div>
                <button class="action-button success" onclick="quickScan()">
                    <i class="fas fa-play"></i>
                    Iniciar Escaneo
                </button>
            </div>

            <div class="action-card">
                <div class="action-header">
                    <div class="action-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-magic"></i>
                    </div>
                    <div>
                        <div class="action-title">Optimización Automática</div>
                        <div class="action-description">
                            Mejora el rendimiento de tu sistema con un solo clic
                        </div>
                    </div>
                </div>
                <button class="action-button info" onclick="autoOptimize()">
                    <i class="fas fa-bolt"></i>
                    Optimizar Ahora
                </button>
            </div>

            <div class="action-card">
                <div class="action-header">
                    <div class="action-icon" style="background: var(--primary-gradient);">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div>
                        <div class="action-title">Asistente IA</div>
                        <div class="action-description">
                            Pregunta cualquier cosa sobre la seguridad de tu sistema
                        </div>
                    </div>
                </div>
                <button class="action-button" onclick="openAssistant()">
                    <i class="fas fa-comments"></i>
                    Hablar con IA
                </button>
            </div>

            <div class="action-card">
                <div class="action-header">
                    <div class="action-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-cog"></i>
                    </div>
                    <div>
                        <div class="action-title">Configuración Inteligente</div>
                        <div class="action-description">
                            Ajusta la protección según tus necesidades específicas
                        </div>
                    </div>
                </div>
                <button class="action-button warning" onclick="smartConfig()">
                    <i class="fas fa-sliders-h"></i>
                    Configurar
                </button>
            </div>
        </div>

        <!-- System Health -->
        <div class="system-health">
            <div class="health-card">
                <div class="activity-header">
                    <h2 class="activity-title">Estado del Sistema</h2>
                    <i class="fas fa-heartbeat" style="color: #2ed573;"></i>
                </div>
                
                <div class="health-metric">
                    <span class="metric-name">CPU</span>
                    <div class="metric-value">
                        <div class="metric-bar">
                            <div class="metric-fill good" style="width: 45%"></div>
                        </div>
                        <span>45%</span>
                    </div>
                </div>

                <div class="health-metric">
                    <span class="metric-name">Memoria RAM</span>
                    <div class="metric-value">
                        <div class="metric-bar">
                            <div class="metric-fill warning" style="width: 67%"></div>
                        </div>
                        <span>67%</span>
                    </div>
                </div>

                <div class="health-metric">
                    <span class="metric-name">Almacenamiento</span>
                    <div class="metric-value">
                        <div class="metric-bar">
                            <div class="metric-fill warning" style="width: 78%"></div>
                        </div>
                        <span>78%</span>
                    </div>
                </div>

                <div class="health-metric">
                    <span class="metric-name">Batería</span>
                    <div class="metric-value">
                        <div class="metric-bar">
                            <div class="metric-fill good" style="width: 89%"></div>
                        </div>
                        <span>89%</span>
                    </div>
                </div>

                <div class="health-metric">
                    <span class="metric-name">Temperatura</span>
                    <div class="metric-value">
                        <div class="metric-bar">
                            <div class="metric-fill good" style="width: 42%"></div>
                        </div>
                        <span>42°C</span>
                    </div>
                </div>
            </div>

            <div class="health-card">
                <div class="activity-header">
                    <h2 class="activity-title">Actividad Reciente</h2>
                    <i class="fas fa-clock" style="color: #4facfe;"></i>
                </div>

                <div class="activity-item">
                    <div class="activity-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-shield-check"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-text">Escaneo completo finalizado</div>
                        <div class="activity-time">Hace 2 horas - Sin amenazas detectadas</div>
                    </div>
                </div>

                <div class="activity-item">
                    <div class="activity-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-broom"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-text">Optimización automática</div>
                        <div class="activity-time">Hace 4 horas - 1.8 GB liberados</div>
                    </div>
                </div>

                <div class="activity-item">
                    <div class="activity-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-download"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-text">Definiciones actualizadas</div>
                        <div class="activity-time">Hace 6 horas - 1,247 nuevas firmas</div>
                    </div>
                </div>

                <div class="activity-item">
                    <div class="activity-icon" style="background: var(--primary-gradient);">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-text">Consulta al asistente IA</div>
                        <div class="activity-time">Ayer - "¿Cómo optimizar la batería?"</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
        <button class="quick-action-btn scan" onclick="quickScan()" title="Escaneo Rápido">
            <i class="fas fa-search"></i>
        </button>
        <button class="quick-action-btn optimize" onclick="autoOptimize()" title="Optimización Rápida">
            <i class="fas fa-bolt"></i>
        </button>
        <button class="quick-action-btn chat" onclick="openAssistant()" title="Asistente IA">
            <i class="fas fa-robot"></i>
        </button>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <span id="toast-message"></span>
    </div>

    <script>
        // Variables globales
        let updateInterval;
        let isScanning = false;
        let isOptimizing = false;

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            initializeDashboard();
            startRealTimeUpdates();
            loadUserPreferences();
        });

        // Inicializar dashboard
        function initializeDashboard() {
            updateSystemMetrics();
            loadRecentActivity();
            checkSystemHealth();
            showWelcomeMessage();
        }

        // Mostrar mensaje de bienvenida
        function showWelcomeMessage() {
            const hour = new Date().getHours();
            let greeting = 'Buenos días';
            
            if (hour >= 12 && hour < 18) {
                greeting = 'Buenas tardes';
            } else if (hour >= 18) {
                greeting = 'Buenas noches';
            }
            
            setTimeout(() => {
                showToast(`${greeting}, Juan! Tu sistema está protegido y funcionando óptimamente.`, 'success');
            }, 1000);
        }

        // Actualizar métricas del sistema
        function updateSystemMetrics() {
            // Simular actualización de métricas en tiempo real
            const metrics = {
                security: Math.floor(Math.random() * 5) + 95,
                performance: Math.floor(Math.random() * 10) + 90,
                threats: Math.floor(Math.random() * 3),
                optimized: (Math.random() * 2 + 1).toFixed(1)
            };

            // Actualizar valores en la interfaz
            document.querySelector('.stat-card.security .stat-value').textContent = metrics.security + '%';
            document.querySelector('.stat-card.performance .stat-value').textContent = metrics.performance;
            document.querySelector('.stat-card.threats .stat-value').textContent = metrics.threats;
            document.querySelector('.stat-card.optimization .stat-value').textContent = metrics.optimized + ' GB';

            // Actualizar barras de salud del sistema
            updateHealthBars();
        }

        // Actualizar barras de salud
        function updateHealthBars() {
            const healthMetrics = {
                cpu: Math.floor(Math.random() * 30) + 30,
                ram: Math.floor(Math.random() * 40) + 50,
                storage: Math.floor(Math.random() * 20) + 70,
                battery: Math.floor(Math.random() * 20) + 80,
                temperature: Math.floor(Math.random() * 20) + 35
            };

            const healthBars = document.querySelectorAll('.metric-fill');
            const healthValues = document.querySelectorAll('.metric-value span');

            healthBars[0].style.width = healthMetrics.cpu + '%';
            healthBars[1].style.width = healthMetrics.ram + '%';
            healthBars[2].style.width = healthMetrics.storage + '%';
            healthBars[3].style.width = healthMetrics.battery + '%';
            healthBars[4].style.width = (healthMetrics.temperature / 100 * 100) + '%';

            healthValues[0].textContent = healthMetrics.cpu + '%';
            healthValues[1].textContent = healthMetrics.ram + '%';
            healthValues[2].textContent = healthMetrics.storage + '%';
            healthValues[3].textContent = healthMetrics.battery + '%';
            healthValues[4].textContent = healthMetrics.temperature + '°C';

            // Actualizar clases de color según el valor
            healthBars.forEach((bar, index) => {
                const value = Object.values(healthMetrics)[index];
                bar.className = 'metric-fill';
                
                if (value < 50) {
                    bar.classList.add('good');
                } else if (value < 80) {
                    bar.classList.add('warning');
                } else {
                    bar.classList.add('danger');
                }
            });
        }

        // Iniciar actualizaciones en tiempo real
        function startRealTimeUpdates() {
            updateInterval = setInterval(() => {
                updateSystemMetrics();
                updateProtectionStatus();
            }, 10000); // Actualizar cada 10 segundos
        }

        // Actualizar estado de protección
        function updateProtectionStatus() {
            const statusIndicator = document.querySelector('.status-indicator');
            const protectionStatus = document.querySelector('.protection-status span');
            
            // Simular cambios de estado ocasionales
            if (Math.random() < 0.1) { // 10% de probabilidad
                statusIndicator.style.background = '#ffa502';
                protectionStatus.textContent = 'Actualizando...';
                
                setTimeout(() => {
                    statusIndicator.style.background = '#2ed573';
                    protectionStatus.textContent = 'Protección Activa';
                }, 3000);
            }
        }

        // Escaneo rápido
        function quickScan() {
            if (isScanning) {
                showToast('Ya hay un escaneo en progreso...', 'warning');
                return;
            }

            isScanning = true;
            const scanButton = document.querySelector('.action-button.success');
            const originalText = scanButton.innerHTML;
            
            scanButton.innerHTML = '<div class="loading"></div> Escaneando...';
            scanButton.disabled = true;

            showToast('Iniciando escaneo rápido del sistema...', 'info');

            // Simular proceso de escaneo
            setTimeout(() => {
                showToast('Escaneo completado. No se encontraron amenazas.', 'success');
                addActivityItem('Escaneo rápido completado', 'Ahora - Sistema limpio', 'fas fa-shield-check', 'var(--success-gradient)');
                
                scanButton.innerHTML = originalText;
                scanButton.disabled = false;
                isScanning = false;
                
                // Actualizar métricas
                updateSystemMetrics();
            }, 5000);
        }

        // Optimización automática
        function autoOptimize() {
            if (isOptimizing) {
                showToast('Ya hay una optimización en progreso...', 'warning');
                return;
            }

            isOptimizing = true;
            const optimizeButton = document.querySelector('.action-button.info');
            const originalText = optimizeButton.innerHTML;
            
            optimizeButton.innerHTML = '<div class="loading"></div> Optimizando...';
            optimizeButton.disabled = true;

            showToast('Iniciando optimización automática del sistema...', 'info');

            // Simular proceso de optimización
            const steps = [
                'Analizando sistema...',
                'Limpiando archivos temporales...',
                'Optimizando memoria RAM...',
                'Configurando energía...',
                'Finalizando optimización...'
            ];

            let currentStep = 0;
            const stepInterval = setInterval(() => {
                if (currentStep < steps.length) {
                    showToast(steps[currentStep], 'info');
                    currentStep++;
                } else {
                    clearInterval(stepInterval);
                    
                    showToast('Optimización completada. Rendimiento mejorado en 18%.', 'success');
                    addActivityItem('Optimización automática', 'Ahora - 2.4 GB liberados', 'fas fa-magic', 'var(--info-gradient)');
                    
                    optimizeButton.innerHTML = originalText;
                    optimizeButton.disabled = false;
                    isOptimizing = false;
                    
                    // Actualizar métricas
                    updateSystemMetrics();
                }
            }, 2000);
        }

        // Abrir asistente IA
        function openAssistant() {
            showToast('Abriendo asistente IA...', 'info');
            setTimeout(() => {
                window.location.href = 'user_assistant.php';
            }, 1000);
        }

        // Configuración inteligente
        function smartConfig() {
            showToast('Abriendo configuración inteligente...', 'info');
            setTimeout(() => {
                window.location.href = 'user_settings.php';
            }, 1000);
        }

        // Agregar elemento a actividad reciente
        function addActivityItem(title, time, icon, color) {
            const activityContainer = document.querySelector('.health-card:last-child');
            const newActivity = document.createElement('div');
            newActivity.className = 'activity-item';
            newActivity.style.animation = 'fadeIn 0.5s ease';
            
            newActivity.innerHTML = `
                <div class="activity-icon" style="background: ${color};">
                    <i class="${icon}"></i>
                </div>
                <div class="activity-content">
                    <div class="activity-text">${title}</div>
                    <div class="activity-time">${time}</div>
                </div>
            `;
            
            // Insertar al principio de la lista
            const firstActivity = activityContainer.querySelector('.activity-item');
            if (firstActivity) {
                activityContainer.insertBefore(newActivity, firstActivity);
            } else {
                activityContainer.appendChild(newActivity);
            }
            
            // Mantener solo los últimos 4 elementos
            const activities = activityContainer.querySelectorAll('.activity-item');
            if (activities.length > 4) {
                activityContainer.removeChild(activities[activities.length - 1]);
            }
        }

        // Cargar actividad reciente
        function loadRecentActivity() {
            // La actividad ya está cargada en el HTML
            console.log('Actividad reciente cargada');
        }

        // Verificar salud del sistema
        function checkSystemHealth() {
            // Simular verificación de salud
            console.log('Verificando salud del sistema...');
        }

        // Cargar preferencias del usuario
        function loadUserPreferences() {
            // Simular carga de preferencias
            console.log('Cargando preferencias del usuario...');
        }

        // Mostrar notificación toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type}`;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 4000);
        }

        // Efectos de hover para las tarjetas
        document.querySelectorAll('.stat-card, .action-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Animación de entrada para las tarjetas
        function initializeAnimations() {
            const cards = document.querySelectorAll('.stat-card, .action-card, .health-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        }

        // Manejo de errores
        window.addEventListener('error', function(e) {
            console.log('Error capturado:', e.message);
            showToast('Se produjo un error. Reintentando...', 'error');
        });

        // Cleanup al salir
        window.addEventListener('beforeunload', function() {
            if (updateInterval) {
                clearInterval(updateInterval);
            }
        });

        // Inicializar animaciones después de cargar
        setTimeout(initializeAnimations, 500);

        // Funciones de utilidad
        function formatTime(date) {
            return date.toLocaleTimeString('es-ES', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
        }

        function formatDate(date) {
            return date.toLocaleDateString('es-ES', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        }

        // Detectar cambios de rendimiento
        function detectPerformanceChanges() {
            // Simular detección de cambios
            const changes = [
                'Mejora en velocidad de CPU detectada',
                'Optimización de memoria completada',
                'Reducción en consumo de batería',
                'Limpieza de archivos temporales exitosa'
            ];
            
            const randomChange = changes[Math.floor(Math.random() * changes.length)];
            return randomChange;
        }

        // Notificaciones push simuladas
        function simulatePushNotifications() {
            setInterval(() => {
                if (Math.random() < 0.1) { // 10% de probabilidad cada minuto
                    const notifications = [
                        'Definiciones de virus actualizadas',
                        'Optimización programada completada',
                        'Nuevo reporte de seguridad disponible',
                        'Recomendación de IA: Reiniciar el sistema'
                    ];
                    
                    const randomNotification = notifications[Math.floor(Math.random() * notifications.length)];
                    showToast(randomNotification, 'info');
                }
            }, 60000); // Cada minuto
        }

        // Iniciar notificaciones simuladas
        setTimeout(simulatePushNotifications, 30000); // Después de 30 segundos
    </script>
</body>
</html>

