<?php
require_once 'config.php';

// Procesar solicitudes AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'update_security_settings':
            $user_id = $_POST['user_id'] ?? 1;
            $settings = [
                'real_time_protection' => $_POST['real_time_protection'] ?? 0,
                'auto_scan' => $_POST['auto_scan'] ?? 0,
                'firewall_enabled' => $_POST['firewall_enabled'] ?? 0,
                'threat_notifications' => $_POST['threat_notifications'] ?? 0,
                'scan_frequency' => $_POST['scan_frequency'] ?? 'daily',
                'quarantine_auto' => $_POST['quarantine_auto'] ?? 0
            ];
            
            $result = updateUserSettings($conn, $user_id, 'security', $settings);
            echo json_encode($result);
            exit;
            
        case 'update_performance_settings':
            $user_id = $_POST['user_id'] ?? 1;
            $settings = [
                'auto_optimization' => $_POST['auto_optimization'] ?? 0,
                'ram_optimization' => $_POST['ram_optimization'] ?? 0,
                'storage_cleanup' => $_POST['storage_cleanup'] ?? 0,
                'battery_optimization' => $_POST['battery_optimization'] ?? 0,
                'optimization_schedule' => $_POST['optimization_schedule'] ?? 'daily',
                'performance_mode' => $_POST['performance_mode'] ?? 'balanced'
            ];
            
            $result = updateUserSettings($conn, $user_id, 'performance', $settings);
            echo json_encode($result);
            exit;
            
        case 'update_notification_settings':
            $user_id = $_POST['user_id'] ?? 1;
            $settings = [
                'email_notifications' => $_POST['email_notifications'] ?? 0,
                'push_notifications' => $_POST['push_notifications'] ?? 0,
                'sound_alerts' => $_POST['sound_alerts'] ?? 0,
                'threat_alerts' => $_POST['threat_alerts'] ?? 0,
                'optimization_alerts' => $_POST['optimization_alerts'] ?? 0,
                'system_updates' => $_POST['system_updates'] ?? 0
            ];
            
            $result = updateUserSettings($conn, $user_id, 'notifications', $settings);
            echo json_encode($result);
            exit;
            
        case 'update_privacy_settings':
            $user_id = $_POST['user_id'] ?? 1;
            $settings = [
                'data_collection' => $_POST['data_collection'] ?? 0,
                'analytics_sharing' => $_POST['analytics_sharing'] ?? 0,
                'crash_reports' => $_POST['crash_reports'] ?? 0,
                'usage_statistics' => $_POST['usage_statistics'] ?? 0,
                'location_tracking' => $_POST['location_tracking'] ?? 0,
                'third_party_sharing' => $_POST['third_party_sharing'] ?? 0
            ];
            
            $result = updateUserSettings($conn, $user_id, 'privacy', $settings);
            echo json_encode($result);
            exit;
            
        case 'update_profile':
            $user_id = $_POST['user_id'] ?? 1;
            $profile_data = [
                'full_name' => $_POST['full_name'] ?? '',
                'email' => $_POST['email'] ?? '',
                'phone' => $_POST['phone'] ?? '',
                'language' => $_POST['language'] ?? 'es',
                'timezone' => $_POST['timezone'] ?? 'America/Mexico_City',
                'theme' => $_POST['theme'] ?? 'dark'
            ];
            
            $result = updateUserProfile($conn, $user_id, $profile_data);
            echo json_encode($result);
            exit;
            
        case 'change_password':
            $user_id = $_POST['user_id'] ?? 1;
            $current_password = $_POST['current_password'] ?? '';
            $new_password = $_POST['new_password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            $result = changeUserPassword($conn, $user_id, $current_password, $new_password, $confirm_password);
            echo json_encode($result);
            exit;
            
        case 'export_data':
            $user_id = $_POST['user_id'] ?? 1;
            $result = exportUserData($conn, $user_id);
            echo json_encode($result);
            exit;
            
        case 'delete_account':
            $user_id = $_POST['user_id'] ?? 1;
            $password = $_POST['password'] ?? '';
            $result = deleteUserAccount($conn, $user_id, $password);
            echo json_encode($result);
            exit;
    }
}

// Funciones auxiliares
function updateUserSettings($conn, $user_id, $category, $settings) {
    try {
        $settings_json = json_encode($settings);
        
        $stmt = $conn->prepare("
            INSERT INTO user_settings (user_id, category, settings, updated_at) 
            VALUES (?, ?, ?, NOW()) 
            ON DUPLICATE KEY UPDATE 
            settings = VALUES(settings), 
            updated_at = VALUES(updated_at)
        ");
        
        $stmt->bind_param("iss", $user_id, $category, $settings_json);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Configuración actualizada correctamente'];
        } else {
            return ['success' => false, 'error' => 'Error al actualizar configuración'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()];
    }
}

function updateUserProfile($conn, $user_id, $profile_data) {
    try {
        $stmt = $conn->prepare("
            UPDATE users SET 
            full_name = ?, 
            email = ?, 
            phone = ?, 
            language = ?, 
            timezone = ?, 
            theme = ?, 
            updated_at = NOW() 
            WHERE id = ?
        ");
        
        $stmt->bind_param("ssssssi", 
            $profile_data['full_name'],
            $profile_data['email'],
            $profile_data['phone'],
            $profile_data['language'],
            $profile_data['timezone'],
            $profile_data['theme'],
            $user_id
        );
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Perfil actualizado correctamente'];
        } else {
            return ['success' => false, 'error' => 'Error al actualizar perfil'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()];
    }
}

function changeUserPassword($conn, $user_id, $current_password, $new_password, $confirm_password) {
    try {
        // Validar que las contraseñas coincidan
        if ($new_password !== $confirm_password) {
            return ['success' => false, 'error' => 'Las contraseñas no coinciden'];
        }
        
        // Validar longitud de contraseña
        if (strlen($new_password) < 8) {
            return ['success' => false, 'error' => 'La contraseña debe tener al menos 8 caracteres'];
        }
        
        // Verificar contraseña actual
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (!$user || !password_verify($current_password, $user['password'])) {
            return ['success' => false, 'error' => 'Contraseña actual incorrecta'];
        }
        
        // Actualizar contraseña
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $user_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Contraseña actualizada correctamente'];
        } else {
            return ['success' => false, 'error' => 'Error al actualizar contraseña'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()];
    }
}

function exportUserData($conn, $user_id) {
    try {
        // Obtener datos del usuario
        $user_data = [];
        
        // Datos del perfil
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user_data['profile'] = $stmt->get_result()->fetch_assoc();
        
        // Configuraciones
        $stmt = $conn->prepare("SELECT * FROM user_settings WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user_data['settings'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Conversaciones del chatbot
        $stmt = $conn->prepare("SELECT * FROM chatbot_conversations WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user_data['conversations'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Crear archivo de exportación
        $export_data = json_encode($user_data, JSON_PRETTY_PRINT);
        $filename = "guardian_ia_export_user_{$user_id}_" . date('Y-m-d_H-i-s') . ".json";
        
        return [
            'success' => true, 
            'message' => 'Datos exportados correctamente',
            'data' => $export_data,
            'filename' => $filename
        ];
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error al exportar datos: ' . $e->getMessage()];
    }
}

function deleteUserAccount($conn, $user_id, $password) {
    try {
        // Verificar contraseña
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if (!$user || !password_verify($password, $user['password'])) {
            return ['success' => false, 'error' => 'Contraseña incorrecta'];
        }
        
        // Eliminar datos relacionados
        $conn->begin_transaction();
        
        try {
            // Eliminar configuraciones
            $stmt = $conn->prepare("DELETE FROM user_settings WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            
            // Eliminar conversaciones del chatbot
            $stmt = $conn->prepare("DELETE FROM chatbot_conversations WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            
            // Eliminar mensajes del chatbot
            $stmt = $conn->prepare("DELETE FROM chatbot_messages WHERE conversation_id IN (SELECT id FROM chatbot_conversations WHERE user_id = ?)");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            
            // Eliminar usuario
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            
            $conn->commit();
            
            return ['success' => true, 'message' => 'Cuenta eliminada correctamente'];
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Error al eliminar cuenta: ' . $e->getMessage()];
    }
}

// Obtener configuraciones actuales del usuario
$user_id = 1; // En un sistema real, esto vendría de la sesión

// Obtener configuraciones de seguridad
$security_settings = getUserSettings($conn, $user_id, 'security');
$performance_settings = getUserSettings($conn, $user_id, 'performance');
$notification_settings = getUserSettings($conn, $user_id, 'notifications');
$privacy_settings = getUserSettings($conn, $user_id, 'privacy');

// Obtener datos del perfil
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_profile = $stmt->get_result()->fetch_assoc();

function getUserSettings($conn, $user_id, $category) {
    $stmt = $conn->prepare("SELECT settings FROM user_settings WHERE user_id = ? AND category = ?");
    $stmt->bind_param("is", $user_id, $category);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return json_decode($row['settings'], true);
    }
    
    // Configuraciones por defecto
    $defaults = [
        'security' => [
            'real_time_protection' => 1,
            'auto_scan' => 1,
            'firewall_enabled' => 1,
            'threat_notifications' => 1,
            'scan_frequency' => 'daily',
            'quarantine_auto' => 1
        ],
        'performance' => [
            'auto_optimization' => 1,
            'ram_optimization' => 1,
            'storage_cleanup' => 1,
            'battery_optimization' => 1,
            'optimization_schedule' => 'daily',
            'performance_mode' => 'balanced'
        ],
        'notifications' => [
            'email_notifications' => 1,
            'push_notifications' => 1,
            'sound_alerts' => 1,
            'threat_alerts' => 1,
            'optimization_alerts' => 1,
            'system_updates' => 1
        ],
        'privacy' => [
            'data_collection' => 0,
            'analytics_sharing' => 0,
            'crash_reports' => 1,
            'usage_statistics' => 0,
            'location_tracking' => 0,
            'third_party_sharing' => 0
        ]
    ];
    
    return $defaults[$category] ?? [];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Configuración - GuardianIA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --warning-gradient: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(102, 126, 234, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(118, 75, 162, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(67, 233, 123, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        /* Navigation */
        .navbar {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .nav-link:hover {
            color: var(--text-primary);
            background: rgba(255, 255, 255, 0.1);
        }

        .nav-link.active {
            background: var(--warning-gradient);
            color: white;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        /* Main Container */
        .main-container {
            margin-top: 80px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 2rem;
        }

        /* Settings Sidebar */
        .settings-sidebar {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--text-primary);
        }

        .settings-menu {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            text-decoration: none;
            color: var(--text-secondary);
        }

        .menu-item:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .menu-item.active {
            background: var(--primary-gradient);
            color: white;
        }

        .menu-icon {
            width: 20px;
            text-align: center;
        }

        /* Settings Content */
        .settings-content {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
        }

        .settings-section {
            display: none;
        }

        .settings-section.active {
            display: block;
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .section-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }

        .section-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .section-description {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Settings Groups */
        .settings-group {
            margin-bottom: 2rem;
        }

        .group-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--text-primary);
        }

        .setting-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            margin-bottom: 0.5rem;
        }

        .setting-info {
            flex: 1;
        }

        .setting-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .setting-description {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        /* Toggle Switch */
        .toggle-switch {
            position: relative;
            width: 60px;
            height: 30px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
        }

        .toggle-switch.active {
            background: var(--success-gradient);
        }

        .toggle-slider {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 24px;
            height: 24px;
            background: white;
            border-radius: 50%;
            transition: all var(--animation-speed) ease;
        }

        .toggle-switch.active .toggle-slider {
            transform: translateX(30px);
        }

        /* Select Dropdown */
        .setting-select {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 0.5rem 1rem;
            color: var(--text-primary);
            font-family: inherit;
            cursor: pointer;
            min-width: 150px;
        }

        .setting-select:focus {
            outline: none;
            border-color: var(--primary-gradient);
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        .form-input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1rem;
            color: var(--text-primary);
            font-family: inherit;
            transition: all var(--animation-speed) ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-gradient);
            background: rgba(255, 255, 255, 0.1);
        }

        .form-input::placeholder {
            color: var(--text-secondary);
        }

        /* Buttons */
        .btn {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .btn.success {
            background: var(--success-gradient);
        }

        .btn.warning {
            background: var(--warning-gradient);
        }

        .btn.danger {
            background: var(--danger-gradient);
        }

        .btn.secondary {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--border-color);
        }

        /* Danger Zone */
        .danger-zone {
            background: rgba(250, 112, 154, 0.1);
            border: 1px solid rgba(250, 112, 154, 0.3);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            margin-top: 2rem;
        }

        .danger-title {
            color: #fa709a;
            font-weight: 700;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .danger-description {
            color: var(--text-secondary);
            margin-bottom: 1.5rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .main-container {
                grid-template-columns: 1fr;
                padding: 1rem;
            }

            .settings-sidebar {
                position: static;
                margin-bottom: 1rem;
            }

            .settings-menu {
                flex-direction: row;
                overflow-x: auto;
                gap: 0.5rem;
            }

            .menu-item {
                min-width: 120px;
                justify-content: center;
            }

            .menu-text {
                display: none;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            top: 100px;
            right: 2rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem 1.5rem;
            color: var(--text-primary);
            box-shadow: 0 8px 25px var(--shadow-color);
            transform: translateX(400px);
            transition: transform var(--animation-speed) ease;
            z-index: 1001;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #2ed573;
        }

        .toast.error {
            border-left: 4px solid #ff4757;
        }

        .toast.warning {
            border-left: 4px solid #ffa502;
        }

        .toast.info {
            border-left: 4px solid #4facfe;
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <span>GuardianIA</span>
            </div>
            <ul class="nav-menu">
                <li><a href="user_dashboard.php" class="nav-link">Mi Seguridad</a></li>
                <li><a href="user_security.php" class="nav-link">Protección</a></li>
                <li><a href="user_performance.php" class="nav-link">Optimización</a></li>
                <li><a href="user_assistant.php" class="nav-link">Asistente IA</a></li>
                <li><a href="#" class="nav-link active">Configuración</a></li>
            </ul>
            <div class="user-profile">
                <div class="user-avatar">JD</div>
                <span><?php echo htmlspecialchars($user_profile['full_name'] ?? 'Juan Pérez'); ?></span>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Settings Sidebar -->
        <div class="settings-sidebar">
            <h2 class="sidebar-title">Configuración</h2>
            <div class="settings-menu">
                <div class="menu-item active" onclick="showSection('profile')">
                    <i class="fas fa-user menu-icon"></i>
                    <span class="menu-text">Mi Perfil</span>
                </div>
                <div class="menu-item" onclick="showSection('security')">
                    <i class="fas fa-shield-alt menu-icon"></i>
                    <span class="menu-text">Seguridad</span>
                </div>
                <div class="menu-item" onclick="showSection('performance')">
                    <i class="fas fa-tachometer-alt menu-icon"></i>
                    <span class="menu-text">Rendimiento</span>
                </div>
                <div class="menu-item" onclick="showSection('notifications')">
                    <i class="fas fa-bell menu-icon"></i>
                    <span class="menu-text">Notificaciones</span>
                </div>
                <div class="menu-item" onclick="showSection('privacy')">
                    <i class="fas fa-lock menu-icon"></i>
                    <span class="menu-text">Privacidad</span>
                </div>
                <div class="menu-item" onclick="showSection('account')">
                    <i class="fas fa-cog menu-icon"></i>
                    <span class="menu-text">Cuenta</span>
                </div>
            </div>
        </div>

        <!-- Settings Content -->
        <div class="settings-content">
            <!-- Profile Section -->
            <div class="settings-section active" id="profile">
                <div class="section-header">
                    <div class="section-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-user"></i>
                    </div>
                    <div>
                        <h2 class="section-title">Mi Perfil</h2>
                        <p class="section-description">Gestiona tu información personal y preferencias de cuenta</p>
                    </div>
                </div>

                <form id="profileForm">
                    <div class="form-group">
                        <label class="form-label">Nombre Completo</label>
                        <input type="text" class="form-input" name="full_name" value="<?php echo htmlspecialchars($user_profile['full_name'] ?? ''); ?>" placeholder="Tu nombre completo">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Correo Electrónico</label>
                        <input type="email" class="form-input" name="email" value="<?php echo htmlspecialchars($user_profile['email'] ?? ''); ?>" placeholder="tu@email.com">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Teléfono</label>
                        <input type="tel" class="form-input" name="phone" value="<?php echo htmlspecialchars($user_profile['phone'] ?? ''); ?>" placeholder="+52 123 456 7890">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Idioma</label>
                        <select class="setting-select" name="language">
                            <option value="es" <?php echo ($user_profile['language'] ?? 'es') === 'es' ? 'selected' : ''; ?>>Español</option>
                            <option value="en" <?php echo ($user_profile['language'] ?? 'es') === 'en' ? 'selected' : ''; ?>>English</option>
                            <option value="fr" <?php echo ($user_profile['language'] ?? 'es') === 'fr' ? 'selected' : ''; ?>>Français</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Zona Horaria</label>
                        <select class="setting-select" name="timezone">
                            <option value="America/Mexico_City" <?php echo ($user_profile['timezone'] ?? 'America/Mexico_City') === 'America/Mexico_City' ? 'selected' : ''; ?>>Ciudad de México (GMT-6)</option>
                            <option value="America/New_York" <?php echo ($user_profile['timezone'] ?? '') === 'America/New_York' ? 'selected' : ''; ?>>Nueva York (GMT-5)</option>
                            <option value="Europe/Madrid" <?php echo ($user_profile['timezone'] ?? '') === 'Europe/Madrid' ? 'selected' : ''; ?>>Madrid (GMT+1)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Tema</label>
                        <select class="setting-select" name="theme">
                            <option value="dark" <?php echo ($user_profile['theme'] ?? 'dark') === 'dark' ? 'selected' : ''; ?>>Oscuro</option>
                            <option value="light" <?php echo ($user_profile['theme'] ?? 'dark') === 'light' ? 'selected' : ''; ?>>Claro</option>
                            <option value="auto" <?php echo ($user_profile['theme'] ?? 'dark') === 'auto' ? 'selected' : ''; ?>>Automático</option>
                        </select>
                    </div>

                    <div class="action-buttons">
                        <button type="submit" class="btn success">
                            <i class="fas fa-save"></i>
                            Guardar Cambios
                        </button>
                        <button type="button" class="btn secondary" onclick="resetForm('profileForm')">
                            <i class="fas fa-undo"></i>
                            Restablecer
                        </button>
                    </div>
                </form>
            </div>

            <!-- Security Section -->
            <div class="settings-section" id="security">
                <div class="section-header">
                    <div class="section-icon" style="background: var(--success-gradient);">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div>
                        <h2 class="section-title">Configuración de Seguridad</h2>
                        <p class="section-description">Ajusta las configuraciones de protección y detección de amenazas</p>
                    </div>
                </div>

                <form id="securityForm">
                    <div class="settings-group">
                        <h3 class="group-title">Protección en Tiempo Real</h3>
                        
                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Protección en Tiempo Real</div>
                                <div class="setting-description">Monitorea y bloquea amenazas automáticamente</div>
                            </div>
                            <div class="toggle-switch <?php echo $security_settings['real_time_protection'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'real_time_protection')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Escaneo Automático</div>
                                <div class="setting-description">Ejecuta escaneos programados del sistema</div>
                            </div>
                            <div class="toggle-switch <?php echo $security_settings['auto_scan'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'auto_scan')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Firewall Habilitado</div>
                                <div class="setting-description">Protege contra conexiones no autorizadas</div>
                            </div>
                            <div class="toggle-switch <?php echo $security_settings['firewall_enabled'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'firewall_enabled')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Notificaciones de Amenazas</div>
                                <div class="setting-description">Recibe alertas cuando se detecten amenazas</div>
                            </div>
                            <div class="toggle-switch <?php echo $security_settings['threat_notifications'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'threat_notifications')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Frecuencia de Escaneo</div>
                                <div class="setting-description">Qué tan seguido se ejecutan los escaneos</div>
                            </div>
                            <select class="setting-select" name="scan_frequency">
                                <option value="hourly" <?php echo $security_settings['scan_frequency'] === 'hourly' ? 'selected' : ''; ?>>Cada hora</option>
                                <option value="daily" <?php echo $security_settings['scan_frequency'] === 'daily' ? 'selected' : ''; ?>>Diario</option>
                                <option value="weekly" <?php echo $security_settings['scan_frequency'] === 'weekly' ? 'selected' : ''; ?>>Semanal</option>
                            </select>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Cuarentena Automática</div>
                                <div class="setting-description">Aisla amenazas detectadas automáticamente</div>
                            </div>
                            <div class="toggle-switch <?php echo $security_settings['quarantine_auto'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'quarantine_auto')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <button type="submit" class="btn success">
                            <i class="fas fa-save"></i>
                            Guardar Configuración
                        </button>
                    </div>
                </form>
            </div>

            <!-- Performance Section -->
            <div class="settings-section" id="performance">
                <div class="section-header">
                    <div class="section-icon" style="background: var(--warning-gradient);">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    <div>
                        <h2 class="section-title">Configuración de Rendimiento</h2>
                        <p class="section-description">Optimiza el rendimiento y recursos del sistema</p>
                    </div>
                </div>

                <form id="performanceForm">
                    <div class="settings-group">
                        <h3 class="group-title">Optimización Automática</h3>
                        
                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Optimización Automática</div>
                                <div class="setting-description">Optimiza el sistema automáticamente</div>
                            </div>
                            <div class="toggle-switch <?php echo $performance_settings['auto_optimization'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'auto_optimization')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Optimización de RAM</div>
                                <div class="setting-description">Libera memoria no utilizada automáticamente</div>
                            </div>
                            <div class="toggle-switch <?php echo $performance_settings['ram_optimization'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'ram_optimization')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Limpieza de Almacenamiento</div>
                                <div class="setting-description">Elimina archivos temporales y basura</div>
                            </div>
                            <div class="toggle-switch <?php echo $performance_settings['storage_cleanup'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'storage_cleanup')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Optimización de Batería</div>
                                <div class="setting-description">Extiende la duración de la batería</div>
                            </div>
                            <div class="toggle-switch <?php echo $performance_settings['battery_optimization'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'battery_optimization')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Horario de Optimización</div>
                                <div class="setting-description">Cuándo ejecutar optimizaciones automáticas</div>
                            </div>
                            <select class="setting-select" name="optimization_schedule">
                                <option value="hourly" <?php echo $performance_settings['optimization_schedule'] === 'hourly' ? 'selected' : ''; ?>>Cada hora</option>
                                <option value="daily" <?php echo $performance_settings['optimization_schedule'] === 'daily' ? 'selected' : ''; ?>>Diario</option>
                                <option value="weekly" <?php echo $performance_settings['optimization_schedule'] === 'weekly' ? 'selected' : ''; ?>>Semanal</option>
                            </select>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Modo de Rendimiento</div>
                                <div class="setting-description">Equilibrio entre rendimiento y eficiencia</div>
                            </div>
                            <select class="setting-select" name="performance_mode">
                                <option value="power_saver" <?php echo $performance_settings['performance_mode'] === 'power_saver' ? 'selected' : ''; ?>>Ahorro de energía</option>
                                <option value="balanced" <?php echo $performance_settings['performance_mode'] === 'balanced' ? 'selected' : ''; ?>>Equilibrado</option>
                                <option value="performance" <?php echo $performance_settings['performance_mode'] === 'performance' ? 'selected' : ''; ?>>Alto rendimiento</option>
                            </select>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <button type="submit" class="btn warning">
                            <i class="fas fa-save"></i>
                            Guardar Configuración
                        </button>
                    </div>
                </form>
            </div>

            <!-- Notifications Section -->
            <div class="settings-section" id="notifications">
                <div class="section-header">
                    <div class="section-icon" style="background: var(--info-gradient);">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div>
                        <h2 class="section-title">Configuración de Notificaciones</h2>
                        <p class="section-description">Controla cómo y cuándo recibir notificaciones</p>
                    </div>
                </div>

                <form id="notificationsForm">
                    <div class="settings-group">
                        <h3 class="group-title">Tipos de Notificaciones</h3>
                        
                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Notificaciones por Email</div>
                                <div class="setting-description">Recibe notificaciones en tu correo electrónico</div>
                            </div>
                            <div class="toggle-switch <?php echo $notification_settings['email_notifications'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'email_notifications')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Notificaciones Push</div>
                                <div class="setting-description">Recibe notificaciones en tiempo real</div>
                            </div>
                            <div class="toggle-switch <?php echo $notification_settings['push_notifications'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'push_notifications')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Alertas de Sonido</div>
                                <div class="setting-description">Reproduce sonidos para alertas importantes</div>
                            </div>
                            <div class="toggle-switch <?php echo $notification_settings['sound_alerts'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'sound_alerts')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Alertas de Amenazas</div>
                                <div class="setting-description">Notificaciones cuando se detecten amenazas</div>
                            </div>
                            <div class="toggle-switch <?php echo $notification_settings['threat_alerts'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'threat_alerts')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Alertas de Optimización</div>
                                <div class="setting-description">Notificaciones sobre optimizaciones completadas</div>
                            </div>
                            <div class="toggle-switch <?php echo $notification_settings['optimization_alerts'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'optimization_alerts')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Actualizaciones del Sistema</div>
                                <div class="setting-description">Notificaciones sobre actualizaciones disponibles</div>
                            </div>
                            <div class="toggle-switch <?php echo $notification_settings['system_updates'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'system_updates')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <button type="submit" class="btn">
                            <i class="fas fa-save"></i>
                            Guardar Configuración
                        </button>
                    </div>
                </form>
            </div>

            <!-- Privacy Section -->
            <div class="settings-section" id="privacy">
                <div class="section-header">
                    <div class="section-icon" style="background: var(--danger-gradient);">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div>
                        <h2 class="section-title">Configuración de Privacidad</h2>
                        <p class="section-description">Controla qué datos se recopilan y comparten</p>
                    </div>
                </div>

                <form id="privacyForm">
                    <div class="settings-group">
                        <h3 class="group-title">Recopilación de Datos</h3>
                        
                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Recopilación de Datos</div>
                                <div class="setting-description">Permite recopilar datos para mejorar el servicio</div>
                            </div>
                            <div class="toggle-switch <?php echo $privacy_settings['data_collection'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'data_collection')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Compartir Análisis</div>
                                <div class="setting-description">Comparte datos analíticos anónimos</div>
                            </div>
                            <div class="toggle-switch <?php echo $privacy_settings['analytics_sharing'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'analytics_sharing')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Reportes de Errores</div>
                                <div class="setting-description">Envía reportes automáticos de errores</div>
                            </div>
                            <div class="toggle-switch <?php echo $privacy_settings['crash_reports'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'crash_reports')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Estadísticas de Uso</div>
                                <div class="setting-description">Recopila estadísticas sobre el uso de la aplicación</div>
                            </div>
                            <div class="toggle-switch <?php echo $privacy_settings['usage_statistics'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'usage_statistics')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Seguimiento de Ubicación</div>
                                <div class="setting-description">Permite el acceso a datos de ubicación</div>
                            </div>
                            <div class="toggle-switch <?php echo $privacy_settings['location_tracking'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'location_tracking')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <div class="setting-name">Compartir con Terceros</div>
                                <div class="setting-description">Permite compartir datos con servicios de terceros</div>
                            </div>
                            <div class="toggle-switch <?php echo $privacy_settings['third_party_sharing'] ? 'active' : ''; ?>" onclick="toggleSetting(this, 'third_party_sharing')">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <button type="submit" class="btn danger">
                            <i class="fas fa-save"></i>
                            Guardar Configuración
                        </button>
                    </div>
                </form>
            </div>

            <!-- Account Section -->
            <div class="settings-section" id="account">
                <div class="section-header">
                    <div class="section-icon" style="background: var(--primary-gradient);">
                        <i class="fas fa-cog"></i>
                    </div>
                    <div>
                        <h2 class="section-title">Configuración de Cuenta</h2>
                        <p class="section-description">Gestiona tu cuenta y configuraciones avanzadas</p>
                    </div>
                </div>

                <div class="settings-group">
                    <h3 class="group-title">Seguridad de la Cuenta</h3>
                    
                    <form id="passwordForm">
                        <div class="form-group">
                            <label class="form-label">Contraseña Actual</label>
                            <input type="password" class="form-input" name="current_password" placeholder="Tu contraseña actual">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Nueva Contraseña</label>
                            <input type="password" class="form-input" name="new_password" placeholder="Nueva contraseña (mínimo 8 caracteres)">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Confirmar Nueva Contraseña</label>
                            <input type="password" class="form-input" name="confirm_password" placeholder="Confirma tu nueva contraseña">
                        </div>

                        <div class="action-buttons">
                            <button type="submit" class="btn warning">
                                <i class="fas fa-key"></i>
                                Cambiar Contraseña
                            </button>
                        </div>
                    </form>
                </div>

                <div class="settings-group">
                    <h3 class="group-title">Gestión de Datos</h3>
                    
                    <div class="action-buttons">
                        <button class="btn secondary" onclick="exportUserData()">
                            <i class="fas fa-download"></i>
                            Exportar Mis Datos
                        </button>
                    </div>
                </div>

                <div class="danger-zone">
                    <h3 class="danger-title">
                        <i class="fas fa-exclamation-triangle"></i>
                        Zona de Peligro
                    </h3>
                    <p class="danger-description">
                        Las siguientes acciones son permanentes y no se pueden deshacer. Procede con precaución.
                    </p>
                    
                    <button class="btn danger" onclick="showDeleteAccountModal()">
                        <i class="fas fa-trash"></i>
                        Eliminar Mi Cuenta
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <span id="toast-message"></span>
    </div>

    <script>
        // Variables globales
        let userId = <?php echo $user_id; ?>;
        let currentSection = 'profile';

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            initializeSettings();
            setupEventListeners();
        });

        // Inicializar configuraciones
        function initializeSettings() {
            console.log('Inicializando configuraciones...');
            showSection('profile');
        }

        // Configurar event listeners
        function setupEventListeners() {
            // Formularios
            document.getElementById('profileForm').addEventListener('submit', handleProfileSubmit);
            document.getElementById('securityForm').addEventListener('submit', handleSecuritySubmit);
            document.getElementById('performanceForm').addEventListener('submit', handlePerformanceSubmit);
            document.getElementById('notificationsForm').addEventListener('submit', handleNotificationsSubmit);
            document.getElementById('privacyForm').addEventListener('submit', handlePrivacySubmit);
            document.getElementById('passwordForm').addEventListener('submit', handlePasswordSubmit);
        }

        // Mostrar sección
        function showSection(sectionName) {
            // Ocultar todas las secciones
            document.querySelectorAll('.settings-section').forEach(section => {
                section.classList.remove('active');
            });

            // Mostrar sección seleccionada
            document.getElementById(sectionName).classList.add('active');

            // Actualizar menú
            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
            });
            event.target.closest('.menu-item').classList.add('active');

            currentSection = sectionName;
        }

        // Toggle setting
        function toggleSetting(toggle, settingName) {
            toggle.classList.toggle('active');
            const isActive = toggle.classList.contains('active');
            
            // Actualizar valor en el formulario
            const form = toggle.closest('form');
            if (form) {
                let input = form.querySelector(`input[name="${settingName}"]`);
                if (!input) {
                    input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = settingName;
                    form.appendChild(input);
                }
                input.value = isActive ? 1 : 0;
            }
        }

        // Manejar envío de formulario de perfil
        function handleProfileSubmit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'update_profile');
            formData.append('user_id', userId);

            submitForm(formData, 'Perfil actualizado correctamente');
        }

        // Manejar envío de formulario de seguridad
        function handleSecuritySubmit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'update_security_settings');
            formData.append('user_id', userId);

            // Agregar valores de toggles
            document.querySelectorAll('#security .toggle-switch').forEach(toggle => {
                const settingName = toggle.getAttribute('onclick').match(/'([^']+)'/)[1];
                formData.append(settingName, toggle.classList.contains('active') ? 1 : 0);
            });

            submitForm(formData, 'Configuración de seguridad actualizada');
        }

        // Manejar envío de formulario de rendimiento
        function handlePerformanceSubmit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'update_performance_settings');
            formData.append('user_id', userId);

            // Agregar valores de toggles
            document.querySelectorAll('#performance .toggle-switch').forEach(toggle => {
                const settingName = toggle.getAttribute('onclick').match(/'([^']+)'/)[1];
                formData.append(settingName, toggle.classList.contains('active') ? 1 : 0);
            });

            submitForm(formData, 'Configuración de rendimiento actualizada');
        }

        // Manejar envío de formulario de notificaciones
        function handleNotificationsSubmit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'update_notification_settings');
            formData.append('user_id', userId);

            // Agregar valores de toggles
            document.querySelectorAll('#notifications .toggle-switch').forEach(toggle => {
                const settingName = toggle.getAttribute('onclick').match(/'([^']+)'/)[1];
                formData.append(settingName, toggle.classList.contains('active') ? 1 : 0);
            });

            submitForm(formData, 'Configuración de notificaciones actualizada');
        }

        // Manejar envío de formulario de privacidad
        function handlePrivacySubmit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'update_privacy_settings');
            formData.append('user_id', userId);

            // Agregar valores de toggles
            document.querySelectorAll('#privacy .toggle-switch').forEach(toggle => {
                const settingName = toggle.getAttribute('onclick').match(/'([^']+)'/)[1];
                formData.append(settingName, toggle.classList.contains('active') ? 1 : 0);
            });

            submitForm(formData, 'Configuración de privacidad actualizada');
        }

        // Manejar envío de formulario de contraseña
        function handlePasswordSubmit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'change_password');
            formData.append('user_id', userId);

            submitForm(formData, 'Contraseña actualizada correctamente', () => {
                e.target.reset();
            });
        }

        // Enviar formulario
        function submitForm(formData, successMessage, callback) {
            const submitButton = event.target.querySelector('button[type="submit"]');
            const originalText = submitButton.innerHTML;
            
            submitButton.innerHTML = '<div class="loading"></div> Guardando...';
            submitButton.disabled = true;

            fetch('user_settings.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                submitButton.innerHTML = originalText;
                submitButton.disabled = false;

                if (data.success) {
                    showToast(successMessage, 'success');
                    if (callback) callback();
                } else {
                    showToast(data.error || 'Error al guardar configuración', 'error');
                }
            })
            .catch(error => {
                submitButton.innerHTML = originalText;
                submitButton.disabled = false;
                console.error('Error:', error);
                showToast('Error de conexión', 'error');
            });
        }

        // Restablecer formulario
        function resetForm(formId) {
            if (confirm('¿Estás seguro de que quieres restablecer los cambios?')) {
                document.getElementById(formId).reset();
                showToast('Formulario restablecido', 'info');
            }
        }

        // Exportar datos del usuario
        function exportUserData() {
            const button = event.target;
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Exportando...';
            button.disabled = true;

            const formData = new FormData();
            formData.append('action', 'export_data');
            formData.append('user_id', userId);

            fetch('user_settings.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.innerHTML = originalText;
                button.disabled = false;

                if (data.success) {
                    // Crear y descargar archivo
                    const blob = new Blob([data.data], { type: 'application/json' });
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = data.filename;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    window.URL.revokeObjectURL(url);
                    
                    showToast('Datos exportados correctamente', 'success');
                } else {
                    showToast(data.error || 'Error al exportar datos', 'error');
                }
            })
            .catch(error => {
                button.innerHTML = originalText;
                button.disabled = false;
                console.error('Error:', error);
                showToast('Error de conexión', 'error');
            });
        }

        // Mostrar modal de eliminación de cuenta
        function showDeleteAccountModal() {
            const password = prompt('Para eliminar tu cuenta, ingresa tu contraseña:');
            
            if (password) {
                if (confirm('¿Estás ABSOLUTAMENTE seguro de que quieres eliminar tu cuenta? Esta acción NO se puede deshacer.')) {
                    deleteUserAccount(password);
                }
            }
        }

        // Eliminar cuenta de usuario
        function deleteUserAccount(password) {
            const formData = new FormData();
            formData.append('action', 'delete_account');
            formData.append('user_id', userId);
            formData.append('password', password);

            fetch('user_settings.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Cuenta eliminada correctamente. Redirigiendo...', 'success');
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 3000);
                } else {
                    showToast(data.error || 'Error al eliminar cuenta', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error de conexión', 'error');
            });
        }

        // Mostrar notificación toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type}`;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 4000);
        }

        // Manejo de errores
        window.addEventListener('error', function(e) {
            console.log('Error capturado:', e.message);
            showToast('Se produjo un error en la configuración. Reintentando...', 'error');
        });
    </script>
</body>
</html>

