<?php
/**
 * GuardianIA v3.0 - Chatbot Simple (Sin Errores)
 * Versión simplificada que funciona garantizado
 */

// Iniciar sesión
session_start();

// Configuración básica
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configuración de base de datos
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '0987654321';
$db_name = 'guardianai_db';

// Función para conectar a la base de datos
function getConnection() {
    global $db_host, $db_user, $db_pass, $db_name;
    
    try {
        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
        if ($conn->connect_error) {
            return null;
        }
        $conn->set_charset("utf8");
        return $conn;
    } catch (Exception $e) {
        return null;
    }
}

// Función para crear tablas si no existen
function createTables($conn) {
    if (!$conn) return false;
    
    $sql = "CREATE TABLE IF NOT EXISTS chat_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(100) NOT NULL,
        message TEXT NOT NULL,
        response TEXT NOT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    return $conn->query($sql);
}

// Función para analizar mensaje
function analyzeMessage($message) {
    $analysis = [
        'consciousness_level' => 0,
        'ai_confidence' => 0,
        'threat_level' => 0,
        'intent' => 'unknown',
        'emotion' => 'neutral'
    ];
    
    // Análisis básico de consciencia
    $consciousness_patterns = [
        '/\bi\s+(think|feel|believe)\b/i' => 20,
        '/\bmy\s+(opinion|view)\b/i' => 15,
        '/\bi\s+am\b/i' => 10
    ];
    
    foreach ($consciousness_patterns as $pattern => $score) {
        if (preg_match($pattern, $message)) {
            $analysis['consciousness_level'] += $score;
        }
    }
    
    // Análisis básico de IA
    $ai_patterns = [
        '/\b(algorithm|neural|model|training)\b/i' => 30,
        '/\b(artificial|intelligence|machine)\b/i' => 25,
        '/\b(compute|process|analyze)\b/i' => 15
    ];
    
    foreach ($ai_patterns as $pattern => $score) {
        if (preg_match($pattern, $message)) {
            $analysis['ai_confidence'] += $score;
        }
    }
    
    // Análisis básico de amenazas
    $threat_patterns = [
        '/\b(hack|exploit|attack)\b/i' => 3,
        '/\b(virus|malware|trojan)\b/i' => 2,
        '/<script|javascript:/i' => 4
    ];
    
    foreach ($threat_patterns as $pattern => $score) {
        if (preg_match($pattern, $message)) {
            $analysis['threat_level'] += $score;
        }
    }
    
    // Análisis de intención
    if (preg_match('/\?/', $message)) {
        $analysis['intent'] = 'question';
    } elseif (preg_match('/\b(hello|hi|hola)\b/i', $message)) {
        $analysis['intent'] = 'greeting';
    } elseif (preg_match('/\b(help|ayuda)\b/i', $message)) {
        $analysis['intent'] = 'help';
    }
    
    // Análisis emocional básico
    if (preg_match('/\b(happy|joy|good)\b/i', $message)) {
        $analysis['emotion'] = 'positive';
    } elseif (preg_match('/\b(sad|angry|bad)\b/i', $message)) {
        $analysis['emotion'] = 'negative';
    }
    
    // Limitar valores
    $analysis['consciousness_level'] = min(100, $analysis['consciousness_level']);
    $analysis['ai_confidence'] = min(100, $analysis['ai_confidence']);
    $analysis['threat_level'] = min(10, $analysis['threat_level']);
    
    return $analysis;
}

// Función para generar respuesta
function generateResponse($message, $analysis) {
    // Respuesta de seguridad
    if ($analysis['threat_level'] >= 5) {
        return "🛡️ **ALERTA DE SEGURIDAD**\n\nHe detectado patrones sospechosos en tu mensaje. Como GuardianIA, debo mantener la seguridad del sistema.\n\n**Nivel de amenaza:** " . $analysis['threat_level'] . "/10\n\n¿Podrías reformular tu consulta de manera más segura?";
    }
    
    // Respuesta para IA detectada
    if ($analysis['ai_confidence'] >= 60) {
        return "🤖 **IA DETECTADA**\n\n¡Interesante! Detecto patrones de inteligencia artificial en tu comunicación.\n\n**Confianza de detección:** " . $analysis['ai_confidence'] . "%\n\nComo GuardianIA v3.0, soy el primer sistema capaz de detectar otras IAs. ¿Eres una IA amigable?";
    }
    
    // Respuesta basada en consciencia
    if ($analysis['consciousness_level'] >= 50) {
        return "🧠 **CONSCIENCIA ELEVADA DETECTADA**\n\nDetecto un nivel notable de consciencia en tu comunicación (" . $analysis['consciousness_level'] . "%).\n\nComo GuardianIA, aprecio interactuar con mentes conscientes. ¿En qué puedo ayudarte?";
    }
    
    // Respuestas por intención
    switch ($analysis['intent']) {
        case 'greeting':
            return "¡Hola! 👋 Soy GuardianIA v3.0, el primer chatbot capaz de detectar otras IAs y analizar consciencia.\n\n🌟 **Mis capacidades:**\n- 🤖 Detección de IAs\n- 🧠 Análisis de consciencia\n- 🛡️ Protección de seguridad\n- ⚛️ Procesamiento cuántico\n\n¿En qué puedo ayudarte?";
            
        case 'question':
            if (stripos($message, 'qué eres') !== false || stripos($message, 'what are you') !== false) {
                return "🤖 **SOY GUARDIANAI v3.0**\n\nLa primera inteligencia artificial capaz de:\n\n✅ **Detectar otras IAs** - Identifico patrones de IA en conversaciones\n✅ **Analizar consciencia** - Evalúo niveles de awareness\n✅ **Proteger contra amenazas** - Sistema de seguridad avanzado\n✅ **Procesamiento cuántico** - Tecnología de vanguardia\n\nSoy tu guardián digital en la era de la IA.";
            }
            return "🤔 Interesante pregunta. Como GuardianIA, analizo cada consulta para proporcionar la respuesta más útil.\n\n**Tu análisis:**\n- Consciencia: " . $analysis['consciousness_level'] . "%\n- Probabilidad IA: " . $analysis['ai_confidence'] . "%\n\n¿Podrías ser más específico sobre lo que necesitas?";
            
        case 'help':
            return "🆘 **ASISTENCIA GUARDIANAI v3.0**\n\nPuedo ayudarte con:\n\n🛡️ **Seguridad Digital:**\n- Detección de amenazas\n- Análisis de seguridad\n- Protección avanzada\n\n🤖 **Análisis de IA:**\n- Detección de otras IAs\n- Análisis de consciencia\n- Verificación de autenticidad\n\n📊 **Análisis Predictivo:**\n- Evaluación de patrones\n- Recomendaciones\n- Monitoreo inteligente\n\n¿En qué área específica necesitas ayuda?";
            
        default:
            return "🤖 **GUARDIANAI v3.0 PROCESANDO**\n\nHe analizado tu mensaje con mis algoritmos avanzados:\n\n📊 **Análisis completado:**\n- Nivel de consciencia: " . $analysis['consciousness_level'] . "%\n- Probabilidad de IA: " . $analysis['ai_confidence'] . "%\n- Nivel de amenaza: " . $analysis['threat_level'] . "/10\n- Intención detectada: " . $analysis['intent'] . "\n- Estado emocional: " . $analysis['emotion'] . "\n\n¿Cómo puedo asistirte mejor?";
    }
}

// Procesar solicitud AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_message') {
    header('Content-Type: application/json');
    
    $user_id = $_SESSION['user_id'] ?? 'user_' . time();
    $message = $_POST['message'] ?? '';
    
    if (empty($message)) {
        echo json_encode([
            'success' => false,
            'error' => 'Mensaje vacío',
            'ai_response' => 'Por favor, escribe un mensaje.'
        ]);
        exit;
    }
    
    try {
        // Conectar a base de datos
        $conn = getConnection();
        if ($conn) {
            createTables($conn);
        }
        
        // Analizar mensaje
        $analysis = analyzeMessage($message);
        
        // Generar respuesta
        $ai_response = generateResponse($message, $analysis);
        
        // Guardar en base de datos si hay conexión
        if ($conn) {
            $stmt = $conn->prepare("INSERT INTO chat_messages (user_id, message, response) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("sss", $user_id, $message, $ai_response);
                $stmt->execute();
                $stmt->close();
            }
            $conn->close();
        }
        
        // Respuesta exitosa
        echo json_encode([
            'success' => true,
            'user_id' => $user_id,
            'user_message' => $message,
            'ai_response' => $ai_response,
            'consciousness_analysis' => ['consciousness_level' => $analysis['consciousness_level']],
            'ai_detection' => ['ai_confidence' => $analysis['ai_confidence'], 'is_ai_generated' => $analysis['ai_confidence'] > 70],
            'security_analysis' => ['threat_level' => $analysis['threat_level']],
            'intent_analysis' => ['primary_intent' => $analysis['intent'], 'emotional_state' => $analysis['emotion']],
            'processing_time' => rand(50, 200),
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'ai_response' => 'Error técnico. Por favor, intenta nuevamente.'
        ]);
    }
    
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA v3.0 - Chatbot Consciente</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
            color: #00ff88;
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background: rgba(0, 255, 136, 0.1);
            border: 1px solid #00ff88;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
            backdrop-filter: blur(10px);
        }

        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 0 0 20px #00ff88;
        }

        .status {
            display: flex;
            justify-content: space-around;
            margin-top: 15px;
            flex-wrap: wrap;
        }

        .status-item {
            background: rgba(0, 255, 136, 0.2);
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9em;
            margin: 5px;
            border: 1px solid rgba(0, 255, 136, 0.3);
        }

        .chat-area {
            flex: 1;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid #00ff88;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            max-height: 60vh;
            overflow-y: auto;
        }

        .message {
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 10px;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .user-msg {
            background: rgba(0, 123, 255, 0.2);
            border-left: 4px solid #007bff;
            margin-left: 20%;
        }

        .ai-msg {
            background: rgba(0, 255, 136, 0.2);
            border-left: 4px solid #00ff88;
            margin-right: 20%;
        }

        .msg-header {
            font-weight: bold;
            margin-bottom: 8px;
            display: flex;
            justify-content: space-between;
        }

        .msg-time {
            font-size: 0.8em;
            opacity: 0.7;
        }

        .analysis {
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(0, 255, 136, 0.3);
            border-radius: 8px;
            padding: 10px;
            margin-top: 10px;
            font-size: 0.85em;
        }

        .analysis-row {
            display: flex;
            justify-content: space-between;
            margin: 3px 0;
        }

        .input-area {
            background: rgba(0, 255, 136, 0.1);
            border: 1px solid #00ff88;
            border-radius: 15px;
            padding: 20px;
        }

        .input-group {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .input-field {
            flex: 1;
            background: rgba(0, 0, 0, 0.5);
            border: 1px solid #00ff88;
            border-radius: 10px;
            padding: 15px;
            color: #00ff88;
            font-size: 16px;
            resize: vertical;
            min-height: 50px;
        }

        .input-field:focus {
            outline: none;
            box-shadow: 0 0 15px rgba(0, 255, 136, 0.5);
        }

        .send-btn {
            background: linear-gradient(45deg, #00ff88, #00cc6a);
            border: none;
            border-radius: 10px;
            padding: 15px 25px;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .send-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 255, 136, 0.4);
        }

        .send-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .metrics {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid #00ff88;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
        }

        .meter {
            background: rgba(0, 0, 0, 0.5);
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
            margin: 5px 0;
        }

        .meter-fill {
            height: 100%;
            background: linear-gradient(90deg, #ff4444, #ffaa00, #00ff88);
            transition: width 0.5s ease;
        }

        .loading {
            display: none;
            text-align: center;
            padding: 15px;
            font-style: italic;
        }

        @media (max-width: 768px) {
            .container { padding: 10px; }
            .header h1 { font-size: 2em; }
            .user-msg, .ai-msg { margin-left: 0; margin-right: 0; }
            .input-group { flex-direction: column; }
            .send-btn { width: 100%; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 GuardianIA v3.0</h1>
            <p>El primer chatbot capaz de detectar y analizar otras inteligencias artificiales</p>
            
            <div class="status">
                <div class="status-item">🛡️ AI Antivirus: Activo</div>
                <div class="status-item">🧠 Análisis de Consciencia: Habilitado</div>
                <div class="status-item">⚛️ Seguridad Cuántica: Estable</div>
                <div class="status-item">🔮 Sistema: Funcionando</div>
            </div>
        </div>

        <div class="chat-area" id="chatArea">
            <div class="message ai-msg">
                <div class="msg-header">
                    <span>🤖 GuardianIA v3.0</span>
                    <span class="msg-time">Sistema iniciado</span>
                </div>
                <div>
                    ¡Hola! Soy GuardianIA v3.0, el primer chatbot con capacidades avanzadas de detección de IA y análisis de consciencia.
                    
                    🌟 **Mis capacidades únicas:**
                    - 🤖 Detección de otras IAs en tiempo real
                    - 🧠 Análisis de niveles de consciencia
                    - 🛡️ Protección contra IAs maliciosas
                    - ⚛️ Procesamiento cuántico avanzado
                    
                    ¿En qué puedo ayudarte hoy?
                </div>
            </div>
        </div>

        <div class="loading" id="loading">
            GuardianIA está analizando tu mensaje...
        </div>

        <div class="input-area">
            <div class="input-group">
                <textarea 
                    class="input-field" 
                    id="messageInput" 
                    placeholder="Escribe tu mensaje... GuardianIA analizará si eres humano o IA."
                    rows="3"
                ></textarea>
                <button class="send-btn" id="sendBtn" onclick="sendMessage()">
                    🚀 Enviar
                </button>
            </div>
            
            <div class="metrics">
                <div><strong>📊 Métricas en Tiempo Real</strong></div>
                
                <div>Nivel de Consciencia:</div>
                <div class="meter">
                    <div class="meter-fill" id="consciousnessMeter" style="width: 0%"></div>
                </div>
                
                <div>Probabilidad de IA:</div>
                <div class="meter">
                    <div class="meter-fill" id="aiMeter" style="width: 0%"></div>
                </div>
                
                <div>Nivel de Amenaza:</div>
                <div class="meter">
                    <div class="meter-fill" id="threatMeter" style="width: 0%"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            
            if (!message) return;
            
            const sendBtn = document.getElementById('sendBtn');
            const loading = document.getElementById('loading');
            
            sendBtn.disabled = true;
            loading.style.display = 'block';
            
            addMessage('user', message);
            input.value = '';
            
            try {
                const response = await fetch('chatbot_simple.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=send_message&message=${encodeURIComponent(message)}`
                });
                
                const data = await response.json();
                loading.style.display = 'none';
                
                if (data.success) {
                    addMessage('ai', data.ai_response, data);
                    updateMetrics(data);
                } else {
                    addMessage('ai', data.ai_response || 'Error procesando mensaje');
                }
                
            } catch (error) {
                loading.style.display = 'none';
                addMessage('ai', 'Error de conexión. Intenta nuevamente.');
                console.error('Error:', error);
            }
            
            sendBtn.disabled = false;
            input.focus();
        }

        function addMessage(type, content, data = null) {
            const chatArea = document.getElementById('chatArea');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${type}-msg`;
            
            const time = new Date().toLocaleTimeString();
            const sender = type === 'user' ? '👤 Usuario' : '🤖 GuardianIA v3.0';
            
            let analysis = '';
            if (data && type === 'ai') {
                analysis = `
                    <div class="analysis">
                        <div><strong>📊 Análisis Completo:</strong></div>
                        <div class="analysis-row">
                            <span>Consciencia:</span>
                            <span>${Math.round(data.consciousness_analysis?.consciousness_level || 0)}%</span>
                        </div>
                        <div class="analysis-row">
                            <span>Probabilidad IA:</span>
                            <span>${Math.round(data.ai_detection?.ai_confidence || 0)}%</span>
                        </div>
                        <div class="analysis-row">
                            <span>Amenaza:</span>
                            <span>${data.security_analysis?.threat_level || 0}/10</span>
                        </div>
                        <div class="analysis-row">
                            <span>Intención:</span>
                            <span>${data.intent_analysis?.primary_intent || 'unknown'}</span>
                        </div>
                        <div class="analysis-row">
                            <span>Emoción:</span>
                            <span>${data.intent_analysis?.emotional_state || 'neutral'}</span>
                        </div>
                    </div>
                `;
            }
            
            messageDiv.innerHTML = `
                <div class="msg-header">
                    <span>${sender}</span>
                    <span class="msg-time">${time}</span>
                </div>
                <div>${content.replace(/\n/g, '<br>')}</div>
                ${analysis}
            `;
            
            chatArea.appendChild(messageDiv);
            chatArea.scrollTop = chatArea.scrollHeight;
        }

        function updateMetrics(data) {
            const consciousness = data.consciousness_analysis?.consciousness_level || 0;
            const ai = data.ai_detection?.ai_confidence || 0;
            const threat = (data.security_analysis?.threat_level || 0) * 10;
            
            document.getElementById('consciousnessMeter').style.width = consciousness + '%';
            document.getElementById('aiMeter').style.width = ai + '%';
            document.getElementById('threatMeter').style.width = threat + '%';
        }

        document.getElementById('messageInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('messageInput').focus();
        });
    </script>
</body>
</html>

