<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GuardianIA - Protección Inteligente</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --warning-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --dark-gradient: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        /* Navigation */
        .navbar {
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            transition: all var(--animation-speed) ease;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .logo i {
            font-size: 2rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: logoSpin 3s linear infinite;
        }

        @keyframes logoSpin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .nav-menu {
            display: flex;
            list-style: none;
            gap: 2rem;
            align-items: center;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
            position: relative;
        }

        .nav-link:hover {
            color: var(--text-primary);
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }

        .nav-link.active {
            background: var(--primary-gradient);
            color: white;
        }

        /* Main Container */
        .main-container {
            margin-top: 80px;
            padding: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Header Section */
        .header-section {
            text-align: center;
            margin-bottom: 3rem;
            padding: 3rem 0;
        }

        .header-title {
            font-size: 3.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: titleGlow 2s ease-in-out infinite alternate;
        }

        @keyframes titleGlow {
            0% { filter: brightness(1); }
            100% { filter: brightness(1.2); }
        }

        .header-subtitle {
            font-size: 1.25rem;
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.8;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            position: relative;
            overflow: hidden;
            transition: all var(--animation-speed) ease;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px var(--shadow-color);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
            transform: scaleX(0);
            transition: transform var(--animation-speed) ease;
        }

        .stat-card:hover::before {
            transform: scaleX(1);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .stat-icon.security {
            background: var(--primary-gradient);
        }

        .stat-icon.performance {
            background: var(--success-gradient);
        }

        .stat-icon.threats {
            background: var(--danger-gradient);
        }

        .stat-icon.optimization {
            background: var(--warning-gradient);
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
            animation: countUp 2s ease-out;
        }

        @keyframes countUp {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .stat-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .stat-trend {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 1rem;
            font-size: 0.85rem;
        }

        .trend-positive {
            color: #4ade80;
        }

        .trend-negative {
            color: #f87171;
        }

        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin-bottom: 3rem;
        }

        /* Main Dashboard Card */
        .dashboard-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            position: relative;
            overflow: hidden;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .card-action {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        /* System Status */
        .system-status {
            display: grid;
            gap: 1.5rem;
        }

        .status-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            transition: all var(--animation-speed) ease;
        }

        .status-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }

        .status-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .status-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: white;
        }

        .status-details h4 {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .status-details p {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }

        .status-good {
            background: #4ade80;
        }

        .status-warning {
            background: #fbbf24;
        }

        .status-critical {
            background: #f87171;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* Progress Bars */
        .progress-container {
            margin: 1rem 0;
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            overflow: hidden;
            position: relative;
        }

        .progress-fill {
            height: 100%;
            background: var(--primary-gradient);
            border-radius: 4px;
            transition: width 1s ease;
            position: relative;
        }

        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            animation: shimmer 2s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        /* Action Buttons */
        .action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }

        .action-btn {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1.5rem;
            text-align: center;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            text-decoration: none;
            color: var(--text-primary);
            position: relative;
            overflow: hidden;
        }

        .action-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px var(--shadow-color);
            border-color: rgba(255, 255, 255, 0.2);
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.5s ease;
        }

        .action-btn:hover::before {
            left: 100%;
        }

        .action-btn i {
            font-size: 2rem;
            margin-bottom: 1rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .action-btn h3 {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .action-btn p {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Floating Action Button */
        .fab {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            width: 60px;
            height: 60px;
            background: var(--primary-gradient);
            border: none;
            border-radius: 50%;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
            transition: all var(--animation-speed) ease;
            z-index: 1000;
        }

        .fab:hover {
            transform: scale(1.1);
            box-shadow: 0 12px 35px rgba(102, 126, 234, 0.6);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-menu {
                display: none;
            }

            .header-title {
                font-size: 2.5rem;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .main-container {
                padding: 1rem;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Notification Toast */
        .toast {
            position: fixed;
            top: 100px;
            right: 2rem;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 1rem 1.5rem;
            color: var(--text-primary);
            box-shadow: 0 8px 25px var(--shadow-color);
            transform: translateX(400px);
            transition: transform var(--animation-speed) ease;
            z-index: 1001;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #4ade80;
        }

        .toast.error {
            border-left: 4px solid #f87171;
        }

        .toast.warning {
            border-left: 4px solid #fbbf24;
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
                <span>GuardianIA</span>
            </div>
            <ul class="nav-menu">
                <li><a href="#" class="nav-link active">Dashboard</a></li>
                <li><a href="threat_center.php" class="nav-link">Centro de Amenazas</a></li>
                <li><a href="performance.php" class="nav-link">Rendimiento</a></li>
                <li><a href="chatbot.php" class="nav-link">Asistente IA</a></li>
                <li><a href="settings.php" class="nav-link">Configuración</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Header Section -->
        <div class="header-section">
            <h1 class="header-title">🛡️ GuardianIA</h1>
            <p class="header-subtitle">
                Protección inteligente impulsada por IA. Monitoreo en tiempo real, 
                optimización automática y respuesta proactiva a amenazas.
            </p>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card" onclick="showDetails('security')">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" id="security-score">98</div>
                        <div class="stat-label">Puntuación de Seguridad</div>
                    </div>
                    <div class="stat-icon security">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                </div>
                <div class="stat-trend trend-positive">
                    <i class="fas fa-arrow-up"></i>
                    <span>+5% esta semana</span>
                </div>
            </div>

            <div class="stat-card" onclick="showDetails('performance')">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" id="performance-score">87</div>
                        <div class="stat-label">Rendimiento del Sistema</div>
                    </div>
                    <div class="stat-icon performance">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                </div>
                <div class="stat-trend trend-positive">
                    <i class="fas fa-arrow-up"></i>
                    <span>+12% optimizado</span>
                </div>
            </div>

            <div class="stat-card" onclick="showDetails('threats')">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" id="threats-blocked">247</div>
                        <div class="stat-label">Amenazas Bloqueadas</div>
                    </div>
                    <div class="stat-icon threats">
                        <i class="fas fa-bug"></i>
                    </div>
                </div>
                <div class="stat-trend trend-positive">
                    <i class="fas fa-arrow-up"></i>
                    <span>+23 hoy</span>
                </div>
            </div>

            <div class="stat-card" onclick="showDetails('optimization')">
                <div class="stat-header">
                    <div>
                        <div class="stat-value" id="space-saved">2.4</div>
                        <div class="stat-label">GB Liberados</div>
                    </div>
                    <div class="stat-icon optimization">
                        <i class="fas fa-broom"></i>
                    </div>
                </div>
                <div class="stat-trend trend-positive">
                    <i class="fas fa-arrow-up"></i>
                    <span>+500MB hoy</span>
                </div>
            </div>
        </div>

        <!-- Dashboard Grid -->
        <div class="dashboard-grid">
            <!-- Main Dashboard -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2 class="card-title">🔍 Análisis del Sistema</h2>
                    <button class="card-action" onclick="runFullScan()">
                        <i class="fas fa-play"></i>
                        <span>Escaneo Completo</span>
                    </button>
                </div>

                <div class="progress-container">
                    <div class="progress-header">
                        <span>CPU</span>
                        <span id="cpu-usage">45%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 45%"></div>
                    </div>
                </div>

                <div class="progress-container">
                    <div class="progress-header">
                        <span>RAM</span>
                        <span id="ram-usage">67%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 67%"></div>
                    </div>
                </div>

                <div class="progress-container">
                    <div class="progress-header">
                        <span>Almacenamiento</span>
                        <span id="storage-usage">78%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 78%"></div>
                    </div>
                </div>

                <div class="progress-container">
                    <div class="progress-header">
                        <span>Batería</span>
                        <span id="battery-level">89%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 89%"></div>
                    </div>
                </div>
            </div>

            <!-- System Status -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h2 class="card-title">⚡ Estado del Sistema</h2>
                </div>

                <div class="system-status">
                    <div class="status-item">
                        <div class="status-info">
                            <div class="status-icon" style="background: var(--success-gradient);">
                                <i class="fas fa-shield-check"></i>
                            </div>
                            <div class="status-details">
                                <h4>Protección Activa</h4>
                                <p>Todos los módulos funcionando</p>
                            </div>
                        </div>
                        <div class="status-indicator status-good"></div>
                    </div>

                    <div class="status-item">
                        <div class="status-info">
                            <div class="status-icon" style="background: var(--warning-gradient);">
                                <i class="fas fa-database"></i>
                            </div>
                            <div class="status-details">
                                <h4>Base de Datos</h4>
                                <p>Actualizada hace 2 horas</p>
                            </div>
                        </div>
                        <div class="status-indicator status-warning"></div>
                    </div>

                    <div class="status-item">
                        <div class="status-info">
                            <div class="status-icon" style="background: var(--primary-gradient);">
                                <i class="fas fa-robot"></i>
                            </div>
                            <div class="status-details">
                                <h4>IA Activa</h4>
                                <p>Aprendizaje continuo</p>
                            </div>
                        </div>
                        <div class="status-indicator status-good"></div>
                    </div>

                    <div class="status-item">
                        <div class="status-info">
                            <div class="status-icon" style="background: var(--success-gradient);">
                                <i class="fas fa-wifi"></i>
                            </div>
                            <div class="status-details">
                                <h4>Conexión</h4>
                                <p>Estable - 98ms</p>
                            </div>
                        </div>
                        <div class="status-indicator status-good"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Grid -->
        <div class="action-grid">
            <a href="threat_center.php" class="action-btn">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Centro de Amenazas</h3>
                <p>Monitoreo y respuesta en tiempo real</p>
            </a>

            <a href="performance.php" class="action-btn">
                <i class="fas fa-rocket"></i>
                <h3>Optimización</h3>
                <p>Mejora el rendimiento del sistema</p>
            </a>

            <a href="chatbot.php" class="action-btn">
                <i class="fas fa-comments"></i>
                <h3>Asistente IA</h3>
                <p>Consultas inteligentes 24/7</p>
            </a>

            <a href="reports.php" class="action-btn">
                <i class="fas fa-chart-line"></i>
                <h3>Reportes</h3>
                <p>Análisis detallado y estadísticas</p>
            </a>
        </div>
    </div>

    <!-- Floating Action Button -->
    <button class="fab" onclick="quickScan()" title="Escaneo Rápido">
        <i class="fas fa-search"></i>
    </button>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <span id="toast-message"></span>
    </div>

    <script>
        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            initializeDashboard();
            startRealTimeUpdates();
            animateCounters();
        });

        // Inicializar dashboard
        function initializeDashboard() {
            updateSystemMetrics();
            loadRecentActivity();
            checkSystemHealth();
        }

        // Actualizar métricas del sistema
        function updateSystemMetrics() {
            // Simular datos en tiempo real
            const metrics = {
                cpu: Math.floor(Math.random() * 30) + 30,
                ram: Math.floor(Math.random() * 40) + 50,
                storage: Math.floor(Math.random() * 20) + 70,
                battery: Math.floor(Math.random() * 20) + 80
            };

            document.getElementById('cpu-usage').textContent = metrics.cpu + '%';
            document.getElementById('ram-usage').textContent = metrics.ram + '%';
            document.getElementById('storage-usage').textContent = metrics.storage + '%';
            document.getElementById('battery-level').textContent = metrics.battery + '%';

            // Actualizar barras de progreso
            document.querySelector('.progress-container:nth-child(1) .progress-fill').style.width = metrics.cpu + '%';
            document.querySelector('.progress-container:nth-child(2) .progress-fill').style.width = metrics.ram + '%';
            document.querySelector('.progress-container:nth-child(3) .progress-fill').style.width = metrics.storage + '%';
            document.querySelector('.progress-container:nth-child(4) .progress-fill').style.width = metrics.battery + '%';
        }

        // Iniciar actualizaciones en tiempo real
        function startRealTimeUpdates() {
            setInterval(updateSystemMetrics, 5000);
            setInterval(updateStats, 10000);
        }

        // Actualizar estadísticas
        function updateStats() {
            const securityScore = Math.floor(Math.random() * 5) + 95;
            const performanceScore = Math.floor(Math.random() * 10) + 85;
            const threatsBlocked = Math.floor(Math.random() * 50) + 200;
            const spaceSaved = (Math.random() * 2 + 2).toFixed(1);

            animateCounter('security-score', securityScore);
            animateCounter('performance-score', performanceScore);
            animateCounter('threats-blocked', threatsBlocked);
            animateCounter('space-saved', spaceSaved);
        }

        // Animar contadores
        function animateCounters() {
            const counters = document.querySelectorAll('.stat-value');
            counters.forEach(counter => {
                const target = parseInt(counter.textContent);
                let current = 0;
                const increment = target / 50;
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        counter.textContent = target;
                        clearInterval(timer);
                    } else {
                        counter.textContent = Math.floor(current);
                    }
                }, 40);
            });
        }

        // Animar contador específico
        function animateCounter(elementId, targetValue) {
            const element = document.getElementById(elementId);
            const currentValue = parseFloat(element.textContent);
            const increment = (targetValue - currentValue) / 20;
            let current = currentValue;

            const timer = setInterval(() => {
                current += increment;
                if ((increment > 0 && current >= targetValue) || (increment < 0 && current <= targetValue)) {
                    element.textContent = targetValue;
                    clearInterval(timer);
                } else {
                    element.textContent = typeof targetValue === 'string' ? current.toFixed(1) : Math.floor(current);
                }
            }, 50);
        }

        // Mostrar detalles de estadística
        function showDetails(type) {
            const messages = {
                security: 'Puntuación de seguridad excelente. Sistema protegido contra amenazas conocidas.',
                performance: 'Rendimiento óptimo. Sistema funcionando eficientemente.',
                threats: 'Amenazas bloqueadas exitosamente. Protección activa funcionando.',
                optimization: 'Espacio liberado mediante limpieza inteligente.'
            };

            showToast(messages[type], 'success');
        }

        // Ejecutar escaneo completo
        function runFullScan() {
            showToast('Iniciando escaneo completo del sistema...', 'success');
            
            // Simular progreso de escaneo
            let progress = 0;
            const scanInterval = setInterval(() => {
                progress += Math.random() * 10;
                if (progress >= 100) {
                    progress = 100;
                    clearInterval(scanInterval);
                    showToast('Escaneo completo finalizado. No se encontraron amenazas.', 'success');
                }
            }, 500);
        }

        // Escaneo rápido
        function quickScan() {
            showToast('Ejecutando escaneo rápido...', 'success');
            
            setTimeout(() => {
                showToast('Escaneo rápido completado. Sistema seguro.', 'success');
            }, 3000);
        }

        // Cargar actividad reciente
        function loadRecentActivity() {
            // Simular carga de actividad reciente
            console.log('Cargando actividad reciente...');
        }

        // Verificar salud del sistema
        function checkSystemHealth() {
            // Simular verificación de salud
            console.log('Verificando salud del sistema...');
        }

        // Mostrar notificación toast
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type}`;
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 4000);
        }

        // Efectos de hover para las tarjetas
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Efectos de hover para botones de acción
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px) scale(1.02)';
            });
            
            btn.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Navegación suave
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                if (this.getAttribute('href').startsWith('#')) {
                    e.preventDefault();
                    // Lógica de navegación suave aquí
                }
            });
        });

        // Responsive menu toggle (para móviles)
        function toggleMobileMenu() {
            const navMenu = document.querySelector('.nav-menu');
            navMenu.classList.toggle('show');
        }

        // Detectar cambios de tamaño de ventana
        window.addEventListener('resize', function() {
            // Ajustar layout responsivo si es necesario
            if (window.innerWidth <= 768) {
                // Lógica para móviles
            }
        });

        // Prevenir errores de consola
        window.addEventListener('error', function(e) {
            console.log('Error capturado:', e.message);
        });

        // Funciones de utilidad
        function formatNumber(num) {
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        function formatBytes(bytes, decimals = 2) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const dm = decimals < 0 ? 0 : decimals;
            const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        }

        // Inicializar tooltips
        function initializeTooltips() {
            const elements = document.querySelectorAll('[title]');
            elements.forEach(element => {
                element.addEventListener('mouseenter', function() {
                    // Lógica de tooltip personalizada
                });
            });
        }

        // Llamar inicialización de tooltips
        initializeTooltips();
    </script>
</body>
</html>

