<?php
require_once 'auth.php';

// Si ya está autenticado, redirigir al dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: user_dashboard.php');
    exit;
}

// Verificar token de recordar
checkRememberToken($conn);
if (isset($_SESSION['user_id'])) {
    header('Location: user_dashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - GuardianIA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --warning-gradient: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-card: #16213e;
            --text-primary: #ffffff;
            --text-secondary: #a0a9c0;
            --border-color: #2d3748;
            --shadow-color: rgba(0, 0, 0, 0.3);
            
            --animation-speed: 0.3s;
            --border-radius: 12px;
            --card-padding: 24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: var(--bg-primary);
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(102, 126, 234, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(118, 75, 162, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(67, 233, 123, 0.2) 0%, transparent 50%);
            animation: backgroundPulse 8s ease-in-out infinite;
        }

        @keyframes backgroundPulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }

        /* Login Container */
        .login-container {
            width: 100%;
            max-width: 450px;
            padding: 2rem;
        }

        .login-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 3rem;
            box-shadow: 0 20px 40px var(--shadow-color);
            position: relative;
            overflow: hidden;
        }

        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary-gradient);
        }

        /* Logo and Header */
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            font-size: 2rem;
            font-weight: 800;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 1rem;
        }

        .login-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        .login-subtitle {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Form Styles */
        .login-form {
            margin-bottom: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        .form-input-container {
            position: relative;
        }

        .form-input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1rem 1rem 1rem 3rem;
            color: var(--text-primary);
            font-family: inherit;
            font-size: 1rem;
            transition: all var(--animation-speed) ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-gradient);
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-input::placeholder {
            color: var(--text-secondary);
        }

        .form-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            font-size: 1rem;
        }

        .form-input:focus + .form-icon {
            color: #667eea;
        }

        /* Password Toggle */
        .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            cursor: pointer;
            transition: color var(--animation-speed) ease;
        }

        .password-toggle:hover {
            color: var(--text-primary);
        }

        /* Checkbox */
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }

        .checkbox {
            position: relative;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .checkbox input {
            opacity: 0;
            position: absolute;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        .checkbox-custom {
            width: 20px;
            height: 20px;
            border: 2px solid var(--border-color);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all var(--animation-speed) ease;
        }

        .checkbox input:checked + .checkbox-custom {
            background: var(--primary-gradient);
            border-color: transparent;
        }

        .checkbox-custom i {
            color: white;
            font-size: 0.8rem;
            opacity: 0;
            transition: opacity var(--animation-speed) ease;
        }

        .checkbox input:checked + .checkbox-custom i {
            opacity: 1;
        }

        .checkbox-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
            cursor: pointer;
        }

        /* Buttons */
        .btn {
            width: 100%;
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all var(--animation-speed) ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 25px rgba(255, 255, 255, 0.1);
        }

        /* Links */
        .form-links {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .form-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color var(--animation-speed) ease;
        }

        .form-link:hover {
            color: #667eea;
        }

        /* Divider */
        .divider {
            display: flex;
            align-items: center;
            margin: 2rem 0;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border-color);
        }

        .divider span {
            padding: 0 1rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        /* Footer */
        .login-footer {
            text-align: center;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .login-footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }

        .login-footer a:hover {
            text-decoration: underline;
        }

        /* Error/Success Messages */
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            display: none;
        }

        .alert.success {
            background: rgba(67, 233, 123, 0.1);
            border: 1px solid rgba(67, 233, 123, 0.3);
            color: #43e97b;
        }

        .alert.error {
            background: rgba(250, 112, 154, 0.1);
            border: 1px solid rgba(250, 112, 154, 0.3);
            color: #fa709a;
        }

        .alert.warning {
            background: rgba(255, 167, 38, 0.1);
            border: 1px solid rgba(255, 167, 38, 0.3);
            color: #ffa726;
        }

        .alert.info {
            background: rgba(79, 172, 254, 0.1);
            border: 1px solid rgba(79, 172, 254, 0.3);
            color: #4facfe;
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .login-container {
                padding: 1rem;
            }

            .login-card {
                padding: 2rem;
            }

            .logo {
                font-size: 1.5rem;
            }

            .login-title {
                font-size: 1.5rem;
            }
        }

        /* Animation for card entrance */
        .login-card {
            animation: cardSlideIn 0.6s ease-out;
        }

        @keyframes cardSlideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-shield-alt"></i>
                    <span>GuardianIA</span>
                </div>
                <h1 class="login-title">Bienvenido de vuelta</h1>
                <p class="login-subtitle">Inicia sesión para acceder a tu panel de seguridad</p>
            </div>

            <div id="alert" class="alert"></div>

            <form class="login-form" id="loginForm">
                <div class="form-group">
                    <label class="form-label" for="email">Correo Electrónico</label>
                    <div class="form-input-container">
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            class="form-input" 
                            placeholder="tu@email.com"
                            required
                        >
                        <i class="fas fa-envelope form-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Contraseña</label>
                    <div class="form-input-container">
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="Tu contraseña"
                            required
                        >
                        <i class="fas fa-lock form-icon"></i>
                        <i class="fas fa-eye password-toggle" onclick="togglePassword()"></i>
                    </div>
                </div>

                <div class="checkbox-group">
                    <label class="checkbox">
                        <input type="checkbox" name="remember" id="remember">
                        <div class="checkbox-custom">
                            <i class="fas fa-check"></i>
                        </div>
                    </label>
                    <label class="checkbox-label" for="remember">Recordarme</label>
                </div>

                <button type="submit" class="btn" id="loginButton">
                    <i class="fas fa-sign-in-alt"></i>
                    Iniciar Sesión
                </button>
            </form>

            <div class="form-links">
                <a href="#" class="form-link" onclick="showForgotPassword()">¿Olvidaste tu contraseña?</a>
                <a href="#" class="form-link" onclick="showResendVerification()">Reenviar verificación</a>
            </div>

            <div class="divider">
                <span>¿No tienes cuenta?</span>
            </div>

            <button class="btn btn-secondary" onclick="showRegister()">
                <i class="fas fa-user-plus"></i>
                Crear Cuenta
            </button>

            <div class="login-footer">
                <p>Al iniciar sesión, aceptas nuestros <a href="#">Términos de Servicio</a> y <a href="#">Política de Privacidad</a></p>
            </div>
        </div>
    </div>

    <!-- Forgot Password Modal -->
    <div id="forgotPasswordModal" style="display: none;">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-key"></i>
                    <span>Recuperar Contraseña</span>
                </div>
                <h1 class="login-title">¿Olvidaste tu contraseña?</h1>
                <p class="login-subtitle">Ingresa tu email y te enviaremos instrucciones para restablecerla</p>
            </div>

            <div id="forgotAlert" class="alert"></div>

            <form class="login-form" id="forgotPasswordForm">
                <div class="form-group">
                    <label class="form-label" for="forgotEmail">Correo Electrónico</label>
                    <div class="form-input-container">
                        <input 
                            type="email" 
                            id="forgotEmail" 
                            name="email" 
                            class="form-input" 
                            placeholder="tu@email.com"
                            required
                        >
                        <i class="fas fa-envelope form-icon"></i>
                    </div>
                </div>

                <button type="submit" class="btn" id="forgotButton">
                    <i class="fas fa-paper-plane"></i>
                    Enviar Instrucciones
                </button>
            </form>

            <div class="login-footer">
                <a href="#" onclick="showLogin()">← Volver al inicio de sesión</a>
            </div>
        </div>
    </div>

    <!-- Register Modal -->
    <div id="registerModal" style="display: none;">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-user-plus"></i>
                    <span>Crear Cuenta</span>
                </div>
                <h1 class="login-title">Únete a GuardianIA</h1>
                <p class="login-subtitle">Crea tu cuenta para comenzar a proteger tu sistema</p>
            </div>

            <div id="registerAlert" class="alert"></div>

            <form class="login-form" id="registerForm">
                <div class="form-group">
                    <label class="form-label" for="fullName">Nombre Completo</label>
                    <div class="form-input-container">
                        <input 
                            type="text" 
                            id="fullName" 
                            name="full_name" 
                            class="form-input" 
                            placeholder="Tu nombre completo"
                            required
                        >
                        <i class="fas fa-user form-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="registerEmail">Correo Electrónico</label>
                    <div class="form-input-container">
                        <input 
                            type="email" 
                            id="registerEmail" 
                            name="email" 
                            class="form-input" 
                            placeholder="tu@email.com"
                            required
                        >
                        <i class="fas fa-envelope form-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="registerPassword">Contraseña</label>
                    <div class="form-input-container">
                        <input 
                            type="password" 
                            id="registerPassword" 
                            name="password" 
                            class="form-input" 
                            placeholder="Mínimo 8 caracteres"
                            required
                        >
                        <i class="fas fa-lock form-icon"></i>
                        <i class="fas fa-eye password-toggle" onclick="togglePassword('registerPassword')"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirmPassword">Confirmar Contraseña</label>
                    <div class="form-input-container">
                        <input 
                            type="password" 
                            id="confirmPassword" 
                            name="confirm_password" 
                            class="form-input" 
                            placeholder="Confirma tu contraseña"
                            required
                        >
                        <i class="fas fa-lock form-icon"></i>
                        <i class="fas fa-eye password-toggle" onclick="togglePassword('confirmPassword')"></i>
                    </div>
                </div>

                <button type="submit" class="btn" id="registerButton">
                    <i class="fas fa-user-plus"></i>
                    Crear Cuenta
                </button>
            </form>

            <div class="login-footer">
                <a href="#" onclick="showLogin()">← Ya tengo cuenta</a>
            </div>
        </div>
    </div>

    <!-- Resend Verification Modal -->
    <div id="resendVerificationModal" style="display: none;">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-envelope-open"></i>
                    <span>Verificar Email</span>
                </div>
                <h1 class="login-title">Reenviar Verificación</h1>
                <p class="login-subtitle">Ingresa tu email para reenviar el enlace de verificación</p>
            </div>

            <div id="resendAlert" class="alert"></div>

            <form class="login-form" id="resendVerificationForm">
                <div class="form-group">
                    <label class="form-label" for="resendEmail">Correo Electrónico</label>
                    <div class="form-input-container">
                        <input 
                            type="email" 
                            id="resendEmail" 
                            name="email" 
                            class="form-input" 
                            placeholder="tu@email.com"
                            required
                        >
                        <i class="fas fa-envelope form-icon"></i>
                    </div>
                </div>

                <button type="submit" class="btn" id="resendButton">
                    <i class="fas fa-paper-plane"></i>
                    Reenviar Verificación
                </button>
            </form>

            <div class="login-footer">
                <a href="#" onclick="showLogin()">← Volver al inicio de sesión</a>
            </div>
        </div>
    </div>

    <script>
        // Variables globales
        let currentView = 'login';

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            initializeLogin();
            setupEventListeners();
        });

        // Inicializar login
        function initializeLogin() {
            console.log('Inicializando sistema de autenticación...');
            showLogin();
        }

        // Configurar event listeners
        function setupEventListeners() {
            // Formularios
            document.getElementById('loginForm').addEventListener('submit', handleLogin);
            document.getElementById('forgotPasswordForm').addEventListener('submit', handleForgotPassword);
            document.getElementById('registerForm').addEventListener('submit', handleRegister);
            document.getElementById('resendVerificationForm').addEventListener('submit', handleResendVerification);

            // Enter key para enviar formularios
            document.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    const activeForm = document.querySelector('form:not([style*="display: none"])');
                    if (activeForm) {
                        activeForm.dispatchEvent(new Event('submit'));
                    }
                }
            });
        }

        // Mostrar vista de login
        function showLogin() {
            hideAllViews();
            document.querySelector('.login-container').style.display = 'block';
            currentView = 'login';
        }

        // Mostrar vista de recuperar contraseña
        function showForgotPassword() {
            hideAllViews();
            document.getElementById('forgotPasswordModal').style.display = 'block';
            currentView = 'forgot';
        }

        // Mostrar vista de registro
        function showRegister() {
            hideAllViews();
            document.getElementById('registerModal').style.display = 'block';
            currentView = 'register';
        }

        // Mostrar vista de reenviar verificación
        function showResendVerification() {
            hideAllViews();
            document.getElementById('resendVerificationModal').style.display = 'block';
            currentView = 'resend';
        }

        // Ocultar todas las vistas
        function hideAllViews() {
            document.querySelector('.login-container').style.display = 'none';
            document.getElementById('forgotPasswordModal').style.display = 'none';
            document.getElementById('registerModal').style.display = 'none';
            document.getElementById('resendVerificationModal').style.display = 'none';
        }

        // Toggle password visibility
        function togglePassword(inputId = 'password') {
            const input = document.getElementById(inputId);
            const toggle = input.parentElement.querySelector('.password-toggle');
            
            if (input.type === 'password') {
                input.type = 'text';
                toggle.classList.remove('fa-eye');
                toggle.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                toggle.classList.remove('fa-eye-slash');
                toggle.classList.add('fa-eye');
            }
        }

        // Manejar login
        function handleLogin(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'login');
            
            const button = document.getElementById('loginButton');
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Iniciando sesión...';
            button.disabled = true;
            
            hideAlert('alert');

            fetch('auth.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.innerHTML = originalText;
                button.disabled = false;

                if (data.success) {
                    showAlert('alert', 'Inicio de sesión exitoso. Redirigiendo...', 'success');
                    setTimeout(() => {
                        window.location.href = 'user_dashboard.php';
                    }, 1500);
                } else {
                    showAlert('alert', data.error, 'error');
                    
                    if (data.needs_verification) {
                        setTimeout(() => {
                            showResendVerification();
                            document.getElementById('resendEmail').value = formData.get('email');
                        }, 2000);
                    }
                }
            })
            .catch(error => {
                button.innerHTML = originalText;
                button.disabled = false;
                console.error('Error:', error);
                showAlert('alert', 'Error de conexión. Inténtalo de nuevo.', 'error');
            });
        }

        // Manejar recuperar contraseña
        function handleForgotPassword(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'forgot_password');
            
            const button = document.getElementById('forgotButton');
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Enviando...';
            button.disabled = true;
            
            hideAlert('forgotAlert');

            fetch('auth.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.innerHTML = originalText;
                button.disabled = false;

                if (data.success) {
                    showAlert('forgotAlert', data.message, 'success');
                    setTimeout(() => {
                        showLogin();
                    }, 3000);
                } else {
                    showAlert('forgotAlert', data.error, 'error');
                }
            })
            .catch(error => {
                button.innerHTML = originalText;
                button.disabled = false;
                console.error('Error:', error);
                showAlert('forgotAlert', 'Error de conexión. Inténtalo de nuevo.', 'error');
            });
        }

        // Manejar registro
        function handleRegister(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'register');
            
            const button = document.getElementById('registerButton');
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Creando cuenta...';
            button.disabled = true;
            
            hideAlert('registerAlert');

            fetch('auth.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.innerHTML = originalText;
                button.disabled = false;

                if (data.success) {
                    showAlert('registerAlert', data.message, 'success');
                    setTimeout(() => {
                        showLogin();
                    }, 3000);
                } else {
                    showAlert('registerAlert', data.error, 'error');
                }
            })
            .catch(error => {
                button.innerHTML = originalText;
                button.disabled = false;
                console.error('Error:', error);
                showAlert('registerAlert', 'Error de conexión. Inténtalo de nuevo.', 'error');
            });
        }

        // Manejar reenvío de verificación
        function handleResendVerification(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'resend_verification');
            
            const button = document.getElementById('resendButton');
            const originalText = button.innerHTML;
            
            button.innerHTML = '<div class="loading"></div> Enviando...';
            button.disabled = true;
            
            hideAlert('resendAlert');

            fetch('auth.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.innerHTML = originalText;
                button.disabled = false;

                if (data.success) {
                    showAlert('resendAlert', data.message, 'success');
                    setTimeout(() => {
                        showLogin();
                    }, 3000);
                } else {
                    showAlert('resendAlert', data.error, 'error');
                }
            })
            .catch(error => {
                button.innerHTML = originalText;
                button.disabled = false;
                console.error('Error:', error);
                showAlert('resendAlert', 'Error de conexión. Inténtalo de nuevo.', 'error');
            });
        }

        // Mostrar alerta
        function showAlert(alertId, message, type) {
            const alert = document.getElementById(alertId);
            alert.textContent = message;
            alert.className = `alert ${type}`;
            alert.style.display = 'block';
        }

        // Ocultar alerta
        function hideAlert(alertId) {
            const alert = document.getElementById(alertId);
            alert.style.display = 'none';
        }

        // Validación en tiempo real
        document.addEventListener('input', function(e) {
            if (e.target.type === 'password') {
                validatePassword(e.target);
            }
            
            if (e.target.type === 'email') {
                validateEmail(e.target);
            }
        });

        // Validar email
        function validateEmail(input) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const isValid = emailRegex.test(input.value);
            
            if (input.value && !isValid) {
                input.style.borderColor = '#fa709a';
            } else {
                input.style.borderColor = '';
            }
        }

        // Validar contraseña
        function validatePassword(input) {
            const isValid = input.value.length >= 8;
            
            if (input.value && !isValid) {
                input.style.borderColor = '#fa709a';
            } else {
                input.style.borderColor = '';
            }
            
            // Validar confirmación de contraseña
            if (input.name === 'password' && currentView === 'register') {
                const confirmInput = document.getElementById('confirmPassword');
                if (confirmInput.value && confirmInput.value !== input.value) {
                    confirmInput.style.borderColor = '#fa709a';
                } else {
                    confirmInput.style.borderColor = '';
                }
            }
            
            if (input.name === 'confirm_password') {
                const passwordInput = document.getElementById('registerPassword');
                if (input.value && input.value !== passwordInput.value) {
                    input.style.borderColor = '#fa709a';
                } else {
                    input.style.borderColor = '';
                }
            }
        }

        // Manejo de errores
        window.addEventListener('error', function(e) {
            console.log('Error capturado:', e.message);
            showAlert('alert', 'Se produjo un error inesperado. Recarga la página e inténtalo de nuevo.', 'error');
        });

        // Verificar si hay parámetros en la URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('verified') === 'true') {
            showAlert('alert', 'Email verificado correctamente. Ya puedes iniciar sesión.', 'success');
        }
        if (urlParams.get('reset') === 'true') {
            showAlert('alert', 'Contraseña restablecida correctamente. Ya puedes iniciar sesión.', 'success');
        }
    </script>
</body>
</html>

