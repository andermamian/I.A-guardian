package com.guardianai;

import android.app.Activity;

public class GuardianMusicCreatorActivity extends Activity {
}
